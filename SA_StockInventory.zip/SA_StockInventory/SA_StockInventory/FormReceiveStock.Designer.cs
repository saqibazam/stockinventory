﻿namespace SA_StockInventory
{
    partial class FormReceiveStock
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource1 = new Microsoft.Reporting.WinForms.ReportDataSource();
            this.View_StockInBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.viewSaIN = new SA_StockInventory.ViewSaIN();
            this.reportViewerSIn = new Microsoft.Reporting.WinForms.ReportViewer();
            this.viewSaINBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.View_StockInTableAdapter = new SA_StockInventory.ViewSaINTableAdapters.View_StockInTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.View_StockInBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.viewSaIN)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.viewSaINBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // View_StockInBindingSource
            // 
            this.View_StockInBindingSource.DataMember = "View_StockIn";
            this.View_StockInBindingSource.DataSource = this.viewSaIN;
            // 
            // viewSaIN
            // 
            this.viewSaIN.DataSetName = "ViewSaIN";
            this.viewSaIN.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // reportViewerSIn
            // 
            this.reportViewerSIn.Dock = System.Windows.Forms.DockStyle.Fill;
            reportDataSource1.Name = "DataSetSINREPORT";
            reportDataSource1.Value = this.View_StockInBindingSource;
            this.reportViewerSIn.LocalReport.DataSources.Add(reportDataSource1);
            this.reportViewerSIn.LocalReport.ReportEmbeddedResource = "SA_StockInventory.ReportStockIn.rdlc";
            this.reportViewerSIn.Location = new System.Drawing.Point(0, 0);
            this.reportViewerSIn.Margin = new System.Windows.Forms.Padding(0);
            this.reportViewerSIn.Name = "reportViewerSIn";
            this.reportViewerSIn.Size = new System.Drawing.Size(746, 465);
            this.reportViewerSIn.TabIndex = 0;
            // 
            // viewSaINBindingSource
            // 
            this.viewSaINBindingSource.DataSource = this.viewSaIN;
            this.viewSaINBindingSource.Position = 0;
            // 
            // View_StockInTableAdapter
            // 
            this.View_StockInTableAdapter.ClearBeforeFill = true;
            // 
            // FormReceiveStock
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(746, 465);
            this.Controls.Add(this.reportViewerSIn);
            this.Name = "FormReceiveStock";
            this.Text = "Receive Stock";
            this.Load += new System.EventHandler(this.FormReceiveStock_Load);
            ((System.ComponentModel.ISupportInitialize)(this.View_StockInBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.viewSaIN)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.viewSaINBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Microsoft.Reporting.WinForms.ReportViewer reportViewerSIn;
        private System.Windows.Forms.BindingSource View_StockInBindingSource;
        private ViewSaIN viewSaIN;
        private System.Windows.Forms.BindingSource viewSaINBindingSource;
        private ViewSaINTableAdapters.View_StockInTableAdapter View_StockInTableAdapter;
    }
}