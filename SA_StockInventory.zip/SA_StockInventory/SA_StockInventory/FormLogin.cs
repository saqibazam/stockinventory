﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Security.Cryptography;
using System.Windows.Forms;

namespace SA_StockInventory
{
    public partial class FormLogin : Form
    {
        Class_Connection cn = new Class_Connection();
    //    DialogResult dlgResult;
    //    SqlCommand cmd;
        public FormLogin()
        {
            InitializeComponent();
        }

        private void buttonLogin_Click(object sender, EventArgs e)
        {
            PasswordCheck();
        }

        private string Decrypt(string strText)
        {
            string strEncrypt = "!!@#$%^&.,/'*_*&^";
            byte[] bKey = new byte[20];
            byte[] IV = { 0x12, 0x34, 0x56, 0x78, 0x90, 0xAB, 0xCD, 0xEF };

     
            bKey = System.Text.Encoding.UTF8.GetBytes(strEncrypt.Substring(0, 8));
            DESCryptoServiceProvider des = new DESCryptoServiceProvider();
            Byte[] inputByteArray = inputByteArray = Convert.FromBase64String(strText);
            MemoryStream ms = new MemoryStream();
            CryptoStream cs = new CryptoStream(ms, des.CreateDecryptor(bKey, IV), CryptoStreamMode.Write);
            cs.Write(inputByteArray, 0, inputByteArray.Length);
            cs.FlushFinalBlock();
            System.Text.Encoding encoding = System.Text.Encoding.UTF8;
            return encoding.GetString(ms.ToArray());
         
        }

        public static string CheckUserName = "";
        private void PasswordCheck()
        {
            try
            {
                SqlCommand cmd = new SqlCommand("select user_name , user_password  from Users where user_name = @username ", cn.con);
                cmd.Parameters.AddWithValue("@username", textBoxUserName.Text);
                cn.con.Open();

                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {

                    string usr = reader["user_name"].ToString();

                    string pwd = Decrypt(reader["user_password"].ToString());
                    if ((textBoxUserName.Text.Trim() == usr) & (textBoxPassword.Text.Trim() == pwd))
                    {
                        //This Code will show CheckUserName in MDIParentStock Form
                        //Same work for Each Edit Form to retreive UserName, if username is Admin than Edit will be allowed
                        this.Hide();
                         CheckUserName = usr;
                        MDIParentStock mdi = new MDIParentStock();
                        mdi.ShowDialog();
                        this.Close();
                    }
                    else
                    {
                        MessageBox.Show("INVALID USER NAME OR PASSWORD", "INVALID PASSWORD", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        textBoxUserName.Focus();
                        textBoxUserName.SelectionStart = 0;
                        textBoxUserName.SelectionLength = textBoxUserName.Text.Length;
                        textBoxPassword.Text = "";
                    }
                }
                reader.Close();
                cn.con.Close();
            }

            catch (Exception x)
            {
                MessageBox.Show(x.GetBaseException().ToString(), "Error",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }
        private void textBoxPassword_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
            {
                PasswordCheck();
            }
        }

        private void FormLogin_Load(object sender, EventArgs e)
        {

        }
    }
}
