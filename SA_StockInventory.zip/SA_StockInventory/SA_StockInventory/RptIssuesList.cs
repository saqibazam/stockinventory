﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SA_StockInventory
{
    public partial class RptIssuesList : Form
    {
        public RptIssuesList()
        {
            InitializeComponent();
        }

        private void RptIssuesList_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'sastockDataSetCategory.Category' table. You can move, or remove it, as needed.
            this.categoryTableAdapter.Fill(this.sastockDataSetCategory.Category);
            // TODO: This line of code loads data into the 'sastockDataSetClient.Client_info' table. You can move, or remove it, as needed.
            this.client_infoTableAdapter.Fill(this.sastockDataSetClient.Client_info);



            this.reportViewer1.RefreshReport();
        }

        private void buttonSearch_Click(object sender, EventArgs e)
        {

            if (radioButtonClient.Checked == true)
            {
                this.View_StockInTableAdapter.FillByClientID (this.ViewSaIN.View_StockIn, Convert.ToInt16(comboBoxClient.SelectedValue));
                this.reportViewer1.ZoomMode = Microsoft.Reporting.WinForms.ZoomMode.PageWidth;
                this.reportViewer1.RefreshReport();
            }
            if (radioButtonClient.Checked == true && checkBoxDate.Checked == true)
            {
                this.View_StockInTableAdapter.FillByClient(this.ViewSaIN.View_StockIn, Convert.ToInt16(comboBoxClient.SelectedValue), dateTimePickerFrom.Text, dateTimePickerTo.Text);
                this.reportViewer1.ZoomMode = Microsoft.Reporting.WinForms.ZoomMode.PageWidth;
                this.reportViewer1.RefreshReport();
            }

            if (radioButtonCatagory.Checked == true)
            {
                this.View_StockInTableAdapter.FillByCat(this.ViewSaIN.View_StockIn, Convert.ToInt16(comboBoxCatagory.SelectedValue));
                this.reportViewer1.ZoomMode = Microsoft.Reporting.WinForms.ZoomMode.PageWidth;
                this.reportViewer1.RefreshReport();
            }

            if (radioButtonCatagory.Checked == true && checkBoxDate .Checked == true  )
            {
                this.View_StockInTableAdapter.FillByCatagory(this.ViewSaIN.View_StockIn, Convert.ToInt16(comboBoxCatagory.SelectedValue), dateTimePickerFrom.Text, dateTimePickerTo.Text);
                this.reportViewer1.ZoomMode = Microsoft.Reporting.WinForms.ZoomMode.PageWidth;
                this.reportViewer1.RefreshReport();
            }

        }

        private void View_StockInBindingSource_CurrentChanged(object sender, EventArgs e)
        {

        }

        private void checkBoxFrom_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }
    }
}
