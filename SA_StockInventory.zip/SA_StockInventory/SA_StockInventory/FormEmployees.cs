﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SA_StockInventory
{
    public partial class Form_Employees : Form
    {
        public Form_Employees()
        {
            InitializeComponent();
        }

        Class_Connection cn = new Class_Connection();
        DialogResult dlgResult;
        SqlCommand cmd;
        //SqlDataAdapter adapt;
        int i = 1001;



   

        private void Form_Employees_Load(object sender, EventArgs e)
        {
            ////// TODO: This line of code loads data into the 'sastockDataSetEmployee.Department' table. You can move, or remove it, as needed.
            ////this.departmentTableAdapter.Fill(this.sastockDataSetEmployee.Department);
            ////// TODO: This line of code loads data into the 'sastockDataSetEmployee.Designation' table. You can move, or remove it, as needed.
            ////this.designationTableAdapter.Fill(this.sastockDataSetEmployee.Designation);
            ////// TODO: This line of code loads data into the 'sastockDataSetBranch.Branch' table. You can move, or remove it, as needed.
            ////this.branchTableAdapter.Fill(this.sastockDataSetBranch.Branch);
            ////// TODO: This line of code loads data into the 'sastockDataSetEmployee.Employees' table. You can move, or remove it, as needed.
            ////this.employeesTableAdapter.Fill(this.sastockDataSetEmployee.Employees);


            displayDataInGrid();
            DisplayDatainTextBox(i);

            string userName = FormLogin.CheckUserName;
            if (userName == "Admin" || userName == "Super")
            {
                button_Delete.Visible = true;
                button_Update.Visible = true;
            }

        }

        private void DisplayDatainTextBox(int i)
        {

            cn.con.Open();
            SqlCommand cmd = new SqlCommand();
            try
            {

                //cmd = new SqlCommand("select max(branch_id) from Branch", cn.con);

                // TODO: This line of code loads data into the 'sastockDataSetEmployee.Department' table. You can move, or remove it, as needed.
                this.departmentTableAdapter.Fill(this.sastockDataSetEmployee.Department);
                // TODO: This line of code loads data into the 'sastockDataSetEmployee.Designation' table. You can move, or remove it, as needed.
                this.designationTableAdapter.Fill(this.sastockDataSetEmployee.Designation);
                // TODO: This line of code loads data into the 'sastockDataSetBranch.Branch' table. You can move, or remove it, as needed.
                this.branchTableAdapter.Fill(this.sastockDataSetBranch.Branch);



                cmd = new SqlCommand("crudEmployees", cn.con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add(new SqlParameter("@StatementType", "SelectEmployees"));
                cmd.Parameters.Add(new SqlParameter("@EmpID", i));

                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    empIDTextBox.Text = reader["EmpID"].ToString();
                    empNameTextBox.Text = reader["EmpName"].ToString();
                    activeCheckBox.Checked = (reader.GetBoolean(reader.GetOrdinal("Active")));
                    nICTextBox.Text = reader["NIC"].ToString();
                    ageTextBox.Text = reader["Age"].ToString();
                    genderTextBox.Text = reader["Gender"].ToString();
                    fatherNameTextBox.Text = reader["FatherName"].ToString();
                    cAddTextBox.Text = reader["CAdd"].ToString();
                    cCityTextBox.Text = reader["CCity"].ToString();
                    phoneNoTextBox.Text = reader["PhoneNo"].ToString();
                    cellNoTextBox.Text = reader["CellNo"].ToString();
                    emailTextBox.Text = reader["Email"].ToString();
                    empStatusTextBox.Text = reader["EmpStatus"].ToString();
                    designationCodeComboBox.SelectedValue  = reader["DesignationCode"].ToString();
                    deptCodeComboBox.SelectedValue = reader["DeptCode"].ToString();
                    branchCodeComboBox.SelectedValue = reader["BranchCode"].ToString();

                  

                }
                reader.Close();
                cn.con.Close();
              

            }
            catch (Exception x)
            {
                MessageBox.Show(x.GetBaseException().ToString(), "Error",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                cmd.InitializeLifetimeService();
                // cmd.Dispose();
                cn.con.Close();
                //cn.con.Dispose(); //will be written on at exit from the application time....
            }
        }

        private void displayDataInGrid()
            {

          
            // TODO: This line of code loads data into the 'sastockDataSetEmployee.Employees' table. You can move, or remove it, as needed.
            this.employeesTableAdapter.Fill(this.sastockDataSetEmployee.Employees);

        }

    
        private void buttonNew_Click(object sender, EventArgs e)
        {
            buttonNew.Enabled = false;
            button_Insert.Enabled = true;
            button_Update.Enabled = false;


            empIDTextBox.Text = "";
            empNameTextBox.Text = "";
            activeCheckBox.Checked = false ;
            nICTextBox.Text = "";
            ageTextBox.Text = "";
            genderTextBox.Text = "";
            fatherNameTextBox.Text = "";
            cAddTextBox.Text = "";
            cCityTextBox.Text = "";
            phoneNoTextBox.Text = "";
            cellNoTextBox.Text = "";
            emailTextBox.Text = "";
            empStatusTextBox.Text = "";
            designationCodeComboBox.Text = "";
            deptCodeComboBox.Text = "";
            branchCodeComboBox.Text = "";




        }

        private void button_Insert_Click(object sender, EventArgs e)
        {
            dlgResult = MessageBox.Show("Do you want to Insert New Record", "New Record Insert", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
            if (dlgResult == DialogResult.Yes)
            {

                try
                {
                    if (empIDTextBox.Text == "" && empNameTextBox.Text != "")
                    {
                        //cmd = new SqlCommand("insert into Branch(branch_name,branch_location) values(@name,@location)", cn.con);
                        cn.con.Open();
                        cmd = new SqlCommand("crudEmployees", cn.con);
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.Add(new SqlParameter("@StatementType", "InsertEmployees"));
                        cmd.Parameters.AddWithValue("@EmpName", empNameTextBox.Text);
                        cmd.Parameters.AddWithValue("@Active", activeCheckBox.Checked  );
                        cmd.Parameters.AddWithValue("@NIC", nICTextBox.Text);
                        cmd.Parameters.AddWithValue("@Age", ageTextBox.Text);
                        cmd.Parameters.AddWithValue("@Gender", genderTextBox.Text);
                        cmd.Parameters.AddWithValue("@FatherName", fatherNameTextBox.Text);
                        cmd.Parameters.AddWithValue("@CAdd", cAddTextBox.Text);
                        cmd.Parameters.AddWithValue("@CCity", cCityTextBox.Text);
                        cmd.Parameters.AddWithValue("@PhoneNo", phoneNoTextBox.Text);
                        cmd.Parameters.AddWithValue("@CellNo", cellNoTextBox.Text);
                        cmd.Parameters.AddWithValue("@Email", emailTextBox.Text);
                        cmd.Parameters.AddWithValue("@EmpStatus", empStatusTextBox.Text);
                        cmd.Parameters.AddWithValue("@DesignationCode", designationCodeComboBox.SelectedValue);
                        cmd.Parameters.AddWithValue("@DeptCode", deptCodeComboBox.SelectedValue);
                        cmd.Parameters.AddWithValue("@BranchCode", branchCodeComboBox.SelectedValue);

                        cmd.ExecuteNonQuery();
                        cn.con.Close();
                        MessageBox.Show("Record Inserted Successfully");
                        DisplayDatainTextBox(i);
                        displayDataInGrid();

                        buttonNew.Enabled = true;
                        button_Insert.Enabled = false;
                        button_Update.Enabled = true;

                    }
                    else
                    {
                        MessageBox.Show("Only for New Record, Please Fill All Fields!");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(Convert.ToString(ex));
                }
            }
            
        }

     

   
     

        private void employeesDataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            empIDTextBox.Text = employeesDataGridView.Rows[e.RowIndex].Cells[0].Value.ToString();

            i = Convert.ToInt32(empIDTextBox.Text);
            DisplayDatainTextBox(i);
        }

      
        private void employeesDataGridView_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            empIDTextBox.Text = employeesDataGridView.Rows[e.RowIndex].Cells[0].Value.ToString();
            i = Convert.ToInt32(empIDTextBox.Text);
            DisplayDatainTextBox(i);
        }

        private void branchCodeComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button_Update_Click(object sender, EventArgs e)
        {
            dlgResult = MessageBox.Show("Do you want to Update this Record", "Update Record", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
            if (dlgResult == DialogResult.Yes)
            {


                try
                {
                    if (empNameTextBox.Text != "")
                    {
                        cn.con.Open();
                        cmd = new SqlCommand("crudEmployees", cn.con);
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.Add(new SqlParameter("@StatementType", "UpdateEmployees"));
                        cmd.Parameters.AddWithValue("@EmpID", empIDTextBox.Text);
                        cmd.Parameters.AddWithValue("@EmpName", empNameTextBox.Text);
                        cmd.Parameters.AddWithValue("@Active", activeCheckBox.Checked);
                        cmd.Parameters.AddWithValue("@NIC", nICTextBox.Text);
                        cmd.Parameters.AddWithValue("@Age", ageTextBox.Text);
                        cmd.Parameters.AddWithValue("@Gender", genderTextBox.Text);
                        cmd.Parameters.AddWithValue("@FatherName", fatherNameTextBox.Text);
                        cmd.Parameters.AddWithValue("@CAdd", cAddTextBox.Text);
                        cmd.Parameters.AddWithValue("@CCity", cCityTextBox.Text);
                        cmd.Parameters.AddWithValue("@PhoneNo", phoneNoTextBox.Text);
                        cmd.Parameters.AddWithValue("@CellNo", cellNoTextBox.Text);
                        cmd.Parameters.AddWithValue("@Email", emailTextBox.Text);
                        cmd.Parameters.AddWithValue("@EmpStatus", empStatusTextBox.Text);
                        cmd.Parameters.AddWithValue("@DesignationCode", designationCodeComboBox.SelectedValue);
                        cmd.Parameters.AddWithValue("@DeptCode", deptCodeComboBox.SelectedValue);
                        cmd.Parameters.AddWithValue("@BranchCode", branchCodeComboBox.SelectedValue);
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Record Updated Successfully");
                        cn.con.Close();
                        displayDataInGrid();
                        DisplayDatainTextBox(i);
                        buttonNew.Enabled = true;
                        button_Insert.Enabled = false;
                        button_Update.Enabled = true;

                    }
                    else
                    {
                        MessageBox.Show("Please Select Record to Update");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(Convert.ToString(ex));
                }
            }
        }

        private void button_Delete_Click(object sender, EventArgs e)
        {
            dlgResult = MessageBox.Show("Do you want to Delete this Record", "Delete Record", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
            if (dlgResult == DialogResult.Yes)
            {


                try
                {
                    if (empNameTextBox.Text != "")
                    {
                        // cmd = new SqlCommand("delete from Branch where branch_id=@id", cn.con);
                        cn.con.Open();
                        cmd = new SqlCommand("crudEmployees", cn.con);
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.Add(new SqlParameter("@StatementType", "DeleteEmployees"));
                        cmd.Parameters.AddWithValue("@EmpID", empIDTextBox.Text);
                        cmd.ExecuteNonQuery();
                        cn.con.Close();
                        MessageBox.Show("Record Deleted Successfully!");
                        DisplayDatainTextBox(i);
                        displayDataInGrid();
                    }
                    else { MessageBox.Show("Please Select Record to Delete"); }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(Convert.ToString(ex));
                }

                //   MessageBox.Show("Please Select Record to Delete");
            }
        }
    }
}
