﻿namespace SA_StockInventory
{
    partial class FormMDSout
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormMDSout));
            System.Windows.Forms.Label master_out_idLabel;
            System.Windows.Forms.Label emp_idLabel;
            System.Windows.Forms.Label cat_idLabel;
            System.Windows.Forms.Label date_soutLabel;
            this.sastockDataSet_OutMasterDetail = new SA_StockInventory.sastockDataSet_OutMasterDetail();
            this.stock_Out_MasterBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.stock_Out_MasterTableAdapter = new SA_StockInventory.sastockDataSet_OutMasterDetailTableAdapters.Stock_Out_MasterTableAdapter();
            this.tableAdapterManager = new SA_StockInventory.sastockDataSet_OutMasterDetailTableAdapters.TableAdapterManager();
            this.stock_Out_MasterBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.stock_Out_MasterBindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
            this.master_out_idTextBox = new System.Windows.Forms.TextBox();
            this.emp_idComboBox = new System.Windows.Forms.ComboBox();
            this.cat_idComboBox = new System.Windows.Forms.ComboBox();
            this.date_soutDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.stockOutDetailBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.stockOutDetailTableAdapter = new SA_StockInventory.sastockDataSet_OutMasterDetailTableAdapters.StockOutDetailTableAdapter();
            this.stockOutDetailDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            master_out_idLabel = new System.Windows.Forms.Label();
            emp_idLabel = new System.Windows.Forms.Label();
            cat_idLabel = new System.Windows.Forms.Label();
            date_soutLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.sastockDataSet_OutMasterDetail)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.stock_Out_MasterBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.stock_Out_MasterBindingNavigator)).BeginInit();
            this.stock_Out_MasterBindingNavigator.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.stockOutDetailBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.stockOutDetailDataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // sastockDataSet_OutMasterDetail
            // 
            this.sastockDataSet_OutMasterDetail.DataSetName = "sastockDataSet_OutMasterDetail";
            this.sastockDataSet_OutMasterDetail.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // stock_Out_MasterBindingSource
            // 
            this.stock_Out_MasterBindingSource.DataMember = "Stock_Out_Master";
            this.stock_Out_MasterBindingSource.DataSource = this.sastockDataSet_OutMasterDetail;
            // 
            // stock_Out_MasterTableAdapter
            // 
            this.stock_Out_MasterTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.Stock_Out_MasterTableAdapter = this.stock_Out_MasterTableAdapter;
            this.tableAdapterManager.StockOutDetailTableAdapter = this.stockOutDetailTableAdapter;
            this.tableAdapterManager.UpdateOrder = SA_StockInventory.sastockDataSet_OutMasterDetailTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // stock_Out_MasterBindingNavigator
            // 
            this.stock_Out_MasterBindingNavigator.AddNewItem = this.bindingNavigatorAddNewItem;
            this.stock_Out_MasterBindingNavigator.BindingSource = this.stock_Out_MasterBindingSource;
            this.stock_Out_MasterBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.stock_Out_MasterBindingNavigator.DeleteItem = this.bindingNavigatorDeleteItem;
            this.stock_Out_MasterBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.stock_Out_MasterBindingNavigatorSaveItem});
            this.stock_Out_MasterBindingNavigator.Location = new System.Drawing.Point(0, 0);
            this.stock_Out_MasterBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.stock_Out_MasterBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.stock_Out_MasterBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.stock_Out_MasterBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.stock_Out_MasterBindingNavigator.Name = "stock_Out_MasterBindingNavigator";
            this.stock_Out_MasterBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.stock_Out_MasterBindingNavigator.Size = new System.Drawing.Size(794, 25);
            this.stock_Out_MasterBindingNavigator.TabIndex = 0;
            this.stock_Out_MasterBindingNavigator.Text = "bindingNavigator1";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem.Text = "Move first";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem.Text = "Move previous";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Position";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Current position";
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(35, 15);
            this.bindingNavigatorCountItem.Text = "of {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Total number of items";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 6);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 20);
            this.bindingNavigatorMoveNextItem.Text = "Move next";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 20);
            this.bindingNavigatorMoveLastItem.Text = "Move last";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 6);
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorAddNewItem.Text = "Add new";
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(23, 20);
            this.bindingNavigatorDeleteItem.Text = "Delete";
            // 
            // stock_Out_MasterBindingNavigatorSaveItem
            // 
            this.stock_Out_MasterBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.stock_Out_MasterBindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("stock_Out_MasterBindingNavigatorSaveItem.Image")));
            this.stock_Out_MasterBindingNavigatorSaveItem.Name = "stock_Out_MasterBindingNavigatorSaveItem";
            this.stock_Out_MasterBindingNavigatorSaveItem.Size = new System.Drawing.Size(23, 23);
            this.stock_Out_MasterBindingNavigatorSaveItem.Text = "Save Data";
            this.stock_Out_MasterBindingNavigatorSaveItem.Click += new System.EventHandler(this.stock_Out_MasterBindingNavigatorSaveItem_Click_1);
            // 
            // master_out_idLabel
            // 
            master_out_idLabel.AutoSize = true;
            master_out_idLabel.Location = new System.Drawing.Point(15, 39);
            master_out_idLabel.Name = "master_out_idLabel";
            master_out_idLabel.Size = new System.Drawing.Size(71, 13);
            master_out_idLabel.TabIndex = 1;
            master_out_idLabel.Text = "Master out id:";
            // 
            // master_out_idTextBox
            // 
            this.master_out_idTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.stock_Out_MasterBindingSource, "Master_out_id", true));
            this.master_out_idTextBox.Location = new System.Drawing.Point(92, 36);
            this.master_out_idTextBox.Name = "master_out_idTextBox";
            this.master_out_idTextBox.Size = new System.Drawing.Size(200, 20);
            this.master_out_idTextBox.TabIndex = 2;
            // 
            // emp_idLabel
            // 
            emp_idLabel.AutoSize = true;
            emp_idLabel.Location = new System.Drawing.Point(15, 65);
            emp_idLabel.Name = "emp_idLabel";
            emp_idLabel.Size = new System.Drawing.Size(41, 13);
            emp_idLabel.TabIndex = 3;
            emp_idLabel.Text = "emp id:";
            // 
            // emp_idComboBox
            // 
            this.emp_idComboBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.stock_Out_MasterBindingSource, "emp_id", true));
            this.emp_idComboBox.FormattingEnabled = true;
            this.emp_idComboBox.Location = new System.Drawing.Point(92, 62);
            this.emp_idComboBox.Name = "emp_idComboBox";
            this.emp_idComboBox.Size = new System.Drawing.Size(200, 21);
            this.emp_idComboBox.TabIndex = 4;
            // 
            // cat_idLabel
            // 
            cat_idLabel.AutoSize = true;
            cat_idLabel.Location = new System.Drawing.Point(15, 92);
            cat_idLabel.Name = "cat_idLabel";
            cat_idLabel.Size = new System.Drawing.Size(36, 13);
            cat_idLabel.TabIndex = 5;
            cat_idLabel.Text = "cat id:";
            // 
            // cat_idComboBox
            // 
            this.cat_idComboBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.stock_Out_MasterBindingSource, "cat_id", true));
            this.cat_idComboBox.FormattingEnabled = true;
            this.cat_idComboBox.Location = new System.Drawing.Point(92, 89);
            this.cat_idComboBox.Name = "cat_idComboBox";
            this.cat_idComboBox.Size = new System.Drawing.Size(200, 21);
            this.cat_idComboBox.TabIndex = 6;
            // 
            // date_soutLabel
            // 
            date_soutLabel.AutoSize = true;
            date_soutLabel.Location = new System.Drawing.Point(15, 120);
            date_soutLabel.Name = "date_soutLabel";
            date_soutLabel.Size = new System.Drawing.Size(54, 13);
            date_soutLabel.TabIndex = 7;
            date_soutLabel.Text = "date sout:";
            // 
            // date_soutDateTimePicker
            // 
            this.date_soutDateTimePicker.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.stock_Out_MasterBindingSource, "date_sout", true));
            this.date_soutDateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.date_soutDateTimePicker.Location = new System.Drawing.Point(92, 116);
            this.date_soutDateTimePicker.Name = "date_soutDateTimePicker";
            this.date_soutDateTimePicker.Size = new System.Drawing.Size(200, 20);
            this.date_soutDateTimePicker.TabIndex = 8;
            // 
            // stockOutDetailBindingSource
            // 
            this.stockOutDetailBindingSource.DataMember = "FK_StockOutDetail_Stock_Out_Master1";
            this.stockOutDetailBindingSource.DataSource = this.stock_Out_MasterBindingSource;
            // 
            // stockOutDetailTableAdapter
            // 
            this.stockOutDetailTableAdapter.ClearBeforeFill = true;
            // 
            // stockOutDetailDataGridView
            // 
            this.stockOutDetailDataGridView.AutoGenerateColumns = false;
            this.stockOutDetailDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.stockOutDetailDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5});
            this.stockOutDetailDataGridView.DataSource = this.stockOutDetailBindingSource;
            this.stockOutDetailDataGridView.Location = new System.Drawing.Point(38, 177);
            this.stockOutDetailDataGridView.Name = "stockOutDetailDataGridView";
            this.stockOutDetailDataGridView.Size = new System.Drawing.Size(593, 220);
            this.stockOutDetailDataGridView.TabIndex = 9;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "StockOutDetailID";
            this.dataGridViewTextBoxColumn1.HeaderText = "StockOutDetailID";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "StockMasterID";
            this.dataGridViewTextBoxColumn2.HeaderText = "StockMasterID";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "itemID";
            this.dataGridViewTextBoxColumn3.HeaderText = "itemID";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "itemQty";
            this.dataGridViewTextBoxColumn4.HeaderText = "itemQty";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "itemDesc";
            this.dataGridViewTextBoxColumn5.HeaderText = "itemDesc";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            // 
            // FormMDSout
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(794, 471);
            this.Controls.Add(this.stockOutDetailDataGridView);
            this.Controls.Add(master_out_idLabel);
            this.Controls.Add(this.master_out_idTextBox);
            this.Controls.Add(emp_idLabel);
            this.Controls.Add(this.emp_idComboBox);
            this.Controls.Add(cat_idLabel);
            this.Controls.Add(this.cat_idComboBox);
            this.Controls.Add(date_soutLabel);
            this.Controls.Add(this.date_soutDateTimePicker);
            this.Controls.Add(this.stock_Out_MasterBindingNavigator);
            this.Name = "FormMDSout";
            this.Text = "FormMDSout";
            this.Load += new System.EventHandler(this.FormMDSout_Load);
            ((System.ComponentModel.ISupportInitialize)(this.sastockDataSet_OutMasterDetail)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.stock_Out_MasterBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.stock_Out_MasterBindingNavigator)).EndInit();
            this.stock_Out_MasterBindingNavigator.ResumeLayout(false);
            this.stock_Out_MasterBindingNavigator.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.stockOutDetailBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.stockOutDetailDataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private sastockDataSet_OutMasterDetail sastockDataSet_OutMasterDetail;
        private System.Windows.Forms.BindingSource stock_Out_MasterBindingSource;
        private sastockDataSet_OutMasterDetailTableAdapters.Stock_Out_MasterTableAdapter stock_Out_MasterTableAdapter;
        private sastockDataSet_OutMasterDetailTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.BindingNavigator stock_Out_MasterBindingNavigator;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton stock_Out_MasterBindingNavigatorSaveItem;
        private sastockDataSet_OutMasterDetailTableAdapters.StockOutDetailTableAdapter stockOutDetailTableAdapter;
        private System.Windows.Forms.TextBox master_out_idTextBox;
        private System.Windows.Forms.ComboBox emp_idComboBox;
        private System.Windows.Forms.ComboBox cat_idComboBox;
        private System.Windows.Forms.DateTimePicker date_soutDateTimePicker;
        private System.Windows.Forms.BindingSource stockOutDetailBindingSource;
        private System.Windows.Forms.DataGridView stockOutDetailDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
    }
}