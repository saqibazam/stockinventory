﻿namespace SA_StockInventory
{
    partial class Form_Employees
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label empIDLabel;
            System.Windows.Forms.Label empNameLabel;
            System.Windows.Forms.Label activeLabel;
            System.Windows.Forms.Label nICLabel;
            System.Windows.Forms.Label ageLabel;
            System.Windows.Forms.Label genderLabel;
            System.Windows.Forms.Label fatherNameLabel;
            System.Windows.Forms.Label cAddLabel;
            System.Windows.Forms.Label cCityLabel;
            System.Windows.Forms.Label phoneNoLabel;
            System.Windows.Forms.Label cellNoLabel;
            System.Windows.Forms.Label emailLabel;
            System.Windows.Forms.Label empStatusLabel;
            System.Windows.Forms.Label designationCodeLabel;
            System.Windows.Forms.Label deptCodeLabel;
            System.Windows.Forms.Label branchCodeLabel;
            this.sastockDataSetEmployee = new SA_StockInventory.sastockDataSetEmployee();
            this.employeesBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.employeesTableAdapter = new SA_StockInventory.sastockDataSetEmployeeTableAdapters.EmployeesTableAdapter();
            this.tableAdapterManager = new SA_StockInventory.sastockDataSetEmployeeTableAdapters.TableAdapterManager();
            this.departmentTableAdapter = new SA_StockInventory.sastockDataSetEmployeeTableAdapters.DepartmentTableAdapter();
            this.designationTableAdapter = new SA_StockInventory.sastockDataSetEmployeeTableAdapters.DesignationTableAdapter();
            this.empIDTextBox = new System.Windows.Forms.TextBox();
            this.empNameTextBox = new System.Windows.Forms.TextBox();
            this.activeCheckBox = new System.Windows.Forms.CheckBox();
            this.nICTextBox = new System.Windows.Forms.TextBox();
            this.ageTextBox = new System.Windows.Forms.TextBox();
            this.genderTextBox = new System.Windows.Forms.TextBox();
            this.fatherNameTextBox = new System.Windows.Forms.TextBox();
            this.cAddTextBox = new System.Windows.Forms.TextBox();
            this.cCityTextBox = new System.Windows.Forms.TextBox();
            this.phoneNoTextBox = new System.Windows.Forms.TextBox();
            this.cellNoTextBox = new System.Windows.Forms.TextBox();
            this.emailTextBox = new System.Windows.Forms.TextBox();
            this.empStatusTextBox = new System.Windows.Forms.TextBox();
            this.designationCodeComboBox = new System.Windows.Forms.ComboBox();
            this.designationBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.deptCodeComboBox = new System.Windows.Forms.ComboBox();
            this.departmentBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.branchCodeComboBox = new System.Windows.Forms.ComboBox();
            this.branchBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.sastockDataSetBranch = new SA_StockInventory.sastockDataSetBranch();
            this.employeesDataGridView = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.EmpName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Active = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.NIC = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Age = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Gender = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.FatherName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CAdd = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CCity = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PhoneNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CellNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Email = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.EmpStatus = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DesignationCode = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.DeptCode = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.BranchCode = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.activeDataGridViewCheckBoxColumn = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.buttonNew = new System.Windows.Forms.Button();
            this.button_Delete = new System.Windows.Forms.Button();
            this.button_Update = new System.Windows.Forms.Button();
            this.button_Insert = new System.Windows.Forms.Button();
            this.branchTableAdapter = new SA_StockInventory.sastockDataSetBranchTableAdapters.BranchTableAdapter();
            empIDLabel = new System.Windows.Forms.Label();
            empNameLabel = new System.Windows.Forms.Label();
            activeLabel = new System.Windows.Forms.Label();
            nICLabel = new System.Windows.Forms.Label();
            ageLabel = new System.Windows.Forms.Label();
            genderLabel = new System.Windows.Forms.Label();
            fatherNameLabel = new System.Windows.Forms.Label();
            cAddLabel = new System.Windows.Forms.Label();
            cCityLabel = new System.Windows.Forms.Label();
            phoneNoLabel = new System.Windows.Forms.Label();
            cellNoLabel = new System.Windows.Forms.Label();
            emailLabel = new System.Windows.Forms.Label();
            empStatusLabel = new System.Windows.Forms.Label();
            designationCodeLabel = new System.Windows.Forms.Label();
            deptCodeLabel = new System.Windows.Forms.Label();
            branchCodeLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.sastockDataSetEmployee)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.employeesBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.designationBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.departmentBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.branchBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sastockDataSetBranch)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.employeesDataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // empIDLabel
            // 
            empIDLabel.AutoSize = true;
            empIDLabel.Location = new System.Drawing.Point(24, 35);
            empIDLabel.Name = "empIDLabel";
            empIDLabel.Size = new System.Drawing.Size(45, 13);
            empIDLabel.TabIndex = 1;
            empIDLabel.Text = "Emp ID:";
            // 
            // empNameLabel
            // 
            empNameLabel.AutoSize = true;
            empNameLabel.Location = new System.Drawing.Point(24, 61);
            empNameLabel.Name = "empNameLabel";
            empNameLabel.Size = new System.Drawing.Size(62, 13);
            empNameLabel.TabIndex = 3;
            empNameLabel.Text = "Emp Name:";
            // 
            // activeLabel
            // 
            activeLabel.AutoSize = true;
            activeLabel.Location = new System.Drawing.Point(24, 89);
            activeLabel.Name = "activeLabel";
            activeLabel.Size = new System.Drawing.Size(53, 13);
            activeLabel.TabIndex = 5;
            activeLabel.Text = "Deactive:";
            // 
            // nICLabel
            // 
            nICLabel.AutoSize = true;
            nICLabel.Location = new System.Drawing.Point(24, 117);
            nICLabel.Name = "nICLabel";
            nICLabel.Size = new System.Drawing.Size(28, 13);
            nICLabel.TabIndex = 7;
            nICLabel.Text = "NIC:";
            // 
            // ageLabel
            // 
            ageLabel.AutoSize = true;
            ageLabel.Location = new System.Drawing.Point(24, 143);
            ageLabel.Name = "ageLabel";
            ageLabel.Size = new System.Drawing.Size(29, 13);
            ageLabel.TabIndex = 9;
            ageLabel.Text = "Age:";
            // 
            // genderLabel
            // 
            genderLabel.AutoSize = true;
            genderLabel.Location = new System.Drawing.Point(24, 169);
            genderLabel.Name = "genderLabel";
            genderLabel.Size = new System.Drawing.Size(45, 13);
            genderLabel.TabIndex = 11;
            genderLabel.Text = "Gender:";
            // 
            // fatherNameLabel
            // 
            fatherNameLabel.AutoSize = true;
            fatherNameLabel.Location = new System.Drawing.Point(24, 195);
            fatherNameLabel.Name = "fatherNameLabel";
            fatherNameLabel.Size = new System.Drawing.Size(71, 13);
            fatherNameLabel.TabIndex = 13;
            fatherNameLabel.Text = "Father Name:";
            // 
            // cAddLabel
            // 
            cAddLabel.AutoSize = true;
            cAddLabel.Location = new System.Drawing.Point(24, 221);
            cAddLabel.Name = "cAddLabel";
            cAddLabel.Size = new System.Drawing.Size(36, 13);
            cAddLabel.TabIndex = 15;
            cAddLabel.Text = "CAdd:";
            // 
            // cCityLabel
            // 
            cCityLabel.AutoSize = true;
            cCityLabel.Location = new System.Drawing.Point(24, 247);
            cCityLabel.Name = "cCityLabel";
            cCityLabel.Size = new System.Drawing.Size(34, 13);
            cCityLabel.TabIndex = 17;
            cCityLabel.Text = "CCity:";
            // 
            // phoneNoLabel
            // 
            phoneNoLabel.AutoSize = true;
            phoneNoLabel.Location = new System.Drawing.Point(423, 34);
            phoneNoLabel.Name = "phoneNoLabel";
            phoneNoLabel.Size = new System.Drawing.Size(58, 13);
            phoneNoLabel.TabIndex = 19;
            phoneNoLabel.Text = "Phone No:";
            // 
            // cellNoLabel
            // 
            cellNoLabel.AutoSize = true;
            cellNoLabel.Location = new System.Drawing.Point(423, 60);
            cellNoLabel.Name = "cellNoLabel";
            cellNoLabel.Size = new System.Drawing.Size(44, 13);
            cellNoLabel.TabIndex = 21;
            cellNoLabel.Text = "Cell No:";
            // 
            // emailLabel
            // 
            emailLabel.AutoSize = true;
            emailLabel.Location = new System.Drawing.Point(423, 86);
            emailLabel.Name = "emailLabel";
            emailLabel.Size = new System.Drawing.Size(35, 13);
            emailLabel.TabIndex = 23;
            emailLabel.Text = "Email:";
            // 
            // empStatusLabel
            // 
            empStatusLabel.AutoSize = true;
            empStatusLabel.Location = new System.Drawing.Point(423, 112);
            empStatusLabel.Name = "empStatusLabel";
            empStatusLabel.Size = new System.Drawing.Size(64, 13);
            empStatusLabel.TabIndex = 25;
            empStatusLabel.Text = "Emp Status:";
            // 
            // designationCodeLabel
            // 
            designationCodeLabel.AutoSize = true;
            designationCodeLabel.Location = new System.Drawing.Point(423, 138);
            designationCodeLabel.Name = "designationCodeLabel";
            designationCodeLabel.Size = new System.Drawing.Size(94, 13);
            designationCodeLabel.TabIndex = 27;
            designationCodeLabel.Text = "Designation Code:";
            // 
            // deptCodeLabel
            // 
            deptCodeLabel.AutoSize = true;
            deptCodeLabel.Location = new System.Drawing.Point(423, 165);
            deptCodeLabel.Name = "deptCodeLabel";
            deptCodeLabel.Size = new System.Drawing.Size(61, 13);
            deptCodeLabel.TabIndex = 29;
            deptCodeLabel.Text = "Dept Code:";
            // 
            // branchCodeLabel
            // 
            branchCodeLabel.AutoSize = true;
            branchCodeLabel.Location = new System.Drawing.Point(423, 192);
            branchCodeLabel.Name = "branchCodeLabel";
            branchCodeLabel.Size = new System.Drawing.Size(72, 13);
            branchCodeLabel.TabIndex = 31;
            branchCodeLabel.Text = "Branch Code:";
            // 
            // sastockDataSetEmployee
            // 
            this.sastockDataSetEmployee.DataSetName = "sastockDataSetEmployee";
            this.sastockDataSetEmployee.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // employeesBindingSource
            // 
            this.employeesBindingSource.DataMember = "Employees";
            this.employeesBindingSource.DataSource = this.sastockDataSetEmployee;
            // 
            // employeesTableAdapter
            // 
            this.employeesTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.BranchTableAdapter = null;
            this.tableAdapterManager.DepartmentTableAdapter = this.departmentTableAdapter;
            this.tableAdapterManager.DesignationTableAdapter = this.designationTableAdapter;
            this.tableAdapterManager.EmployeesTableAdapter = this.employeesTableAdapter;
            this.tableAdapterManager.UpdateOrder = SA_StockInventory.sastockDataSetEmployeeTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // departmentTableAdapter
            // 
            this.departmentTableAdapter.ClearBeforeFill = true;
            // 
            // designationTableAdapter
            // 
            this.designationTableAdapter.ClearBeforeFill = true;
            // 
            // empIDTextBox
            // 
            this.empIDTextBox.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.empIDTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.employeesBindingSource, "EmpID", true));
            this.empIDTextBox.Enabled = false;
            this.empIDTextBox.Location = new System.Drawing.Point(124, 32);
            this.empIDTextBox.Name = "empIDTextBox";
            this.empIDTextBox.Size = new System.Drawing.Size(64, 20);
            this.empIDTextBox.TabIndex = 2;
            // 
            // empNameTextBox
            // 
            this.empNameTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.employeesBindingSource, "EmpName", true));
            this.empNameTextBox.Location = new System.Drawing.Point(124, 58);
            this.empNameTextBox.Name = "empNameTextBox";
            this.empNameTextBox.Size = new System.Drawing.Size(275, 20);
            this.empNameTextBox.TabIndex = 4;
            // 
            // activeCheckBox
            // 
            this.activeCheckBox.DataBindings.Add(new System.Windows.Forms.Binding("CheckState", this.employeesBindingSource, "Active", true));
            this.activeCheckBox.Location = new System.Drawing.Point(124, 84);
            this.activeCheckBox.Name = "activeCheckBox";
            this.activeCheckBox.Size = new System.Drawing.Size(121, 24);
            this.activeCheckBox.TabIndex = 6;
            this.activeCheckBox.Text = "Status";
            this.activeCheckBox.UseVisualStyleBackColor = true;
            // 
            // nICTextBox
            // 
            this.nICTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.employeesBindingSource, "NIC", true));
            this.nICTextBox.Location = new System.Drawing.Point(124, 114);
            this.nICTextBox.Name = "nICTextBox";
            this.nICTextBox.Size = new System.Drawing.Size(155, 20);
            this.nICTextBox.TabIndex = 8;
            // 
            // ageTextBox
            // 
            this.ageTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.employeesBindingSource, "Age", true));
            this.ageTextBox.Location = new System.Drawing.Point(124, 140);
            this.ageTextBox.Name = "ageTextBox";
            this.ageTextBox.Size = new System.Drawing.Size(64, 20);
            this.ageTextBox.TabIndex = 10;
            // 
            // genderTextBox
            // 
            this.genderTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.employeesBindingSource, "Gender", true));
            this.genderTextBox.Location = new System.Drawing.Point(124, 166);
            this.genderTextBox.Name = "genderTextBox";
            this.genderTextBox.Size = new System.Drawing.Size(64, 20);
            this.genderTextBox.TabIndex = 12;
            // 
            // fatherNameTextBox
            // 
            this.fatherNameTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.employeesBindingSource, "FatherName", true));
            this.fatherNameTextBox.Location = new System.Drawing.Point(124, 192);
            this.fatherNameTextBox.Name = "fatherNameTextBox";
            this.fatherNameTextBox.Size = new System.Drawing.Size(275, 20);
            this.fatherNameTextBox.TabIndex = 14;
            // 
            // cAddTextBox
            // 
            this.cAddTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.employeesBindingSource, "CAdd", true));
            this.cAddTextBox.Location = new System.Drawing.Point(124, 218);
            this.cAddTextBox.Name = "cAddTextBox";
            this.cAddTextBox.Size = new System.Drawing.Size(275, 20);
            this.cAddTextBox.TabIndex = 16;
            // 
            // cCityTextBox
            // 
            this.cCityTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.employeesBindingSource, "CCity", true));
            this.cCityTextBox.Location = new System.Drawing.Point(124, 244);
            this.cCityTextBox.Name = "cCityTextBox";
            this.cCityTextBox.Size = new System.Drawing.Size(121, 20);
            this.cCityTextBox.TabIndex = 18;
            // 
            // phoneNoTextBox
            // 
            this.phoneNoTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.employeesBindingSource, "PhoneNo", true));
            this.phoneNoTextBox.Location = new System.Drawing.Point(523, 31);
            this.phoneNoTextBox.Name = "phoneNoTextBox";
            this.phoneNoTextBox.Size = new System.Drawing.Size(121, 20);
            this.phoneNoTextBox.TabIndex = 20;
            // 
            // cellNoTextBox
            // 
            this.cellNoTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.employeesBindingSource, "CellNo", true));
            this.cellNoTextBox.Location = new System.Drawing.Point(523, 57);
            this.cellNoTextBox.Name = "cellNoTextBox";
            this.cellNoTextBox.Size = new System.Drawing.Size(121, 20);
            this.cellNoTextBox.TabIndex = 22;
            // 
            // emailTextBox
            // 
            this.emailTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.employeesBindingSource, "Email", true));
            this.emailTextBox.Location = new System.Drawing.Point(523, 83);
            this.emailTextBox.Name = "emailTextBox";
            this.emailTextBox.Size = new System.Drawing.Size(121, 20);
            this.emailTextBox.TabIndex = 24;
            // 
            // empStatusTextBox
            // 
            this.empStatusTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.employeesBindingSource, "EmpStatus", true));
            this.empStatusTextBox.Location = new System.Drawing.Point(523, 109);
            this.empStatusTextBox.Name = "empStatusTextBox";
            this.empStatusTextBox.Size = new System.Drawing.Size(121, 20);
            this.empStatusTextBox.TabIndex = 26;
            // 
            // designationCodeComboBox
            // 
            this.designationCodeComboBox.DataSource = this.designationBindingSource;
            this.designationCodeComboBox.DisplayMember = "Description";
            this.designationCodeComboBox.FormattingEnabled = true;
            this.designationCodeComboBox.Location = new System.Drawing.Point(523, 135);
            this.designationCodeComboBox.Name = "designationCodeComboBox";
            this.designationCodeComboBox.Size = new System.Drawing.Size(121, 21);
            this.designationCodeComboBox.TabIndex = 28;
            this.designationCodeComboBox.ValueMember = "DesignationCode";
            // 
            // designationBindingSource
            // 
            this.designationBindingSource.DataMember = "Designation";
            this.designationBindingSource.DataSource = this.sastockDataSetEmployee;
            // 
            // deptCodeComboBox
            // 
            this.deptCodeComboBox.DataSource = this.departmentBindingSource;
            this.deptCodeComboBox.DisplayMember = "department_name";
            this.deptCodeComboBox.FormattingEnabled = true;
            this.deptCodeComboBox.Location = new System.Drawing.Point(523, 162);
            this.deptCodeComboBox.Name = "deptCodeComboBox";
            this.deptCodeComboBox.Size = new System.Drawing.Size(121, 21);
            this.deptCodeComboBox.TabIndex = 30;
            this.deptCodeComboBox.ValueMember = "department_id";
            // 
            // departmentBindingSource
            // 
            this.departmentBindingSource.DataMember = "Department";
            this.departmentBindingSource.DataSource = this.sastockDataSetEmployee;
            // 
            // branchCodeComboBox
            // 
            this.branchCodeComboBox.DataSource = this.branchBindingSource;
            this.branchCodeComboBox.DisplayMember = "branch_name";
            this.branchCodeComboBox.FormattingEnabled = true;
            this.branchCodeComboBox.Location = new System.Drawing.Point(523, 189);
            this.branchCodeComboBox.Name = "branchCodeComboBox";
            this.branchCodeComboBox.Size = new System.Drawing.Size(121, 21);
            this.branchCodeComboBox.TabIndex = 32;
            this.branchCodeComboBox.ValueMember = "branch_id";
            this.branchCodeComboBox.SelectedIndexChanged += new System.EventHandler(this.branchCodeComboBox_SelectedIndexChanged);
            // 
            // branchBindingSource
            // 
            this.branchBindingSource.DataMember = "Branch";
            this.branchBindingSource.DataSource = this.sastockDataSetBranch;
            // 
            // sastockDataSetBranch
            // 
            this.sastockDataSetBranch.DataSetName = "sastockDataSetBranch";
            this.sastockDataSetBranch.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // employeesDataGridView
            // 
            this.employeesDataGridView.AllowUserToAddRows = false;
            this.employeesDataGridView.AllowUserToDeleteRows = false;
            this.employeesDataGridView.AllowUserToResizeColumns = false;
            this.employeesDataGridView.AllowUserToResizeRows = false;
            this.employeesDataGridView.AutoGenerateColumns = false;
            this.employeesDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.employeesDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.EmpName,
            this.Active,
            this.NIC,
            this.Age,
            this.Gender,
            this.FatherName,
            this.CAdd,
            this.CCity,
            this.PhoneNo,
            this.CellNo,
            this.Email,
            this.EmpStatus,
            this.DesignationCode,
            this.DeptCode,
            this.BranchCode,
            this.activeDataGridViewCheckBoxColumn});
            this.employeesDataGridView.DataSource = this.employeesBindingSource;
            this.employeesDataGridView.Location = new System.Drawing.Point(27, 335);
            this.employeesDataGridView.Name = "employeesDataGridView";
            this.employeesDataGridView.ReadOnly = true;
            this.employeesDataGridView.Size = new System.Drawing.Size(629, 193);
            this.employeesDataGridView.TabIndex = 32;
            this.employeesDataGridView.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.employeesDataGridView_CellContentClick);
            this.employeesDataGridView.RowHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.employeesDataGridView_RowHeaderMouseClick);
            // 
            // Column1
            // 
            this.Column1.DataPropertyName = "EmpID";
            this.Column1.HeaderText = "EmpID";
            this.Column1.Name = "Column1";
            this.Column1.ReadOnly = true;
            // 
            // EmpName
            // 
            this.EmpName.DataPropertyName = "EmpName";
            this.EmpName.HeaderText = "EmpName";
            this.EmpName.Name = "EmpName";
            this.EmpName.ReadOnly = true;
            // 
            // Active
            // 
            this.Active.DataPropertyName = "Active";
            this.Active.HeaderText = "Deactive";
            this.Active.Name = "Active";
            this.Active.ReadOnly = true;
            // 
            // NIC
            // 
            this.NIC.DataPropertyName = "NIC";
            this.NIC.HeaderText = "NIC";
            this.NIC.Name = "NIC";
            this.NIC.ReadOnly = true;
            // 
            // Age
            // 
            this.Age.DataPropertyName = "Age";
            this.Age.HeaderText = "Age";
            this.Age.Name = "Age";
            this.Age.ReadOnly = true;
            // 
            // Gender
            // 
            this.Gender.DataPropertyName = "Gender";
            this.Gender.HeaderText = "Gender";
            this.Gender.Name = "Gender";
            this.Gender.ReadOnly = true;
            // 
            // FatherName
            // 
            this.FatherName.DataPropertyName = "FatherName";
            this.FatherName.HeaderText = "FatherName";
            this.FatherName.Name = "FatherName";
            this.FatherName.ReadOnly = true;
            // 
            // CAdd
            // 
            this.CAdd.DataPropertyName = "CAdd";
            this.CAdd.HeaderText = "CAdd";
            this.CAdd.Name = "CAdd";
            this.CAdd.ReadOnly = true;
            // 
            // CCity
            // 
            this.CCity.DataPropertyName = "CCity";
            this.CCity.HeaderText = "CCity";
            this.CCity.Name = "CCity";
            this.CCity.ReadOnly = true;
            // 
            // PhoneNo
            // 
            this.PhoneNo.DataPropertyName = "PhoneNo";
            this.PhoneNo.HeaderText = "PhoneNo";
            this.PhoneNo.Name = "PhoneNo";
            this.PhoneNo.ReadOnly = true;
            // 
            // CellNo
            // 
            this.CellNo.DataPropertyName = "CellNo";
            this.CellNo.HeaderText = "CellNo";
            this.CellNo.Name = "CellNo";
            this.CellNo.ReadOnly = true;
            // 
            // Email
            // 
            this.Email.DataPropertyName = "Email";
            this.Email.HeaderText = "Email";
            this.Email.Name = "Email";
            this.Email.ReadOnly = true;
            // 
            // EmpStatus
            // 
            this.EmpStatus.DataPropertyName = "EmpStatus";
            this.EmpStatus.HeaderText = "EmpStatus";
            this.EmpStatus.Name = "EmpStatus";
            this.EmpStatus.ReadOnly = true;
            // 
            // DesignationCode
            // 
            this.DesignationCode.DataPropertyName = "DesignationCode";
            this.DesignationCode.DataSource = this.designationBindingSource;
            this.DesignationCode.DisplayMember = "Description";
            this.DesignationCode.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.Nothing;
            this.DesignationCode.HeaderText = "DesignationCode";
            this.DesignationCode.Name = "DesignationCode";
            this.DesignationCode.ReadOnly = true;
            this.DesignationCode.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.DesignationCode.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.DesignationCode.ValueMember = "DesignationCode";
            // 
            // DeptCode
            // 
            this.DeptCode.DataPropertyName = "DeptCode";
            this.DeptCode.DataSource = this.departmentBindingSource;
            this.DeptCode.DisplayMember = "department_name";
            this.DeptCode.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.Nothing;
            this.DeptCode.HeaderText = "DeptCode";
            this.DeptCode.Name = "DeptCode";
            this.DeptCode.ReadOnly = true;
            this.DeptCode.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.DeptCode.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.DeptCode.ValueMember = "department_id";
            // 
            // BranchCode
            // 
            this.BranchCode.DataPropertyName = "BranchCode";
            this.BranchCode.DataSource = this.branchBindingSource;
            this.BranchCode.DisplayMember = "branch_name";
            this.BranchCode.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.Nothing;
            this.BranchCode.HeaderText = "BranchCode";
            this.BranchCode.Name = "BranchCode";
            this.BranchCode.ReadOnly = true;
            this.BranchCode.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.BranchCode.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.BranchCode.ValueMember = "branch_id";
            // 
            // activeDataGridViewCheckBoxColumn
            // 
            this.activeDataGridViewCheckBoxColumn.DataPropertyName = "Active";
            this.activeDataGridViewCheckBoxColumn.HeaderText = "Active";
            this.activeDataGridViewCheckBoxColumn.Name = "activeDataGridViewCheckBoxColumn";
            this.activeDataGridViewCheckBoxColumn.ReadOnly = true;
            // 
            // buttonNew
            // 
            this.buttonNew.Location = new System.Drawing.Point(28, 292);
            this.buttonNew.Name = "buttonNew";
            this.buttonNew.Size = new System.Drawing.Size(75, 23);
            this.buttonNew.TabIndex = 36;
            this.buttonNew.Text = "New";
            this.buttonNew.UseVisualStyleBackColor = true;
            this.buttonNew.Click += new System.EventHandler(this.buttonNew_Click);
            // 
            // button_Delete
            // 
            this.button_Delete.Location = new System.Drawing.Point(370, 292);
            this.button_Delete.Name = "button_Delete";
            this.button_Delete.Size = new System.Drawing.Size(75, 23);
            this.button_Delete.TabIndex = 35;
            this.button_Delete.Text = "Delete";
            this.button_Delete.UseVisualStyleBackColor = true;
            this.button_Delete.Visible = false;
            this.button_Delete.Click += new System.EventHandler(this.button_Delete_Click);
            // 
            // button_Update
            // 
            this.button_Update.Location = new System.Drawing.Point(260, 292);
            this.button_Update.Name = "button_Update";
            this.button_Update.Size = new System.Drawing.Size(75, 23);
            this.button_Update.TabIndex = 34;
            this.button_Update.Text = "Update";
            this.button_Update.UseVisualStyleBackColor = true;
            this.button_Update.Visible = false;
            this.button_Update.Click += new System.EventHandler(this.button_Update_Click);
            // 
            // button_Insert
            // 
            this.button_Insert.Enabled = false;
            this.button_Insert.Location = new System.Drawing.Point(140, 292);
            this.button_Insert.Name = "button_Insert";
            this.button_Insert.Size = new System.Drawing.Size(75, 23);
            this.button_Insert.TabIndex = 33;
            this.button_Insert.Text = "Insert";
            this.button_Insert.UseVisualStyleBackColor = true;
            this.button_Insert.Click += new System.EventHandler(this.button_Insert_Click);
            // 
            // branchTableAdapter
            // 
            this.branchTableAdapter.ClearBeforeFill = true;
            // 
            // Form_Employees
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(687, 540);
            this.Controls.Add(this.buttonNew);
            this.Controls.Add(this.button_Delete);
            this.Controls.Add(this.button_Update);
            this.Controls.Add(this.button_Insert);
            this.Controls.Add(this.employeesDataGridView);
            this.Controls.Add(empIDLabel);
            this.Controls.Add(this.empIDTextBox);
            this.Controls.Add(empNameLabel);
            this.Controls.Add(this.empNameTextBox);
            this.Controls.Add(activeLabel);
            this.Controls.Add(this.activeCheckBox);
            this.Controls.Add(nICLabel);
            this.Controls.Add(this.nICTextBox);
            this.Controls.Add(ageLabel);
            this.Controls.Add(this.ageTextBox);
            this.Controls.Add(genderLabel);
            this.Controls.Add(this.genderTextBox);
            this.Controls.Add(fatherNameLabel);
            this.Controls.Add(this.fatherNameTextBox);
            this.Controls.Add(cAddLabel);
            this.Controls.Add(this.cAddTextBox);
            this.Controls.Add(cCityLabel);
            this.Controls.Add(this.cCityTextBox);
            this.Controls.Add(phoneNoLabel);
            this.Controls.Add(this.phoneNoTextBox);
            this.Controls.Add(cellNoLabel);
            this.Controls.Add(this.cellNoTextBox);
            this.Controls.Add(emailLabel);
            this.Controls.Add(this.emailTextBox);
            this.Controls.Add(empStatusLabel);
            this.Controls.Add(this.empStatusTextBox);
            this.Controls.Add(designationCodeLabel);
            this.Controls.Add(this.designationCodeComboBox);
            this.Controls.Add(deptCodeLabel);
            this.Controls.Add(this.deptCodeComboBox);
            this.Controls.Add(branchCodeLabel);
            this.Controls.Add(this.branchCodeComboBox);
            this.Name = "Form_Employees";
            this.Text = "Employees";
            this.Load += new System.EventHandler(this.Form_Employees_Load);
            ((System.ComponentModel.ISupportInitialize)(this.sastockDataSetEmployee)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.employeesBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.designationBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.departmentBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.branchBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sastockDataSetBranch)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.employeesDataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private sastockDataSetEmployee sastockDataSetEmployee;
        private System.Windows.Forms.BindingSource employeesBindingSource;
        private sastockDataSetEmployeeTableAdapters.EmployeesTableAdapter employeesTableAdapter;
        private sastockDataSetEmployeeTableAdapters.TableAdapterManager tableAdapterManager;
        private sastockDataSetEmployeeTableAdapters.DesignationTableAdapter designationTableAdapter;
        private System.Windows.Forms.TextBox empIDTextBox;
        private System.Windows.Forms.TextBox empNameTextBox;
        private System.Windows.Forms.CheckBox activeCheckBox;
        private System.Windows.Forms.TextBox nICTextBox;
        private System.Windows.Forms.TextBox ageTextBox;
        private System.Windows.Forms.TextBox genderTextBox;
        private System.Windows.Forms.TextBox fatherNameTextBox;
        private System.Windows.Forms.TextBox cAddTextBox;
        private System.Windows.Forms.TextBox cCityTextBox;
        private System.Windows.Forms.TextBox phoneNoTextBox;
        private System.Windows.Forms.TextBox cellNoTextBox;
        private System.Windows.Forms.TextBox emailTextBox;
        private System.Windows.Forms.TextBox empStatusTextBox;
        private System.Windows.Forms.ComboBox designationCodeComboBox;
        private System.Windows.Forms.ComboBox deptCodeComboBox;
        private System.Windows.Forms.ComboBox branchCodeComboBox;
        private System.Windows.Forms.BindingSource designationBindingSource;
        private sastockDataSetEmployeeTableAdapters.DepartmentTableAdapter departmentTableAdapter;
        private System.Windows.Forms.BindingSource departmentBindingSource;
        private System.Windows.Forms.DataGridView employeesDataGridView;
        private System.Windows.Forms.Button buttonNew;
        private System.Windows.Forms.Button button_Delete;
        private System.Windows.Forms.Button button_Update;
        private System.Windows.Forms.Button button_Insert;
        private sastockDataSetBranch sastockDataSetBranch;
        private System.Windows.Forms.BindingSource branchBindingSource;
        private sastockDataSetBranchTableAdapters.BranchTableAdapter branchTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn EmpName;
        private System.Windows.Forms.DataGridViewCheckBoxColumn Active;
        private System.Windows.Forms.DataGridViewTextBoxColumn NIC;
        private System.Windows.Forms.DataGridViewTextBoxColumn Age;
        private System.Windows.Forms.DataGridViewTextBoxColumn Gender;
        private System.Windows.Forms.DataGridViewTextBoxColumn FatherName;
        private System.Windows.Forms.DataGridViewTextBoxColumn CAdd;
        private System.Windows.Forms.DataGridViewTextBoxColumn CCity;
        private System.Windows.Forms.DataGridViewTextBoxColumn PhoneNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn CellNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn Email;
        private System.Windows.Forms.DataGridViewTextBoxColumn EmpStatus;
        private System.Windows.Forms.DataGridViewComboBoxColumn DesignationCode;
        private System.Windows.Forms.DataGridViewComboBoxColumn DeptCode;
        private System.Windows.Forms.DataGridViewComboBoxColumn BranchCode;
        private System.Windows.Forms.DataGridViewCheckBoxColumn activeDataGridViewCheckBoxColumn;
    }
}