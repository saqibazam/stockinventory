﻿namespace SA_StockInventory
{


    partial class sastockDataSetStock_Out
    {
    }
}

namespace SA_StockInventory.sastockDataSetStock_OutTableAdapters {
    
    
    public partial class Stock_outTableAdapter {
    }
}
