﻿namespace SA_StockInventory
{
    partial class FormDepartment
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label department_idLabel;
            System.Windows.Forms.Label department_nameLabel;
            this.department_idTextBox = new System.Windows.Forms.TextBox();
            this.department_nameTextBox = new System.Windows.Forms.TextBox();
            this.sastockDataSetDepartment = new SA_StockInventory.sastockDataSetDepartment();
            this.departmentBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.departmentTableAdapter = new SA_StockInventory.sastockDataSetDepartmentTableAdapters.DepartmentTableAdapter();
            this.tableAdapterManager = new SA_StockInventory.sastockDataSetDepartmentTableAdapters.TableAdapterManager();
            this.departmentDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.buttonNew = new System.Windows.Forms.Button();
            this.button_Delete = new System.Windows.Forms.Button();
            this.button_Update = new System.Windows.Forms.Button();
            this.button_Insert = new System.Windows.Forms.Button();
            department_idLabel = new System.Windows.Forms.Label();
            department_nameLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.sastockDataSetDepartment)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.departmentBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.departmentDataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // department_idLabel
            // 
            department_idLabel.AutoSize = true;
            department_idLabel.Location = new System.Drawing.Point(30, 51);
            department_idLabel.Name = "department_idLabel";
            department_idLabel.Size = new System.Drawing.Size(77, 13);
            department_idLabel.TabIndex = 1;
            department_idLabel.Text = "Department Id:";
            // 
            // department_nameLabel
            // 
            department_nameLabel.AutoSize = true;
            department_nameLabel.Location = new System.Drawing.Point(30, 77);
            department_nameLabel.Name = "department_nameLabel";
            department_nameLabel.Size = new System.Drawing.Size(96, 13);
            department_nameLabel.TabIndex = 3;
            department_nameLabel.Text = "Department Name:";
            // 
            // department_idTextBox
            // 
            this.department_idTextBox.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.department_idTextBox.Enabled = false;
            this.department_idTextBox.Location = new System.Drawing.Point(128, 48);
            this.department_idTextBox.Name = "department_idTextBox";
            this.department_idTextBox.Size = new System.Drawing.Size(63, 20);
            this.department_idTextBox.TabIndex = 2;
            // 
            // department_nameTextBox
            // 
            this.department_nameTextBox.Location = new System.Drawing.Point(128, 74);
            this.department_nameTextBox.Name = "department_nameTextBox";
            this.department_nameTextBox.Size = new System.Drawing.Size(239, 20);
            this.department_nameTextBox.TabIndex = 4;
            // 
            // sastockDataSetDepartment
            // 
            this.sastockDataSetDepartment.DataSetName = "sastockDataSetDepartment";
            this.sastockDataSetDepartment.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // departmentBindingSource
            // 
            this.departmentBindingSource.DataMember = "Department";
            this.departmentBindingSource.DataSource = this.sastockDataSetDepartment;
            // 
            // departmentTableAdapter
            // 
            this.departmentTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.DepartmentTableAdapter = this.departmentTableAdapter;
            this.tableAdapterManager.UpdateOrder = SA_StockInventory.sastockDataSetDepartmentTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // departmentDataGridView
            // 
            this.departmentDataGridView.AllowUserToAddRows = false;
            this.departmentDataGridView.AllowUserToDeleteRows = false;
            this.departmentDataGridView.AllowUserToResizeColumns = false;
            this.departmentDataGridView.AllowUserToResizeRows = false;
            this.departmentDataGridView.AutoGenerateColumns = false;
            this.departmentDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.departmentDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2});
            this.departmentDataGridView.DataSource = this.departmentBindingSource;
            this.departmentDataGridView.Location = new System.Drawing.Point(33, 207);
            this.departmentDataGridView.Name = "departmentDataGridView";
            this.departmentDataGridView.ReadOnly = true;
            this.departmentDataGridView.Size = new System.Drawing.Size(416, 107);
            this.departmentDataGridView.TabIndex = 5;
            this.departmentDataGridView.RowHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.departmentDataGridView_RowHeaderMouseClick);
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "department_id";
            this.dataGridViewTextBoxColumn1.HeaderText = "Department ID";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "department_name";
            this.dataGridViewTextBoxColumn2.HeaderText = "Department Name";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            this.dataGridViewTextBoxColumn2.Width = 240;
            // 
            // buttonNew
            // 
            this.buttonNew.Location = new System.Drawing.Point(32, 132);
            this.buttonNew.Name = "buttonNew";
            this.buttonNew.Size = new System.Drawing.Size(75, 23);
            this.buttonNew.TabIndex = 19;
            this.buttonNew.Text = "New";
            this.buttonNew.UseVisualStyleBackColor = true;
            this.buttonNew.Click += new System.EventHandler(this.buttonNew_Click);
            // 
            // button_Delete
            // 
            this.button_Delete.Location = new System.Drawing.Point(374, 132);
            this.button_Delete.Name = "button_Delete";
            this.button_Delete.Size = new System.Drawing.Size(75, 23);
            this.button_Delete.TabIndex = 18;
            this.button_Delete.Text = "Delete";
            this.button_Delete.UseVisualStyleBackColor = true;
            this.button_Delete.Visible = false;
            this.button_Delete.Click += new System.EventHandler(this.button_Delete_Click);
            // 
            // button_Update
            // 
            this.button_Update.Location = new System.Drawing.Point(264, 132);
            this.button_Update.Name = "button_Update";
            this.button_Update.Size = new System.Drawing.Size(75, 23);
            this.button_Update.TabIndex = 17;
            this.button_Update.Text = "Update";
            this.button_Update.UseVisualStyleBackColor = true;
            this.button_Update.Visible = false;
            this.button_Update.Click += new System.EventHandler(this.button_Update_Click);
            // 
            // button_Insert
            // 
            this.button_Insert.Enabled = false;
            this.button_Insert.Location = new System.Drawing.Point(144, 132);
            this.button_Insert.Name = "button_Insert";
            this.button_Insert.Size = new System.Drawing.Size(75, 23);
            this.button_Insert.TabIndex = 16;
            this.button_Insert.Text = "Insert";
            this.button_Insert.UseVisualStyleBackColor = true;
            this.button_Insert.Click += new System.EventHandler(this.button_Insert_Click);
            // 
            // FormDepartment
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(490, 457);
            this.Controls.Add(this.buttonNew);
            this.Controls.Add(this.button_Delete);
            this.Controls.Add(this.button_Update);
            this.Controls.Add(this.button_Insert);
            this.Controls.Add(this.departmentDataGridView);
            this.Controls.Add(department_idLabel);
            this.Controls.Add(this.department_idTextBox);
            this.Controls.Add(department_nameLabel);
            this.Controls.Add(this.department_nameTextBox);
            this.Name = "FormDepartment";
            this.Text = "Department";
            this.Load += new System.EventHandler(this.FormDepartment_Load);
            ((System.ComponentModel.ISupportInitialize)(this.sastockDataSetDepartment)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.departmentBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.departmentDataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox department_idTextBox;
        private System.Windows.Forms.TextBox department_nameTextBox;
        private sastockDataSetDepartment sastockDataSetDepartment;
        private System.Windows.Forms.BindingSource departmentBindingSource;
        private sastockDataSetDepartmentTableAdapters.DepartmentTableAdapter departmentTableAdapter;
        private sastockDataSetDepartmentTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.DataGridView departmentDataGridView;
        private System.Windows.Forms.Button buttonNew;
        private System.Windows.Forms.Button button_Delete;
        private System.Windows.Forms.Button button_Update;
        private System.Windows.Forms.Button button_Insert;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
    }
}