﻿namespace SA_StockInventory
{
    partial class FormItems
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label items_idLabel;
            System.Windows.Forms.Label items_nameLabel;
            System.Windows.Forms.Label items_descLabel;
            System.Windows.Forms.Label items_sizeLabel;
            System.Windows.Forms.Label category_idLabel;
            this.items_idTextBox = new System.Windows.Forms.TextBox();
            this.items_nameTextBox = new System.Windows.Forms.TextBox();
            this.items_descTextBox = new System.Windows.Forms.TextBox();
            this.items_sizeTextBox = new System.Windows.Forms.TextBox();
            this.CatogaryComboBox = new System.Windows.Forms.ComboBox();
            this.categoryBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.sastockDataSetCategory = new SA_StockInventory.sastockDataSetCategory();
            this.dataGridViewItems = new System.Windows.Forms.DataGridView();
            this.itemsidDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.itemsnameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.itemsdescDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.itemssizeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.category_id = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.entrydateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.itemsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.itemsDataSet = new SA_StockInventory.ItemsDataSet();
            this.buttonNew = new System.Windows.Forms.Button();
            this.button_Delete = new System.Windows.Forms.Button();
            this.button_Update = new System.Windows.Forms.Button();
            this.button_Insert = new System.Windows.Forms.Button();
            this.categoryTableAdapter = new SA_StockInventory.sastockDataSetCategoryTableAdapters.CategoryTableAdapter();
            this.itemsTableAdapter = new SA_StockInventory.ItemsDataSetTableAdapters.ItemsTableAdapter();
            items_idLabel = new System.Windows.Forms.Label();
            items_nameLabel = new System.Windows.Forms.Label();
            items_descLabel = new System.Windows.Forms.Label();
            items_sizeLabel = new System.Windows.Forms.Label();
            category_idLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.categoryBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sastockDataSetCategory)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewItems)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.itemsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.itemsDataSet)).BeginInit();
            this.SuspendLayout();
            // 
            // items_idLabel
            // 
            items_idLabel.AutoSize = true;
            items_idLabel.Location = new System.Drawing.Point(22, 37);
            items_idLabel.Name = "items_idLabel";
            items_idLabel.Size = new System.Drawing.Size(49, 13);
            items_idLabel.TabIndex = 1;
            items_idLabel.Text = "Items ID:";
            // 
            // items_nameLabel
            // 
            items_nameLabel.AutoSize = true;
            items_nameLabel.Location = new System.Drawing.Point(22, 63);
            items_nameLabel.Name = "items_nameLabel";
            items_nameLabel.Size = new System.Drawing.Size(66, 13);
            items_nameLabel.TabIndex = 3;
            items_nameLabel.Text = "Items Name:";
            // 
            // items_descLabel
            // 
            items_descLabel.AutoSize = true;
            items_descLabel.Location = new System.Drawing.Point(22, 89);
            items_descLabel.Name = "items_descLabel";
            items_descLabel.Size = new System.Drawing.Size(63, 13);
            items_descLabel.TabIndex = 5;
            items_descLabel.Text = "Items Desc:";
            // 
            // items_sizeLabel
            // 
            items_sizeLabel.AutoSize = true;
            items_sizeLabel.Location = new System.Drawing.Point(22, 115);
            items_sizeLabel.Name = "items_sizeLabel";
            items_sizeLabel.Size = new System.Drawing.Size(58, 13);
            items_sizeLabel.TabIndex = 7;
            items_sizeLabel.Text = "Items Size:";
            // 
            // category_idLabel
            // 
            category_idLabel.AutoSize = true;
            category_idLabel.Location = new System.Drawing.Point(22, 141);
            category_idLabel.Name = "category_idLabel";
            category_idLabel.Size = new System.Drawing.Size(52, 13);
            category_idLabel.TabIndex = 9;
            category_idLabel.Text = "Category:";
            // 
            // items_idTextBox
            // 
            this.items_idTextBox.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.items_idTextBox.Enabled = false;
            this.items_idTextBox.Location = new System.Drawing.Point(91, 34);
            this.items_idTextBox.Name = "items_idTextBox";
            this.items_idTextBox.Size = new System.Drawing.Size(60, 20);
            this.items_idTextBox.TabIndex = 2;
            // 
            // items_nameTextBox
            // 
            this.items_nameTextBox.Location = new System.Drawing.Point(91, 60);
            this.items_nameTextBox.Name = "items_nameTextBox";
            this.items_nameTextBox.Size = new System.Drawing.Size(368, 20);
            this.items_nameTextBox.TabIndex = 4;
            // 
            // items_descTextBox
            // 
            this.items_descTextBox.Location = new System.Drawing.Point(91, 86);
            this.items_descTextBox.Name = "items_descTextBox";
            this.items_descTextBox.Size = new System.Drawing.Size(368, 20);
            this.items_descTextBox.TabIndex = 6;
            // 
            // items_sizeTextBox
            // 
            this.items_sizeTextBox.Location = new System.Drawing.Point(91, 112);
            this.items_sizeTextBox.Name = "items_sizeTextBox";
            this.items_sizeTextBox.Size = new System.Drawing.Size(177, 20);
            this.items_sizeTextBox.TabIndex = 8;
            // 
            // CatogaryComboBox
            // 
            this.CatogaryComboBox.DataSource = this.categoryBindingSource;
            this.CatogaryComboBox.DisplayMember = "category_name";
            this.CatogaryComboBox.FormattingEnabled = true;
            this.CatogaryComboBox.Location = new System.Drawing.Point(92, 138);
            this.CatogaryComboBox.Name = "CatogaryComboBox";
            this.CatogaryComboBox.Size = new System.Drawing.Size(367, 21);
            this.CatogaryComboBox.TabIndex = 10;
            this.CatogaryComboBox.ValueMember = "category_id";
            this.CatogaryComboBox.SelectedIndexChanged += new System.EventHandler(this.CatogaryComboBox_SelectedIndexChanged);
            // 
            // categoryBindingSource
            // 
            this.categoryBindingSource.DataMember = "Category";
            this.categoryBindingSource.DataSource = this.sastockDataSetCategory;
            // 
            // sastockDataSetCategory
            // 
            this.sastockDataSetCategory.DataSetName = "sastockDataSetCategory";
            this.sastockDataSetCategory.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // dataGridViewItems
            // 
            this.dataGridViewItems.AllowUserToAddRows = false;
            this.dataGridViewItems.AllowUserToDeleteRows = false;
            this.dataGridViewItems.AllowUserToResizeColumns = false;
            this.dataGridViewItems.AllowUserToResizeRows = false;
            this.dataGridViewItems.AutoGenerateColumns = false;
            this.dataGridViewItems.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewItems.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.itemsidDataGridViewTextBoxColumn,
            this.itemsnameDataGridViewTextBoxColumn,
            this.itemsdescDataGridViewTextBoxColumn,
            this.itemssizeDataGridViewTextBoxColumn,
            this.category_id,
            this.entrydateDataGridViewTextBoxColumn});
            this.dataGridViewItems.DataSource = this.itemsBindingSource;
            this.dataGridViewItems.Location = new System.Drawing.Point(25, 234);
            this.dataGridViewItems.Name = "dataGridViewItems";
            this.dataGridViewItems.ReadOnly = true;
            this.dataGridViewItems.Size = new System.Drawing.Size(615, 255);
            this.dataGridViewItems.TabIndex = 11;
            this.dataGridViewItems.RowHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dataGridViewItems_RowHeaderMouseClick);
            // 
            // itemsidDataGridViewTextBoxColumn
            // 
            this.itemsidDataGridViewTextBoxColumn.DataPropertyName = "items_id";
            this.itemsidDataGridViewTextBoxColumn.HeaderText = "Items ID";
            this.itemsidDataGridViewTextBoxColumn.Name = "itemsidDataGridViewTextBoxColumn";
            this.itemsidDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // itemsnameDataGridViewTextBoxColumn
            // 
            this.itemsnameDataGridViewTextBoxColumn.DataPropertyName = "items_name";
            this.itemsnameDataGridViewTextBoxColumn.HeaderText = "Items Name";
            this.itemsnameDataGridViewTextBoxColumn.Name = "itemsnameDataGridViewTextBoxColumn";
            this.itemsnameDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // itemsdescDataGridViewTextBoxColumn
            // 
            this.itemsdescDataGridViewTextBoxColumn.DataPropertyName = "items_desc";
            this.itemsdescDataGridViewTextBoxColumn.HeaderText = "Items Desc";
            this.itemsdescDataGridViewTextBoxColumn.Name = "itemsdescDataGridViewTextBoxColumn";
            this.itemsdescDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // itemssizeDataGridViewTextBoxColumn
            // 
            this.itemssizeDataGridViewTextBoxColumn.DataPropertyName = "items_size";
            this.itemssizeDataGridViewTextBoxColumn.HeaderText = "Items Size";
            this.itemssizeDataGridViewTextBoxColumn.Name = "itemssizeDataGridViewTextBoxColumn";
            this.itemssizeDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // category_id
            // 
            this.category_id.DataPropertyName = "category_id";
            this.category_id.DataSource = this.categoryBindingSource;
            this.category_id.DisplayMember = "category_name";
            this.category_id.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.Nothing;
            this.category_id.HeaderText = "Category";
            this.category_id.Name = "category_id";
            this.category_id.ReadOnly = true;
            this.category_id.ValueMember = "category_id";
            this.category_id.Width = 150;
            // 
            // entrydateDataGridViewTextBoxColumn
            // 
            this.entrydateDataGridViewTextBoxColumn.DataPropertyName = "entrydate";
            this.entrydateDataGridViewTextBoxColumn.HeaderText = "Entry Date";
            this.entrydateDataGridViewTextBoxColumn.Name = "entrydateDataGridViewTextBoxColumn";
            this.entrydateDataGridViewTextBoxColumn.ReadOnly = true;
            this.entrydateDataGridViewTextBoxColumn.Visible = false;
            this.entrydateDataGridViewTextBoxColumn.Width = 130;
            // 
            // itemsBindingSource
            // 
            this.itemsBindingSource.DataMember = "Items";
            this.itemsBindingSource.DataSource = this.itemsDataSet;
            // 
            // itemsDataSet
            // 
            this.itemsDataSet.DataSetName = "ItemsDataSet";
            this.itemsDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // buttonNew
            // 
            this.buttonNew.Location = new System.Drawing.Point(25, 183);
            this.buttonNew.Name = "buttonNew";
            this.buttonNew.Size = new System.Drawing.Size(75, 23);
            this.buttonNew.TabIndex = 15;
            this.buttonNew.Text = "New";
            this.buttonNew.UseVisualStyleBackColor = true;
            this.buttonNew.Click += new System.EventHandler(this.buttonNew_Click);
            // 
            // button_Delete
            // 
            this.button_Delete.Location = new System.Drawing.Point(367, 183);
            this.button_Delete.Name = "button_Delete";
            this.button_Delete.Size = new System.Drawing.Size(75, 23);
            this.button_Delete.TabIndex = 14;
            this.button_Delete.Text = "Delete";
            this.button_Delete.UseVisualStyleBackColor = true;
            this.button_Delete.Visible = false;
            this.button_Delete.Click += new System.EventHandler(this.button_Delete_Click);
            // 
            // button_Update
            // 
            this.button_Update.Location = new System.Drawing.Point(257, 183);
            this.button_Update.Name = "button_Update";
            this.button_Update.Size = new System.Drawing.Size(75, 23);
            this.button_Update.TabIndex = 13;
            this.button_Update.Text = "Update";
            this.button_Update.UseVisualStyleBackColor = true;
            this.button_Update.Visible = false;
            this.button_Update.Click += new System.EventHandler(this.button_Update_Click);
            // 
            // button_Insert
            // 
            this.button_Insert.Enabled = false;
            this.button_Insert.Location = new System.Drawing.Point(137, 183);
            this.button_Insert.Name = "button_Insert";
            this.button_Insert.Size = new System.Drawing.Size(75, 23);
            this.button_Insert.TabIndex = 12;
            this.button_Insert.Text = "Insert";
            this.button_Insert.UseVisualStyleBackColor = true;
            this.button_Insert.Click += new System.EventHandler(this.button_Insert_Click);
            // 
            // categoryTableAdapter
            // 
            this.categoryTableAdapter.ClearBeforeFill = true;
            // 
            // itemsTableAdapter
            // 
            this.itemsTableAdapter.ClearBeforeFill = true;
            // 
            // FormItems
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(672, 501);
            this.Controls.Add(this.buttonNew);
            this.Controls.Add(this.button_Delete);
            this.Controls.Add(this.button_Update);
            this.Controls.Add(this.button_Insert);
            this.Controls.Add(this.dataGridViewItems);
            this.Controls.Add(this.CatogaryComboBox);
            this.Controls.Add(items_idLabel);
            this.Controls.Add(this.items_idTextBox);
            this.Controls.Add(items_nameLabel);
            this.Controls.Add(this.items_nameTextBox);
            this.Controls.Add(items_descLabel);
            this.Controls.Add(this.items_descTextBox);
            this.Controls.Add(items_sizeLabel);
            this.Controls.Add(this.items_sizeTextBox);
            this.Controls.Add(category_idLabel);
            this.Name = "FormItems";
            this.Text = "Items";
            this.Load += new System.EventHandler(this.FormItems_Load);
            ((System.ComponentModel.ISupportInitialize)(this.categoryBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sastockDataSetCategory)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewItems)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.itemsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.itemsDataSet)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox items_idTextBox;
        private System.Windows.Forms.TextBox items_nameTextBox;
        private System.Windows.Forms.TextBox items_descTextBox;
        private System.Windows.Forms.TextBox items_sizeTextBox;
        private System.Windows.Forms.ComboBox CatogaryComboBox;
        private System.Windows.Forms.DataGridView dataGridViewItems;
        private System.Windows.Forms.Button buttonNew;
        private System.Windows.Forms.Button button_Delete;
        private System.Windows.Forms.Button button_Update;
        private System.Windows.Forms.Button button_Insert;
        private sastockDataSetCategory sastockDataSetCategory;
        private System.Windows.Forms.BindingSource categoryBindingSource;
        private sastockDataSetCategoryTableAdapters.CategoryTableAdapter categoryTableAdapter;
        private ItemsDataSet itemsDataSet;
        private System.Windows.Forms.BindingSource itemsBindingSource;
        private ItemsDataSetTableAdapters.ItemsTableAdapter itemsTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn itemsidDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn itemsnameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn itemsdescDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn itemssizeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewComboBoxColumn category_id;
        private System.Windows.Forms.DataGridViewTextBoxColumn entrydateDataGridViewTextBoxColumn;
    }
}