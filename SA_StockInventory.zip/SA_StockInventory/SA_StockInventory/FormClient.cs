﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SA_StockInventory
{
    public partial class Form_Client : Form
    {
        public Form_Client()
        {
            InitializeComponent();
        }

        Class_Connection cn = new Class_Connection();
        DialogResult dlgResult;
        SqlCommand cmd;
        int i = 1;
        SqlDataAdapter adapt;

        private void DisplayDataInGrid()
        {
            cn.con.Open();
            DataTable dt = new DataTable();
            adapt = new SqlDataAdapter("select * from Client_info", cn.con);
            adapt.Fill(dt);
            dataGridViewClient.DataSource = dt;
            cn.con.Close();
        }

        private void DisplayDatainTextBox(int i)
        {

            cn.con.Open();
            cmd = new SqlCommand();
            try
            {
                cmd = new SqlCommand("crudClientInfo", cn.con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add(new SqlParameter("@StatementType", "SelectClientInfo"));
                cmd.Parameters.Add(new SqlParameter("@Cln_ID", i));

                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    client_idTextBox.Text = reader["client_id"].ToString();
                    client_nameTextBox.Text = reader["client_name"].ToString();
                    cellTextBox.Text = reader["cell"].ToString();
                    phoneTextBox.Text = reader["phone"].ToString();
                    addressTextBox.Text = reader["address"].ToString();
                    ntnTextBox.Text = reader["ntn"].ToString();
                    accountTextBox.Text = reader["account"].ToString();
                }
                reader.Close();
                cn.con.Close();

            }
            catch (Exception x)
            {
                MessageBox.Show(x.GetBaseException().ToString(), "Error",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                cmd.InitializeLifetimeService();

                cn.con.Close();

            }

        }



        private void buttonNew_Click(object sender, EventArgs e)
        {
            buttonNew.Enabled = false;
            button_Insert.Enabled = true;
            button_Update.Enabled = false;


            client_idTextBox.Text = "";
            client_nameTextBox.Text = "";
            cellTextBox.Text = "";
            phoneTextBox.Text = "";
            addressTextBox.Text = "";
            ntnTextBox.Text = "";
            accountTextBox.Text = "";
            
        }

        private void button_Insert_Click(object sender, EventArgs e)
        {
            dlgResult = MessageBox.Show("Do you want to Insert New Record", "New Record Insert", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
            if (dlgResult == DialogResult.Yes)
            {

                try
                {
                    if (client_idTextBox.Text == "" && (client_nameTextBox.Text != ""))
                    {
                        cn.con.Open();
                        cmd = new SqlCommand("crudClientInfo", cn.con);
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.Add(new SqlParameter("@StatementType", "InsertClientInfo"));
                        cmd.Parameters.AddWithValue("@Cln_name", client_nameTextBox.Text);
                        cmd.Parameters.AddWithValue("@Cel", cellTextBox.Text);
                        cmd.Parameters.AddWithValue("@Ph", phoneTextBox.Text);
                        cmd.Parameters.AddWithValue("@Add", addressTextBox.Text);
                        cmd.Parameters.AddWithValue("@Nt", ntnTextBox.Text);
                        cmd.Parameters.AddWithValue("@Acc", accountTextBox.Text);

                        cmd.ExecuteNonQuery();
                        cn.con.Close();
                        MessageBox.Show("Record Inserted Successfully");
                        DisplayDataInGrid();

                        buttonNew.Enabled = true;
                        button_Insert.Enabled = false;
                        button_Update.Enabled = true;

                    }
                    else
                    {
                        MessageBox.Show("Only for New Record, Please Fill All Fields!");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(Convert.ToString(ex));
                }
            }

        }

        private void Form_Client_Load(object sender, EventArgs e)
        {
            DisplayDatainTextBox(i);
            DisplayDataInGrid();
            string userName = FormLogin.CheckUserName;
            if (userName == "Admin" || userName == "Super")
            {
                button_Delete.Visible = true;
                button_Update.Visible = true;
            }

        }

        private void button_Update_Click(object sender, EventArgs e)
        {
            dlgResult = MessageBox.Show("Do you want to Update this Record", "Update Record", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
            if (dlgResult == DialogResult.Yes)
            {


                try
                {
                    if (client_idTextBox.Text != "" && client_nameTextBox.Text != "")
                    {
                        //cmd = new SqlCommand("update Branch set branch_name=@name,branch_location=@location where branch_id=@id", cn.con);
                        cn.con.Open();
                        cmd = new SqlCommand("crudClientInfo", cn.con);
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.Add(new SqlParameter("@StatementType", "UpdateClientInfo"));
                        cmd.Parameters.AddWithValue("@Cln_ID", client_idTextBox.Text);
                        cmd.Parameters.AddWithValue("@Cln_name", client_nameTextBox.Text);
                        cmd.Parameters.AddWithValue("@Cel", cellTextBox.Text);
                        cmd.Parameters.AddWithValue("@Ph", phoneTextBox.Text);
                        cmd.Parameters.AddWithValue("@Add", addressTextBox.Text);
                        cmd.Parameters.AddWithValue("@Nt", ntnTextBox.Text);
                        cmd.Parameters.AddWithValue("@Acc", accountTextBox.Text);
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Record Updated Successfully");
                        cn.con.Close();
                        DisplayDatainTextBox(i);
                        DisplayDataInGrid();
                        buttonNew.Enabled = true;
                        button_Insert.Enabled = false;
                        button_Update.Enabled = true;

                    }
                    else
                    {
                        MessageBox.Show("Please Select Record to Update");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(Convert.ToString(ex));
                }
            }
        }

        private void button_Delete_Click(object sender, EventArgs e)
        {
            dlgResult = MessageBox.Show("Do you want to Delete this Record", "Delete Record", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
            if (dlgResult == DialogResult.Yes)
            {
                try
                {
                    if (client_idTextBox.Text != "")
                    {
                        // cmd = new SqlCommand("delete from Branch where branch_id=@id", cn.con);
                        cn.con.Open();
                        cmd = new SqlCommand("crudClientInfo", cn.con);
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.Add(new SqlParameter("@StatementType", "DeleteClientInfo"));
                        cmd.Parameters.AddWithValue("@Cln_ID", client_idTextBox.Text);
                        cmd.ExecuteNonQuery();
                        cn.con.Close();
                        MessageBox.Show("Record Deleted Successfully!");
                        DisplayDatainTextBox(i);
                        DisplayDataInGrid();
                    }
                    else { MessageBox.Show("Please Select Record to Delete"); }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(Convert.ToString(ex));
                }

                //   MessageBox.Show("Please Select Record to Delete");
            }

        }

        private void dataGridViewClient_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            client_idTextBox.Text = dataGridViewClient.Rows[e.RowIndex].Cells[0].Value.ToString();
            i = Convert.ToInt16(client_idTextBox.Text);
            DisplayDatainTextBox(i);
        }
    }
}
