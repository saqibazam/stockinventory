﻿namespace SA_StockInventory
{
    partial class RptOutList
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource2 = new Microsoft.Reporting.WinForms.ReportDataSource();
            this.comboBoxBranch = new System.Windows.Forms.ComboBox();
            this.branchBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.sastockDataSetBranch = new SA_StockInventory.sastockDataSetBranch();
            this.comboBoxEmployee = new System.Windows.Forms.ComboBox();
            this.employeesBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.sastockDataSetEmpOnly = new SA_StockInventory.sastockDataSetEmpOnly();
            this.comboBoxCatagory = new System.Windows.Forms.ComboBox();
            this.categoryBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.sastockDataSetCategory = new SA_StockInventory.sastockDataSetCategory();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.buttonSearch = new System.Windows.Forms.Button();
            this.branchTableAdapter = new SA_StockInventory.sastockDataSetBranchTableAdapters.BranchTableAdapter();
            this.employeesTableAdapter = new SA_StockInventory.sastockDataSetEmpOnlyTableAdapters.EmployeesTableAdapter();
            this.categoryTableAdapter = new SA_StockInventory.sastockDataSetCategoryTableAdapters.CategoryTableAdapter();
            this.dateTimePickerFrom = new System.Windows.Forms.DateTimePicker();
            this.dateTimePickerTo = new System.Windows.Forms.DateTimePicker();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.checkBoxEmployee = new System.Windows.Forms.CheckBox();
            this.checkBoxCatagory = new System.Windows.Forms.CheckBox();
            this.checkBoxBranch = new System.Windows.Forms.CheckBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.checkBoxDate = new System.Windows.Forms.CheckBox();
            this.reportViewerSout = new Microsoft.Reporting.WinForms.ReportViewer();
            this.ViewSaOut = new SA_StockInventory.ViewSaOut();
            this.View_StockOutBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.View_StockOutTableAdapter = new SA_StockInventory.ViewSaOutTableAdapters.View_StockOutTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.branchBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sastockDataSetBranch)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.employeesBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sastockDataSetEmpOnly)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.categoryBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sastockDataSetCategory)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ViewSaOut)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.View_StockOutBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // comboBoxBranch
            // 
            this.comboBoxBranch.DataSource = this.branchBindingSource;
            this.comboBoxBranch.DisplayMember = "branch_name";
            this.comboBoxBranch.FormattingEnabled = true;
            this.comboBoxBranch.Location = new System.Drawing.Point(87, 16);
            this.comboBoxBranch.Name = "comboBoxBranch";
            this.comboBoxBranch.Size = new System.Drawing.Size(205, 21);
            this.comboBoxBranch.TabIndex = 1;
            this.comboBoxBranch.ValueMember = "branch_id";
            // 
            // branchBindingSource
            // 
            this.branchBindingSource.DataMember = "Branch";
            this.branchBindingSource.DataSource = this.sastockDataSetBranch;
            // 
            // sastockDataSetBranch
            // 
            this.sastockDataSetBranch.DataSetName = "sastockDataSetBranch";
            this.sastockDataSetBranch.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // comboBoxEmployee
            // 
            this.comboBoxEmployee.DataSource = this.employeesBindingSource;
            this.comboBoxEmployee.DisplayMember = "EmpName";
            this.comboBoxEmployee.FormattingEnabled = true;
            this.comboBoxEmployee.Location = new System.Drawing.Point(87, 74);
            this.comboBoxEmployee.Name = "comboBoxEmployee";
            this.comboBoxEmployee.Size = new System.Drawing.Size(205, 21);
            this.comboBoxEmployee.TabIndex = 2;
            this.comboBoxEmployee.ValueMember = "EmpID";
            // 
            // employeesBindingSource
            // 
            this.employeesBindingSource.DataMember = "Employees";
            this.employeesBindingSource.DataSource = this.sastockDataSetEmpOnly;
            // 
            // sastockDataSetEmpOnly
            // 
            this.sastockDataSetEmpOnly.DataSetName = "sastockDataSetEmpOnly";
            this.sastockDataSetEmpOnly.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // comboBoxCatagory
            // 
            this.comboBoxCatagory.DataSource = this.categoryBindingSource;
            this.comboBoxCatagory.DisplayMember = "category_name";
            this.comboBoxCatagory.FormattingEnabled = true;
            this.comboBoxCatagory.Location = new System.Drawing.Point(87, 46);
            this.comboBoxCatagory.Name = "comboBoxCatagory";
            this.comboBoxCatagory.Size = new System.Drawing.Size(205, 21);
            this.comboBoxCatagory.TabIndex = 3;
            this.comboBoxCatagory.ValueMember = "category_id";
            // 
            // categoryBindingSource
            // 
            this.categoryBindingSource.DataMember = "Category";
            this.categoryBindingSource.DataSource = this.sastockDataSetCategory;
            // 
            // sastockDataSetCategory
            // 
            this.sastockDataSetCategory.DataSetName = "sastockDataSetCategory";
            this.sastockDataSetCategory.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(33, 29);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(30, 13);
            this.label1.TabIndex = 6;
            this.label1.Text = "From";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(35, 64);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(20, 13);
            this.label2.TabIndex = 7;
            this.label2.Text = "To";
            // 
            // buttonSearch
            // 
            this.buttonSearch.Location = new System.Drawing.Point(653, 72);
            this.buttonSearch.Name = "buttonSearch";
            this.buttonSearch.Size = new System.Drawing.Size(101, 23);
            this.buttonSearch.TabIndex = 8;
            this.buttonSearch.Text = "Search";
            this.buttonSearch.UseVisualStyleBackColor = true;
            this.buttonSearch.Click += new System.EventHandler(this.buttonSearch_Click);
            // 
            // branchTableAdapter
            // 
            this.branchTableAdapter.ClearBeforeFill = true;
            // 
            // employeesTableAdapter
            // 
            this.employeesTableAdapter.ClearBeforeFill = true;
            // 
            // categoryTableAdapter
            // 
            this.categoryTableAdapter.ClearBeforeFill = true;
            // 
            // dateTimePickerFrom
            // 
            this.dateTimePickerFrom.Location = new System.Drawing.Point(69, 22);
            this.dateTimePickerFrom.Name = "dateTimePickerFrom";
            this.dateTimePickerFrom.Size = new System.Drawing.Size(200, 20);
            this.dateTimePickerFrom.TabIndex = 10;
            // 
            // dateTimePickerTo
            // 
            this.dateTimePickerTo.Location = new System.Drawing.Point(69, 61);
            this.dateTimePickerTo.Name = "dateTimePickerTo";
            this.dateTimePickerTo.Size = new System.Drawing.Size(200, 20);
            this.dateTimePickerTo.TabIndex = 11;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.checkBoxEmployee);
            this.groupBox1.Controls.Add(this.checkBoxCatagory);
            this.groupBox1.Controls.Add(this.checkBoxBranch);
            this.groupBox1.Controls.Add(this.comboBoxBranch);
            this.groupBox1.Controls.Add(this.comboBoxCatagory);
            this.groupBox1.Controls.Add(this.comboBoxEmployee);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(310, 106);
            this.groupBox1.TabIndex = 12;
            this.groupBox1.TabStop = false;
            // 
            // checkBoxEmployee
            // 
            this.checkBoxEmployee.AutoSize = true;
            this.checkBoxEmployee.Location = new System.Drawing.Point(16, 74);
            this.checkBoxEmployee.Name = "checkBoxEmployee";
            this.checkBoxEmployee.Size = new System.Drawing.Size(72, 17);
            this.checkBoxEmployee.TabIndex = 17;
            this.checkBoxEmployee.Text = "Employee";
            this.checkBoxEmployee.UseVisualStyleBackColor = true;
            // 
            // checkBoxCatagory
            // 
            this.checkBoxCatagory.AutoSize = true;
            this.checkBoxCatagory.Location = new System.Drawing.Point(16, 48);
            this.checkBoxCatagory.Name = "checkBoxCatagory";
            this.checkBoxCatagory.Size = new System.Drawing.Size(68, 17);
            this.checkBoxCatagory.TabIndex = 16;
            this.checkBoxCatagory.Text = "Catagory";
            this.checkBoxCatagory.UseVisualStyleBackColor = true;
            // 
            // checkBoxBranch
            // 
            this.checkBoxBranch.AutoSize = true;
            this.checkBoxBranch.Location = new System.Drawing.Point(16, 19);
            this.checkBoxBranch.Name = "checkBoxBranch";
            this.checkBoxBranch.Size = new System.Drawing.Size(60, 17);
            this.checkBoxBranch.TabIndex = 15;
            this.checkBoxBranch.Text = "Branch";
            this.checkBoxBranch.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.checkBoxDate);
            this.groupBox2.Controls.Add(this.dateTimePickerFrom);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.dateTimePickerTo);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Location = new System.Drawing.Point(328, 14);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(285, 104);
            this.groupBox2.TabIndex = 13;
            this.groupBox2.TabStop = false;
            // 
            // checkBoxDate
            // 
            this.checkBoxDate.AutoSize = true;
            this.checkBoxDate.Location = new System.Drawing.Point(11, 16);
            this.checkBoxDate.Name = "checkBoxDate";
            this.checkBoxDate.Size = new System.Drawing.Size(15, 14);
            this.checkBoxDate.TabIndex = 14;
            this.checkBoxDate.UseVisualStyleBackColor = true;
            // 
            // reportViewerSout
            // 
            reportDataSource2.Name = "DataSet1";
            reportDataSource2.Value = this.View_StockOutBindingSource;
            this.reportViewerSout.LocalReport.DataSources.Add(reportDataSource2);
            this.reportViewerSout.LocalReport.ReportEmbeddedResource = "SA_StockInventory.RptOutList.rdlc";
            this.reportViewerSout.Location = new System.Drawing.Point(28, 146);
            this.reportViewerSout.Name = "reportViewerSout";
            this.reportViewerSout.Size = new System.Drawing.Size(854, 246);
            this.reportViewerSout.TabIndex = 14;
            // 
            // ViewSaOut
            // 
            this.ViewSaOut.DataSetName = "ViewSaOut";
            this.ViewSaOut.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // View_StockOutBindingSource
            // 
            this.View_StockOutBindingSource.DataMember = "View_StockOut";
            this.View_StockOutBindingSource.DataSource = this.ViewSaOut;
            // 
            // View_StockOutTableAdapter
            // 
            this.View_StockOutTableAdapter.ClearBeforeFill = true;
            // 
            // RptOutList
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(910, 480);
            this.Controls.Add(this.reportViewerSout);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.buttonSearch);
            this.Name = "RptOutList";
            this.Text = "Report Stock Out List";
            this.Load += new System.EventHandler(this.RptOutList_Load);
            ((System.ComponentModel.ISupportInitialize)(this.branchBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sastockDataSetBranch)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.employeesBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sastockDataSetEmpOnly)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.categoryBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sastockDataSetCategory)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ViewSaOut)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.View_StockOutBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.ComboBox comboBoxBranch;
        private System.Windows.Forms.ComboBox comboBoxEmployee;
        private System.Windows.Forms.ComboBox comboBoxCatagory;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button buttonSearch;
        private sastockDataSetBranch sastockDataSetBranch;
        private System.Windows.Forms.BindingSource branchBindingSource;
        private sastockDataSetBranchTableAdapters.BranchTableAdapter branchTableAdapter;
        private sastockDataSetEmpOnly sastockDataSetEmpOnly;
        private System.Windows.Forms.BindingSource employeesBindingSource;
        private sastockDataSetEmpOnlyTableAdapters.EmployeesTableAdapter employeesTableAdapter;
        private sastockDataSetCategory sastockDataSetCategory;
        private System.Windows.Forms.BindingSource categoryBindingSource;
        private sastockDataSetCategoryTableAdapters.CategoryTableAdapter categoryTableAdapter;
     
        private System.Windows.Forms.DateTimePicker dateTimePickerFrom;
        private System.Windows.Forms.DateTimePicker dateTimePickerTo;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.CheckBox checkBoxDate;
        private System.Windows.Forms.CheckBox checkBoxEmployee;
        private System.Windows.Forms.CheckBox checkBoxCatagory;
        private System.Windows.Forms.CheckBox checkBoxBranch;
        private Microsoft.Reporting.WinForms.ReportViewer reportViewerSout;
        private System.Windows.Forms.BindingSource View_StockOutBindingSource;
        private ViewSaOut ViewSaOut;
        private ViewSaOutTableAdapters.View_StockOutTableAdapter View_StockOutTableAdapter;
    }
}