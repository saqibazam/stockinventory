﻿namespace SA_StockInventory
{
    partial class Form_Client
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.Label client_nameLabel;
            System.Windows.Forms.Label cellLabel;
            System.Windows.Forms.Label phoneLabel;
            System.Windows.Forms.Label addressLabel;
            System.Windows.Forms.Label ntnLabel;
            System.Windows.Forms.Label accountLabel;
            System.Windows.Forms.Label client_idLabel;
            this.client_idTextBox = new System.Windows.Forms.TextBox();
            this.client_nameTextBox = new System.Windows.Forms.TextBox();
            this.cellTextBox = new System.Windows.Forms.TextBox();
            this.phoneTextBox = new System.Windows.Forms.TextBox();
            this.addressTextBox = new System.Windows.Forms.TextBox();
            this.ntnTextBox = new System.Windows.Forms.TextBox();
            this.accountTextBox = new System.Windows.Forms.TextBox();
            this.dataGridViewClient = new System.Windows.Forms.DataGridView();
            this.buttonNew = new System.Windows.Forms.Button();
            this.button_Delete = new System.Windows.Forms.Button();
            this.button_Update = new System.Windows.Forms.Button();
            this.button_Insert = new System.Windows.Forms.Button();
            client_nameLabel = new System.Windows.Forms.Label();
            cellLabel = new System.Windows.Forms.Label();
            phoneLabel = new System.Windows.Forms.Label();
            addressLabel = new System.Windows.Forms.Label();
            ntnLabel = new System.Windows.Forms.Label();
            accountLabel = new System.Windows.Forms.Label();
            client_idLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewClient)).BeginInit();
            this.SuspendLayout();
            // 
            // client_nameLabel
            // 
            client_nameLabel.AutoSize = true;
            client_nameLabel.Location = new System.Drawing.Point(22, 67);
            client_nameLabel.Name = "client_nameLabel";
            client_nameLabel.Size = new System.Drawing.Size(67, 13);
            client_nameLabel.TabIndex = 3;
            client_nameLabel.Text = "Client Name:";
            // 
            // cellLabel
            // 
            cellLabel.AutoSize = true;
            cellLabel.Location = new System.Drawing.Point(22, 93);
            cellLabel.Name = "cellLabel";
            cellLabel.Size = new System.Drawing.Size(27, 13);
            cellLabel.TabIndex = 5;
            cellLabel.Text = "Cell:";
            // 
            // phoneLabel
            // 
            phoneLabel.AutoSize = true;
            phoneLabel.Location = new System.Drawing.Point(22, 119);
            phoneLabel.Name = "phoneLabel";
            phoneLabel.Size = new System.Drawing.Size(41, 13);
            phoneLabel.TabIndex = 7;
            phoneLabel.Text = "Phone:";
            // 
            // addressLabel
            // 
            addressLabel.AutoSize = true;
            addressLabel.Location = new System.Drawing.Point(22, 145);
            addressLabel.Name = "addressLabel";
            addressLabel.Size = new System.Drawing.Size(48, 13);
            addressLabel.TabIndex = 9;
            addressLabel.Text = "Address:";
            // 
            // ntnLabel
            // 
            ntnLabel.AutoSize = true;
            ntnLabel.Location = new System.Drawing.Point(22, 171);
            ntnLabel.Name = "ntnLabel";
            ntnLabel.Size = new System.Drawing.Size(33, 13);
            ntnLabel.TabIndex = 11;
            ntnLabel.Text = "NTN:";
            // 
            // accountLabel
            // 
            accountLabel.AutoSize = true;
            accountLabel.Location = new System.Drawing.Point(22, 197);
            accountLabel.Name = "accountLabel";
            accountLabel.Size = new System.Drawing.Size(50, 13);
            accountLabel.TabIndex = 13;
            accountLabel.Text = "Account:";
            // 
            // client_idLabel
            // 
            client_idLabel.AutoSize = true;
            client_idLabel.Location = new System.Drawing.Point(22, 41);
            client_idLabel.Name = "client_idLabel";
            client_idLabel.Size = new System.Drawing.Size(48, 13);
            client_idLabel.TabIndex = 1;
            client_idLabel.Text = "Client Id:";
            // 
            // client_idTextBox
            // 
            this.client_idTextBox.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.client_idTextBox.Enabled = false;
            this.client_idTextBox.Location = new System.Drawing.Point(92, 38);
            this.client_idTextBox.Name = "client_idTextBox";
            this.client_idTextBox.Size = new System.Drawing.Size(100, 20);
            this.client_idTextBox.TabIndex = 2;
            // 
            // client_nameTextBox
            // 
            this.client_nameTextBox.Location = new System.Drawing.Point(92, 64);
            this.client_nameTextBox.Name = "client_nameTextBox";
            this.client_nameTextBox.Size = new System.Drawing.Size(313, 20);
            this.client_nameTextBox.TabIndex = 4;
            // 
            // cellTextBox
            // 
            this.cellTextBox.Location = new System.Drawing.Point(92, 90);
            this.cellTextBox.Name = "cellTextBox";
            this.cellTextBox.Size = new System.Drawing.Size(159, 20);
            this.cellTextBox.TabIndex = 6;
            // 
            // phoneTextBox
            // 
            this.phoneTextBox.Location = new System.Drawing.Point(92, 116);
            this.phoneTextBox.Name = "phoneTextBox";
            this.phoneTextBox.Size = new System.Drawing.Size(159, 20);
            this.phoneTextBox.TabIndex = 8;
            // 
            // addressTextBox
            // 
            this.addressTextBox.Location = new System.Drawing.Point(92, 142);
            this.addressTextBox.Name = "addressTextBox";
            this.addressTextBox.Size = new System.Drawing.Size(313, 20);
            this.addressTextBox.TabIndex = 10;
            // 
            // ntnTextBox
            // 
            this.ntnTextBox.Location = new System.Drawing.Point(92, 168);
            this.ntnTextBox.Name = "ntnTextBox";
            this.ntnTextBox.Size = new System.Drawing.Size(115, 20);
            this.ntnTextBox.TabIndex = 12;
            // 
            // accountTextBox
            // 
            this.accountTextBox.Location = new System.Drawing.Point(92, 194);
            this.accountTextBox.Name = "accountTextBox";
            this.accountTextBox.Size = new System.Drawing.Size(115, 20);
            this.accountTextBox.TabIndex = 14;
            // 
            // dataGridViewClient
            // 
            this.dataGridViewClient.AllowUserToAddRows = false;
            this.dataGridViewClient.AllowUserToDeleteRows = false;
            this.dataGridViewClient.AllowUserToResizeColumns = false;
            this.dataGridViewClient.AllowUserToResizeRows = false;
            this.dataGridViewClient.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewClient.Location = new System.Drawing.Point(25, 288);
            this.dataGridViewClient.Name = "dataGridViewClient";
            this.dataGridViewClient.ReadOnly = true;
            this.dataGridViewClient.Size = new System.Drawing.Size(621, 173);
            this.dataGridViewClient.TabIndex = 15;
            this.dataGridViewClient.RowHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dataGridViewClient_RowHeaderMouseClick);
            // 
            // buttonNew
            // 
            this.buttonNew.Location = new System.Drawing.Point(25, 243);
            this.buttonNew.Name = "buttonNew";
            this.buttonNew.Size = new System.Drawing.Size(75, 23);
            this.buttonNew.TabIndex = 19;
            this.buttonNew.Text = "New";
            this.buttonNew.UseVisualStyleBackColor = true;
            this.buttonNew.Click += new System.EventHandler(this.buttonNew_Click);
            // 
            // button_Delete
            // 
            this.button_Delete.Location = new System.Drawing.Point(367, 243);
            this.button_Delete.Name = "button_Delete";
            this.button_Delete.Size = new System.Drawing.Size(75, 23);
            this.button_Delete.TabIndex = 18;
            this.button_Delete.Text = "Delete";
            this.button_Delete.UseVisualStyleBackColor = true;
            this.button_Delete.Visible = false;
            this.button_Delete.Click += new System.EventHandler(this.button_Delete_Click);
            // 
            // button_Update
            // 
            this.button_Update.Location = new System.Drawing.Point(257, 243);
            this.button_Update.Name = "button_Update";
            this.button_Update.Size = new System.Drawing.Size(75, 23);
            this.button_Update.TabIndex = 17;
            this.button_Update.Text = "Update";
            this.button_Update.UseVisualStyleBackColor = true;
            this.button_Update.Visible = false;
            this.button_Update.Click += new System.EventHandler(this.button_Update_Click);
            // 
            // button_Insert
            // 
            this.button_Insert.Enabled = false;
            this.button_Insert.Location = new System.Drawing.Point(137, 243);
            this.button_Insert.Name = "button_Insert";
            this.button_Insert.Size = new System.Drawing.Size(75, 23);
            this.button_Insert.TabIndex = 16;
            this.button_Insert.Text = "Insert";
            this.button_Insert.UseVisualStyleBackColor = true;
            this.button_Insert.Click += new System.EventHandler(this.button_Insert_Click);
            // 
            // Form_Client
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(674, 485);
            this.Controls.Add(this.buttonNew);
            this.Controls.Add(this.button_Delete);
            this.Controls.Add(this.button_Update);
            this.Controls.Add(this.button_Insert);
            this.Controls.Add(this.dataGridViewClient);
            this.Controls.Add(client_idLabel);
            this.Controls.Add(this.client_idTextBox);
            this.Controls.Add(client_nameLabel);
            this.Controls.Add(this.client_nameTextBox);
            this.Controls.Add(cellLabel);
            this.Controls.Add(this.cellTextBox);
            this.Controls.Add(phoneLabel);
            this.Controls.Add(this.phoneTextBox);
            this.Controls.Add(addressLabel);
            this.Controls.Add(this.addressTextBox);
            this.Controls.Add(ntnLabel);
            this.Controls.Add(this.ntnTextBox);
            this.Controls.Add(accountLabel);
            this.Controls.Add(this.accountTextBox);
            this.Name = "Form_Client";
            this.Text = "Client Information";
            this.Load += new System.EventHandler(this.Form_Client_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewClient)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox client_idTextBox;
        private System.Windows.Forms.TextBox client_nameTextBox;
        private System.Windows.Forms.TextBox cellTextBox;
        private System.Windows.Forms.TextBox phoneTextBox;
        private System.Windows.Forms.TextBox addressTextBox;
        private System.Windows.Forms.TextBox ntnTextBox;
        private System.Windows.Forms.TextBox accountTextBox;
        private System.Windows.Forms.DataGridView dataGridViewClient;
        private System.Windows.Forms.Button buttonNew;
        private System.Windows.Forms.Button button_Delete;
        private System.Windows.Forms.Button button_Update;
        private System.Windows.Forms.Button button_Insert;
    }
}