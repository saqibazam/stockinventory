﻿namespace SA_StockInventory
{
    partial class Stock_Balance
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource3 = new Microsoft.Reporting.WinForms.ReportDataSource();
            this.View_StockBalanceBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.ViewStockBalance = new SA_StockInventory.ViewStockBalance();
            this.reportViewer1 = new Microsoft.Reporting.WinForms.ReportViewer();
            this.View_StockBalanceTableAdapter = new SA_StockInventory.ViewStockBalanceTableAdapters.View_StockBalanceTableAdapter();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.categoryBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.sastockDataSetCategory = new SA_StockInventory.sastockDataSetCategory();
            this.categoryTableAdapter = new SA_StockInventory.sastockDataSetCategoryTableAdapters.CategoryTableAdapter();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.comboBoxItem = new System.Windows.Forms.ComboBox();
            this.itemsDataSet = new SA_StockInventory.ItemsDataSet();
            this.itemsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.itemsTableAdapter = new SA_StockInventory.ItemsDataSetTableAdapters.ItemsTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.View_StockBalanceBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ViewStockBalance)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.categoryBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sastockDataSetCategory)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.itemsDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.itemsBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // View_StockBalanceBindingSource
            // 
            this.View_StockBalanceBindingSource.DataMember = "View_StockBalance";
            this.View_StockBalanceBindingSource.DataSource = this.ViewStockBalance;
            // 
            // ViewStockBalance
            // 
            this.ViewStockBalance.DataSetName = "ViewStockBalance";
            this.ViewStockBalance.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // reportViewer1
            // 
            reportDataSource3.Name = "DataSetStockBalance";
            reportDataSource3.Value = this.View_StockBalanceBindingSource;
            this.reportViewer1.LocalReport.DataSources.Add(reportDataSource3);
            this.reportViewer1.LocalReport.ReportEmbeddedResource = "SA_StockInventory.ReportStockBalance.rdlc";
            this.reportViewer1.Location = new System.Drawing.Point(0, 59);
            this.reportViewer1.Name = "reportViewer1";
            this.reportViewer1.Size = new System.Drawing.Size(817, 413);
            this.reportViewer1.TabIndex = 0;
            // 
            // View_StockBalanceTableAdapter
            // 
            this.View_StockBalanceTableAdapter.ClearBeforeFill = true;
            // 
            // comboBox1
            // 
            this.comboBox1.DataSource = this.categoryBindingSource;
            this.comboBox1.DisplayMember = "category_name";
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(76, 22);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(184, 21);
            this.comboBox1.TabIndex = 1;
            this.comboBox1.ValueMember = "category_id";
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // categoryBindingSource
            // 
            this.categoryBindingSource.DataMember = "Category";
            this.categoryBindingSource.DataSource = this.sastockDataSetCategory;
            // 
            // sastockDataSetCategory
            // 
            this.sastockDataSetCategory.DataSetName = "sastockDataSetCategory";
            this.sastockDataSetCategory.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // categoryTableAdapter
            // 
            this.categoryTableAdapter.ClearBeforeFill = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(58, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "Catageory:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(276, 25);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(30, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Item:";
            // 
            // comboBoxItem
            // 
            this.comboBoxItem.DataSource = this.itemsBindingSource;
            this.comboBoxItem.DisplayMember = "items_name";
            this.comboBoxItem.FormattingEnabled = true;
            this.comboBoxItem.Location = new System.Drawing.Point(312, 22);
            this.comboBoxItem.Name = "comboBoxItem";
            this.comboBoxItem.Size = new System.Drawing.Size(182, 21);
            this.comboBoxItem.TabIndex = 4;
            this.comboBoxItem.ValueMember = "items_id";
            this.comboBoxItem.SelectedIndexChanged += new System.EventHandler(this.comboBoxItem_SelectedIndexChanged);
            // 
            // itemsDataSet
            // 
            this.itemsDataSet.DataSetName = "ItemsDataSet";
            this.itemsDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // itemsBindingSource
            // 
            this.itemsBindingSource.DataMember = "Items";
            this.itemsBindingSource.DataSource = this.itemsDataSet;
            // 
            // itemsTableAdapter
            // 
            this.itemsTableAdapter.ClearBeforeFill = true;
            // 
            // Stock_Balance
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(819, 472);
            this.Controls.Add(this.comboBoxItem);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.reportViewer1);
            this.Name = "Stock_Balance";
            this.Text = "Stock Balance";
            this.Load += new System.EventHandler(this.Stock_Balance_Load);
            ((System.ComponentModel.ISupportInitialize)(this.View_StockBalanceBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ViewStockBalance)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.categoryBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sastockDataSetCategory)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.itemsDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.itemsBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Microsoft.Reporting.WinForms.ReportViewer reportViewer1;
        private System.Windows.Forms.BindingSource View_StockBalanceBindingSource;
        private ViewStockBalance ViewStockBalance;
        private ViewStockBalanceTableAdapters.View_StockBalanceTableAdapter View_StockBalanceTableAdapter;
        private System.Windows.Forms.ComboBox comboBox1;
        private sastockDataSetCategory sastockDataSetCategory;
        private System.Windows.Forms.BindingSource categoryBindingSource;
        private sastockDataSetCategoryTableAdapters.CategoryTableAdapter categoryTableAdapter;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox comboBoxItem;
        private ItemsDataSet itemsDataSet;
        private System.Windows.Forms.BindingSource itemsBindingSource;
        private ItemsDataSetTableAdapters.ItemsTableAdapter itemsTableAdapter;
    }
}