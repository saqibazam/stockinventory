﻿namespace SA_StockInventory
{
    partial class FormStockInMasterDetail
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label stockInMasterIDLabel;
            System.Windows.Forms.Label client_idLabel;
            System.Windows.Forms.Label sInDateLabel;
            System.Windows.Forms.Label label1;
            System.Windows.Forms.Label label2;
            System.Windows.Forms.Label label3;
            System.Windows.Forms.Label label4;
            System.Windows.Forms.Label label5;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormStockInMasterDetail));
            this.sastockDataSet_InMasterDetail = new SA_StockInventory.sastockDataSet_InMasterDetail();
            this.stockInMasterBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.stockInMasterTableAdapter = new SA_StockInventory.sastockDataSet_InMasterDetailTableAdapters.StockInMasterTableAdapter();
            this.tableAdapterManager = new SA_StockInventory.sastockDataSet_InMasterDetailTableAdapters.TableAdapterManager();
            this.stockInDetailTableAdapter = new SA_StockInventory.sastockDataSet_InMasterDetailTableAdapters.StockInDetailTableAdapter();
            this.stockInMasterBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButtonAssignVoucher = new System.Windows.Forms.ToolStripButton();
            this.stockInMasterBindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
            this.toolStripButtonEdit = new System.Windows.Forms.ToolStripButton();
            this.stockInMasterIDTextBox = new System.Windows.Forms.TextBox();
            this.client_idComboBox = new System.Windows.Forms.ComboBox();
            this.clientinfoBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.sastockDataSetClient = new SA_StockInventory.sastockDataSetClient();
            this.sInDateDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.stockInDetailBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.stockInDetailDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.itemsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.itemsDataSet = new SA_StockInventory.ItemsDataSet();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.client_infoTableAdapter = new SA_StockInventory.sastockDataSetClientTableAdapters.Client_infoTableAdapter();
            this.itemsTableAdapter = new SA_StockInventory.ItemsDataSetTableAdapters.ItemsTableAdapter();
            this.buttonPrintVoucherSin = new System.Windows.Forms.Button();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.categoryBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.sastockDataSetCategory = new SA_StockInventory.sastockDataSetCategory();
            this.categoryTableAdapter = new SA_StockInventory.sastockDataSetCategoryTableAdapters.CategoryTableAdapter();
            this.dataGridView_ItemBalance = new System.Windows.Forms.DataGridView();
            this.textBoxItems = new System.Windows.Forms.TextBox();
            this.textBoxQuantity = new System.Windows.Forms.TextBox();
            this.buttonAddItem = new System.Windows.Forms.Button();
            this.textBoxDescription = new System.Windows.Forms.TextBox();
            this.textBoxItemName = new System.Windows.Forms.TextBox();
            this.buttonDeleteItemIn = new System.Windows.Forms.Button();
            stockInMasterIDLabel = new System.Windows.Forms.Label();
            client_idLabel = new System.Windows.Forms.Label();
            sInDateLabel = new System.Windows.Forms.Label();
            label1 = new System.Windows.Forms.Label();
            label2 = new System.Windows.Forms.Label();
            label3 = new System.Windows.Forms.Label();
            label4 = new System.Windows.Forms.Label();
            label5 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.sastockDataSet_InMasterDetail)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.stockInMasterBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.stockInMasterBindingNavigator)).BeginInit();
            this.stockInMasterBindingNavigator.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.clientinfoBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sastockDataSetClient)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.stockInDetailBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.stockInDetailDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.itemsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.itemsDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.categoryBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sastockDataSetCategory)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_ItemBalance)).BeginInit();
            this.SuspendLayout();
            // 
            // stockInMasterIDLabel
            // 
            stockInMasterIDLabel.AutoSize = true;
            stockInMasterIDLabel.Location = new System.Drawing.Point(13, 41);
            stockInMasterIDLabel.Name = "stockInMasterIDLabel";
            stockInMasterIDLabel.Size = new System.Drawing.Size(99, 13);
            stockInMasterIDLabel.TabIndex = 1;
            stockInMasterIDLabel.Text = "Stock In Master ID:";
            // 
            // client_idLabel
            // 
            client_idLabel.AutoSize = true;
            client_idLabel.Location = new System.Drawing.Point(13, 67);
            client_idLabel.Name = "client_idLabel";
            client_idLabel.Size = new System.Drawing.Size(46, 13);
            client_idLabel.TabIndex = 3;
            client_idLabel.Text = "client id:";
            // 
            // sInDateLabel
            // 
            sInDateLabel.AutoSize = true;
            sInDateLabel.Location = new System.Drawing.Point(13, 95);
            sInDateLabel.Name = "sInDateLabel";
            sInDateLabel.Size = new System.Drawing.Size(52, 13);
            sInDateLabel.TabIndex = 5;
            sInDateLabel.Text = "SIn Date:";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new System.Drawing.Point(595, 25);
            label1.Name = "label1";
            label1.Size = new System.Drawing.Size(52, 13);
            label1.TabIndex = 10;
            label1.Text = "Catagory:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new System.Drawing.Point(584, 55);
            label2.Name = "label2";
            label2.Size = new System.Drawing.Size(67, 13);
            label2.TabIndex = 11;
            label2.Text = "Search Item:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new System.Drawing.Point(658, 124);
            label3.Name = "label3";
            label3.Size = new System.Drawing.Size(49, 13);
            label3.TabIndex = 15;
            label3.Text = "Quantity:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new System.Drawing.Point(777, 124);
            label4.Name = "label4";
            label4.Size = new System.Drawing.Size(63, 13);
            label4.TabIndex = 18;
            label4.Text = "Description:";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new System.Drawing.Point(586, 80);
            label5.Name = "label5";
            label5.Size = new System.Drawing.Size(61, 13);
            label5.TabIndex = 20;
            label5.Text = "Item Name:";
            // 
            // sastockDataSet_InMasterDetail
            // 
            this.sastockDataSet_InMasterDetail.DataSetName = "sastockDataSet_InMasterDetail";
            this.sastockDataSet_InMasterDetail.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // stockInMasterBindingSource
            // 
            this.stockInMasterBindingSource.DataMember = "StockInMaster";
            this.stockInMasterBindingSource.DataSource = this.sastockDataSet_InMasterDetail;
            // 
            // stockInMasterTableAdapter
            // 
            this.stockInMasterTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.StockInDetailTableAdapter = this.stockInDetailTableAdapter;
            this.tableAdapterManager.StockInMasterTableAdapter = this.stockInMasterTableAdapter;
            this.tableAdapterManager.UpdateOrder = SA_StockInventory.sastockDataSet_InMasterDetailTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // stockInDetailTableAdapter
            // 
            this.stockInDetailTableAdapter.ClearBeforeFill = true;
            // 
            // stockInMasterBindingNavigator
            // 
            this.stockInMasterBindingNavigator.AddNewItem = this.bindingNavigatorAddNewItem;
            this.stockInMasterBindingNavigator.BindingSource = this.stockInMasterBindingSource;
            this.stockInMasterBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.stockInMasterBindingNavigator.DeleteItem = null;
            this.stockInMasterBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.toolStripButtonAssignVoucher,
            this.stockInMasterBindingNavigatorSaveItem,
            this.toolStripButtonEdit});
            this.stockInMasterBindingNavigator.Location = new System.Drawing.Point(0, 0);
            this.stockInMasterBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.stockInMasterBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.stockInMasterBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.stockInMasterBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.stockInMasterBindingNavigator.Name = "stockInMasterBindingNavigator";
            this.stockInMasterBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.stockInMasterBindingNavigator.Size = new System.Drawing.Size(1037, 25);
            this.stockInMasterBindingNavigator.TabIndex = 0;
            this.stockInMasterBindingNavigator.Text = "bindingNavigator1";
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(74, 22);
            this.bindingNavigatorAddNewItem.Text = "Add new";
            this.bindingNavigatorAddNewItem.Click += new System.EventHandler(this.bindingNavigatorAddNewItem_Click);
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(35, 22);
            this.bindingNavigatorCountItem.Text = "of {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Total number of items";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem.Text = "Move first";
            this.bindingNavigatorMoveFirstItem.Click += new System.EventHandler(this.bindingNavigatorMoveFirstItem_Click);
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem.Text = "Move previous";
            this.bindingNavigatorMovePreviousItem.Click += new System.EventHandler(this.bindingNavigatorMovePreviousItem_Click);
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Position";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Current position";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator1";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem.Text = "Move next";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveLastItem.Text = "Move last";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator2";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripButtonAssignVoucher
            // 
            this.toolStripButtonAssignVoucher.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButtonAssignVoucher.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButtonAssignVoucher.Image")));
            this.toolStripButtonAssignVoucher.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonAssignVoucher.Name = "toolStripButtonAssignVoucher";
            this.toolStripButtonAssignVoucher.Size = new System.Drawing.Size(93, 22);
            this.toolStripButtonAssignVoucher.Text = "Assign Voucher";
            this.toolStripButtonAssignVoucher.Click += new System.EventHandler(this.toolStripButtonAssignVoucher_Click);
            // 
            // stockInMasterBindingNavigatorSaveItem
            // 
            this.stockInMasterBindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("stockInMasterBindingNavigatorSaveItem.Image")));
            this.stockInMasterBindingNavigatorSaveItem.Name = "stockInMasterBindingNavigatorSaveItem";
            this.stockInMasterBindingNavigatorSaveItem.Size = new System.Drawing.Size(78, 22);
            this.stockInMasterBindingNavigatorSaveItem.Text = "Save Data";
            this.stockInMasterBindingNavigatorSaveItem.Click += new System.EventHandler(this.stockInMasterBindingNavigatorSaveItem_Click);
            // 
            // toolStripButtonEdit
            // 
            this.toolStripButtonEdit.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButtonEdit.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButtonEdit.Image")));
            this.toolStripButtonEdit.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonEdit.Name = "toolStripButtonEdit";
            this.toolStripButtonEdit.Size = new System.Drawing.Size(31, 22);
            this.toolStripButtonEdit.Text = "Edit";
            this.toolStripButtonEdit.Click += new System.EventHandler(this.toolStripButtonEdit_Click);
            // 
            // stockInMasterIDTextBox
            // 
            this.stockInMasterIDTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.stockInMasterBindingSource, "StockInMasterID", true));
            this.stockInMasterIDTextBox.Enabled = false;
            this.stockInMasterIDTextBox.Location = new System.Drawing.Point(118, 38);
            this.stockInMasterIDTextBox.Name = "stockInMasterIDTextBox";
            this.stockInMasterIDTextBox.Size = new System.Drawing.Size(68, 20);
            this.stockInMasterIDTextBox.TabIndex = 2;
            // 
            // client_idComboBox
            // 
            this.client_idComboBox.DataBindings.Add(new System.Windows.Forms.Binding("SelectedValue", this.stockInMasterBindingSource, "client_id", true));
            this.client_idComboBox.DataSource = this.clientinfoBindingSource;
            this.client_idComboBox.DisplayMember = "client_name";
            this.client_idComboBox.FormattingEnabled = true;
            this.client_idComboBox.Location = new System.Drawing.Point(118, 64);
            this.client_idComboBox.Name = "client_idComboBox";
            this.client_idComboBox.Size = new System.Drawing.Size(371, 21);
            this.client_idComboBox.TabIndex = 4;
            this.client_idComboBox.ValueMember = "client_id";
            // 
            // clientinfoBindingSource
            // 
            this.clientinfoBindingSource.DataMember = "Client_info";
            this.clientinfoBindingSource.DataSource = this.sastockDataSetClient;
            // 
            // sastockDataSetClient
            // 
            this.sastockDataSetClient.DataSetName = "sastockDataSetClient";
            this.sastockDataSetClient.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // sInDateDateTimePicker
            // 
            this.sInDateDateTimePicker.CustomFormat = "dd/MM/yyyy";
            this.sInDateDateTimePicker.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.stockInMasterBindingSource, "SInDate", true));
            this.sInDateDateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.sInDateDateTimePicker.Location = new System.Drawing.Point(118, 91);
            this.sInDateDateTimePicker.Name = "sInDateDateTimePicker";
            this.sInDateDateTimePicker.Size = new System.Drawing.Size(111, 20);
            this.sInDateDateTimePicker.TabIndex = 6;
            // 
            // stockInDetailBindingSource
            // 
            this.stockInDetailBindingSource.DataMember = "StockInMaster_StockInDetail";
            this.stockInDetailBindingSource.DataSource = this.stockInMasterBindingSource;
            // 
            // stockInDetailDataGridView
            // 
            this.stockInDetailDataGridView.AllowUserToAddRows = false;
            this.stockInDetailDataGridView.AllowUserToDeleteRows = false;
            this.stockInDetailDataGridView.AllowUserToResizeColumns = false;
            this.stockInDetailDataGridView.AllowUserToResizeRows = false;
            this.stockInDetailDataGridView.AutoGenerateColumns = false;
            this.stockInDetailDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.stockInDetailDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5});
            this.stockInDetailDataGridView.DataSource = this.stockInDetailBindingSource;
            this.stockInDetailDataGridView.Location = new System.Drawing.Point(12, 163);
            this.stockInDetailDataGridView.Name = "stockInDetailDataGridView";
            this.stockInDetailDataGridView.ReadOnly = true;
            this.stockInDetailDataGridView.Size = new System.Drawing.Size(465, 229);
            this.stockInDetailDataGridView.TabIndex = 7;
            this.stockInDetailDataGridView.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.stockInDetailDataGridView_CellEndEdit);
            this.stockInDetailDataGridView.RowHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.stockInDetailDataGridView_RowHeaderMouseClick);
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "StockInDetailID";
            this.dataGridViewTextBoxColumn1.HeaderText = "ID";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            this.dataGridViewTextBoxColumn1.Width = 50;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "StockInMasterID";
            this.dataGridViewTextBoxColumn2.HeaderText = "StockInMasterID";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            this.dataGridViewTextBoxColumn2.Visible = false;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "ItemID";
            this.dataGridViewTextBoxColumn3.DataSource = this.itemsBindingSource;
            this.dataGridViewTextBoxColumn3.DisplayMember = "items_name";
            this.dataGridViewTextBoxColumn3.HeaderText = "Items";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            this.dataGridViewTextBoxColumn3.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn3.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dataGridViewTextBoxColumn3.ValueMember = "items_id";
            this.dataGridViewTextBoxColumn3.Width = 200;
            // 
            // itemsBindingSource
            // 
            this.itemsBindingSource.DataMember = "Items";
            this.itemsBindingSource.DataSource = this.itemsDataSet;
            // 
            // itemsDataSet
            // 
            this.itemsDataSet.DataSetName = "ItemsDataSet";
            this.itemsDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "ItemQty";
            this.dataGridViewTextBoxColumn4.HeaderText = "Quantity";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.ReadOnly = true;
            this.dataGridViewTextBoxColumn4.Width = 50;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "ItemDesc";
            this.dataGridViewTextBoxColumn5.HeaderText = "Description";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.ReadOnly = true;
            // 
            // client_infoTableAdapter
            // 
            this.client_infoTableAdapter.ClearBeforeFill = true;
            // 
            // itemsTableAdapter
            // 
            this.itemsTableAdapter.ClearBeforeFill = true;
            // 
            // buttonPrintVoucherSin
            // 
            this.buttonPrintVoucherSin.Location = new System.Drawing.Point(300, 121);
            this.buttonPrintVoucherSin.Name = "buttonPrintVoucherSin";
            this.buttonPrintVoucherSin.Size = new System.Drawing.Size(129, 23);
            this.buttonPrintVoucherSin.TabIndex = 8;
            this.buttonPrintVoucherSin.Text = "Print Inward Voucher";
            this.buttonPrintVoucherSin.UseVisualStyleBackColor = true;
            this.buttonPrintVoucherSin.Click += new System.EventHandler(this.buttonPrintVoucherSin_Click);
            // 
            // comboBox1
            // 
            this.comboBox1.DataSource = this.categoryBindingSource;
            this.comboBox1.DisplayMember = "category_name";
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(666, 22);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(150, 21);
            this.comboBox1.TabIndex = 9;
            this.comboBox1.ValueMember = "category_id";
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // categoryBindingSource
            // 
            this.categoryBindingSource.DataMember = "Category";
            this.categoryBindingSource.DataSource = this.sastockDataSetCategory;
            // 
            // sastockDataSetCategory
            // 
            this.sastockDataSetCategory.DataSetName = "sastockDataSetCategory";
            this.sastockDataSetCategory.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // categoryTableAdapter
            // 
            this.categoryTableAdapter.ClearBeforeFill = true;
            // 
            // dataGridView_ItemBalance
            // 
            this.dataGridView_ItemBalance.AllowUserToAddRows = false;
            this.dataGridView_ItemBalance.AllowUserToDeleteRows = false;
            this.dataGridView_ItemBalance.AllowUserToResizeColumns = false;
            this.dataGridView_ItemBalance.AllowUserToResizeRows = false;
            this.dataGridView_ItemBalance.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_ItemBalance.Location = new System.Drawing.Point(517, 163);
            this.dataGridView_ItemBalance.Name = "dataGridView_ItemBalance";
            this.dataGridView_ItemBalance.ReadOnly = true;
            this.dataGridView_ItemBalance.Size = new System.Drawing.Size(494, 229);
            this.dataGridView_ItemBalance.TabIndex = 13;
            this.dataGridView_ItemBalance.RowHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dataGridView_ItemBalance_RowHeaderMouseClick);
            // 
            // textBoxItems
            // 
            this.textBoxItems.Location = new System.Drawing.Point(666, 51);
            this.textBoxItems.Name = "textBoxItems";
            this.textBoxItems.Size = new System.Drawing.Size(150, 20);
            this.textBoxItems.TabIndex = 14;
            this.textBoxItems.TextChanged += new System.EventHandler(this.textBoxItems_TextChanged);
            // 
            // textBoxQuantity
            // 
            this.textBoxQuantity.Location = new System.Drawing.Point(710, 121);
            this.textBoxQuantity.Name = "textBoxQuantity";
            this.textBoxQuantity.Size = new System.Drawing.Size(57, 20);
            this.textBoxQuantity.TabIndex = 16;
            this.textBoxQuantity.TextChanged += new System.EventHandler(this.textBoxQuantity_TextChanged);
            // 
            // buttonAddItem
            // 
            this.buttonAddItem.Location = new System.Drawing.Point(526, 119);
            this.buttonAddItem.Name = "buttonAddItem";
            this.buttonAddItem.Size = new System.Drawing.Size(96, 23);
            this.buttonAddItem.TabIndex = 17;
            this.buttonAddItem.Text = "Add Item In";
            this.buttonAddItem.UseVisualStyleBackColor = true;
            this.buttonAddItem.Click += new System.EventHandler(this.buttonAddItem_Click);
            // 
            // textBoxDescription
            // 
            this.textBoxDescription.Location = new System.Drawing.Point(839, 120);
            this.textBoxDescription.Name = "textBoxDescription";
            this.textBoxDescription.Size = new System.Drawing.Size(164, 20);
            this.textBoxDescription.TabIndex = 19;
            // 
            // textBoxItemName
            // 
            this.textBoxItemName.BackColor = System.Drawing.Color.GhostWhite;
            this.textBoxItemName.Enabled = false;
            this.textBoxItemName.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxItemName.ForeColor = System.Drawing.SystemColors.WindowText;
            this.textBoxItemName.Location = new System.Drawing.Point(666, 77);
            this.textBoxItemName.Name = "textBoxItemName";
            this.textBoxItemName.Size = new System.Drawing.Size(331, 20);
            this.textBoxItemName.TabIndex = 21;
            // 
            // buttonDeleteItemIn
            // 
            this.buttonDeleteItemIn.Enabled = false;
            this.buttonDeleteItemIn.Location = new System.Drawing.Point(50, 120);
            this.buttonDeleteItemIn.Name = "buttonDeleteItemIn";
            this.buttonDeleteItemIn.Size = new System.Drawing.Size(107, 23);
            this.buttonDeleteItemIn.TabIndex = 22;
            this.buttonDeleteItemIn.Text = "Delete Item";
            this.buttonDeleteItemIn.UseVisualStyleBackColor = true;
            this.buttonDeleteItemIn.Click += new System.EventHandler(this.buttonDeleteItemIn_Click);
            // 
            // FormStockInMasterDetail
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1037, 471);
            this.Controls.Add(this.buttonDeleteItemIn);
            this.Controls.Add(this.textBoxItemName);
            this.Controls.Add(label5);
            this.Controls.Add(this.textBoxDescription);
            this.Controls.Add(label4);
            this.Controls.Add(this.buttonAddItem);
            this.Controls.Add(this.textBoxQuantity);
            this.Controls.Add(label3);
            this.Controls.Add(this.textBoxItems);
            this.Controls.Add(this.dataGridView_ItemBalance);
            this.Controls.Add(label2);
            this.Controls.Add(label1);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.buttonPrintVoucherSin);
            this.Controls.Add(this.stockInDetailDataGridView);
            this.Controls.Add(stockInMasterIDLabel);
            this.Controls.Add(this.stockInMasterIDTextBox);
            this.Controls.Add(client_idLabel);
            this.Controls.Add(this.client_idComboBox);
            this.Controls.Add(sInDateLabel);
            this.Controls.Add(this.sInDateDateTimePicker);
            this.Controls.Add(this.stockInMasterBindingNavigator);
            this.ForeColor = System.Drawing.SystemColors.ControlText;
            this.Name = "FormStockInMasterDetail";
            this.Text = "Stock In";
            this.Load += new System.EventHandler(this.FormStockInMasterDetail_Load);
            ((System.ComponentModel.ISupportInitialize)(this.sastockDataSet_InMasterDetail)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.stockInMasterBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.stockInMasterBindingNavigator)).EndInit();
            this.stockInMasterBindingNavigator.ResumeLayout(false);
            this.stockInMasterBindingNavigator.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.clientinfoBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sastockDataSetClient)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.stockInDetailBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.stockInDetailDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.itemsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.itemsDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.categoryBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sastockDataSetCategory)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_ItemBalance)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private sastockDataSet_InMasterDetail sastockDataSet_InMasterDetail;
        private System.Windows.Forms.BindingSource stockInMasterBindingSource;
        private sastockDataSet_InMasterDetailTableAdapters.StockInMasterTableAdapter stockInMasterTableAdapter;
        private sastockDataSet_InMasterDetailTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.BindingNavigator stockInMasterBindingNavigator;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton stockInMasterBindingNavigatorSaveItem;
        private sastockDataSet_InMasterDetailTableAdapters.StockInDetailTableAdapter stockInDetailTableAdapter;
        private System.Windows.Forms.TextBox stockInMasterIDTextBox;
        private System.Windows.Forms.ComboBox client_idComboBox;
        private System.Windows.Forms.DateTimePicker sInDateDateTimePicker;
        private System.Windows.Forms.BindingSource stockInDetailBindingSource;
        private System.Windows.Forms.DataGridView stockInDetailDataGridView;
        private System.Windows.Forms.ToolStripButton toolStripButtonAssignVoucher;
        private System.Windows.Forms.ToolStripButton toolStripButtonEdit;
        private sastockDataSetClient sastockDataSetClient;
        private System.Windows.Forms.BindingSource clientinfoBindingSource;
        private sastockDataSetClientTableAdapters.Client_infoTableAdapter client_infoTableAdapter;
        private ItemsDataSet itemsDataSet;
        private System.Windows.Forms.BindingSource itemsBindingSource;
        private ItemsDataSetTableAdapters.ItemsTableAdapter itemsTableAdapter;
        private System.Windows.Forms.Button buttonPrintVoucherSin;
        private System.Windows.Forms.ComboBox comboBox1;
        private sastockDataSetCategory sastockDataSetCategory;
        private System.Windows.Forms.BindingSource categoryBindingSource;
        private sastockDataSetCategoryTableAdapters.CategoryTableAdapter categoryTableAdapter;
        private System.Windows.Forms.DataGridView dataGridView_ItemBalance;
        private System.Windows.Forms.TextBox textBoxItems;
        private System.Windows.Forms.TextBox textBoxQuantity;
        private System.Windows.Forms.Button buttonAddItem;
        private System.Windows.Forms.TextBox textBoxDescription;
        private System.Windows.Forms.TextBox textBoxItemName;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewComboBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.Button buttonDeleteItemIn;
    }
}