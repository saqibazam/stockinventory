﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Configuration;
using System.IO;
using System.Security.Cryptography;
using System.Windows.Forms;

namespace SA_StockInventory
{
    public partial class FormUsers : Form
    {
        public FormUsers()
        {
            InitializeComponent();
        }
        Class_Connection cn = new Class_Connection();
        //DialogResult dlgResult;
        SqlDataAdapter adapt;
        SqlCommand cmd;
        int i = 1;

        private void buttonNew_Click(object sender, EventArgs e)
        {
            textBoxUserID.Text = "";
            textBoxUserName.Text = "";
            textBoxPassword.Text = "";
            textBoxDescription.Text = "";
            checkBoxActive.Checked = false;

            buttonNew.Enabled = false;
            button_Insert.Enabled = true;
            button_Update.Enabled = false;
        }

        private void button_Insert_Click(object sender, EventArgs e)
        {
            try
            {
                if (textBoxUserName.Text != "" && textBoxPassword.Text != "")
                {
                    cn.con.Open();
                    cmd = new SqlCommand("crudUserRights", cn.con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add(new SqlParameter("@StatementType", "InsertUser"));
                    cmd.Parameters.AddWithValue("@user_name", textBoxUserName.Text);
                    cmd.Parameters.AddWithValue("@user_password", Encrypt(textBoxPassword.Text));
                    cmd.Parameters.AddWithValue("@description", textBoxDescription.Text);
                    cmd.Parameters.AddWithValue("@rights_enable", checkBoxActive.Checked);
                    cmd.ExecuteNonQuery();
                    cn.con.Close();
                    MessageBox.Show("Record Inserted Successfully");
                    DisplayDataInGrid();

                    buttonNew.Enabled = true ;
                    button_Insert.Enabled = false ;
                    button_Update.Enabled = true ;
                }
                else
                {
                    MessageBox.Show("Only for New Record, Please Fill All Fields!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(Convert.ToString(ex));
            }
        }



        private string Encrypt(string strText)
        {
            byte[] byKey = new byte[20];
            byte[] dv = { 0x12, 0x34, 0x56, 0x78, 0x90, 0xAB, 0xCD, 0xEF };
            try
            {
                string strEncrypt = "!!@#$%^&.,/'*_*&^";
                byKey = System.Text.Encoding.UTF8.GetBytes(strEncrypt.Substring(0, 8));
                DESCryptoServiceProvider des = new DESCryptoServiceProvider();
                byte[] inputArray = System.Text.Encoding.UTF8.GetBytes(strText);
                MemoryStream ms = new MemoryStream();
                CryptoStream cs = new CryptoStream(ms, des.CreateEncryptor(byKey, dv), CryptoStreamMode.Write);
                cs.Write(inputArray, 0, inputArray.Length);
                cs.FlushFinalBlock();
                return Convert.ToBase64String(ms.ToArray());
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private string Decrypt(string strText)
        {
            string strEncrypt = "!!@#$%^&.,/'*_*&^";
            byte[] bKey = new byte[20];
            byte[] IV = { 0x12, 0x34, 0x56, 0x78, 0x90, 0xAB, 0xCD, 0xEF };

            //try
            //{
            bKey = System.Text.Encoding.UTF8.GetBytes(strEncrypt.Substring(0, 8));
            DESCryptoServiceProvider des = new DESCryptoServiceProvider();
            Byte[] inputByteArray = inputByteArray = Convert.FromBase64String(strText);
            MemoryStream ms = new MemoryStream();
            CryptoStream cs = new CryptoStream(ms, des.CreateDecryptor(bKey, IV), CryptoStreamMode.Write);
            cs.Write(inputByteArray, 0, inputByteArray.Length);
            cs.FlushFinalBlock();
            System.Text.Encoding encoding = System.Text.Encoding.UTF8;
            return encoding.GetString(ms.ToArray());
            //}
            //catch (Exception ex)
            //{
            //   // throw ex;
            //}
        }


        private void DisplayDatainTextBox(int i)
        {
           cn.con.Open();
            cmd = new SqlCommand();
            try
            {
                //cmd = new SqlCommand("select items_id, items_name, items_desc, items_size, category_id, entrydate from Items where items_id = '"+i+"'", cn.con);
                cmd = new SqlCommand("crudUserRights", cn.con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add(new SqlParameter("@StatementType", "SelectUsers"));
                cmd.Parameters.Add(new SqlParameter("@user_id", i));

                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    textBoxUserID.Text = reader["user_id"].ToString();
                    textBoxUserName.Text = reader["user_name"].ToString();
                    textBoxPassword.Text = Decrypt(reader["user_password"].ToString());
                    textBoxDescription.Text = reader["description"].ToString();
                    checkBoxActive.Checked  = (reader.GetBoolean(reader.GetOrdinal("isActive")));


                }
                reader.Close();
                cn.con.Close();
                this.userRightsAssignTableAdapter.FillByUserID(this.sastockDataSetUserRightsAssign.UserRightsAssign, Convert.ToInt16(textBoxUserID.Text));

            }
            catch (Exception x)
            {
                MessageBox.Show(x.GetBaseException().ToString(), "Error",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                cmd.InitializeLifetimeService();

                cn.con.Close();

            }

        }


        private void DisplayDataInGrid()
        {
          

            cn.con.Open();
            DataTable dt = new DataTable();
            adapt = new SqlDataAdapter("select * from Users", cn.con);
            adapt.Fill(dt);
            dataGridViewUsers.DataSource = dt;
            cn.con.Close();
            dataGridViewUsers.Columns[0].HeaderText = "User ID";
            dataGridViewUsers.Columns[0].Width = 50;
            dataGridViewUsers.Columns[1].HeaderText = "User Name";
            dataGridViewUsers.Columns[1].Width = 120;
            dataGridViewUsers.Columns[2].Visible = false;
            dataGridViewUsers.Columns[3].Visible = false;
            dataGridViewUsers.Columns[4].Visible = false;

        }



        private void FormUsers_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'sastockDataSetUserRightsAssign.UserRightsAssign' table. You can move, or remove it, as needed.
            DisplayDataInGrid();
            DisplayDatainTextBox(i);

            buttonNew.Enabled = true;
            button_Insert.Enabled = false;
            button_Update.Enabled = true;
        }

        private void button_Update_Click(object sender, EventArgs e)
        {
            try
            {
                if (textBoxUserName.Text != "" && textBoxPassword.Text != "")
                {
                    //cmd = new SqlCommand("update Items set items_name=@name,items_desc=@desc, items_size=@size, category_id=@catID where items_id=@Itemid", cn.con);
                    this.Validate();
                    this.userRightsAssignBindingSource.EndEdit();
                    this.tableAdapterManager.UpdateAll(this.sastockDataSetUserRightsAssign);
                    cn.con.Open();
                    cmd = new SqlCommand("crudUserRights", cn.con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add(new SqlParameter("@StatementType", "UpdateUser"));
                    cmd.Parameters.AddWithValue("@user_id", textBoxUserID.Text);
                    cmd.Parameters.AddWithValue("@user_name", textBoxUserName.Text);
                    cmd.Parameters.AddWithValue("@user_password", Encrypt(textBoxPassword.Text));
                    cmd.Parameters.AddWithValue("@description", textBoxDescription.Text);
                    cmd.Parameters.AddWithValue("@isactive", checkBoxActive.Checked);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Record Updated Successfully");
                    cn.con.Close();
                    DisplayDatainTextBox(i);
                    DisplayDataInGrid();

                    buttonNew.Enabled = true;
                    button_Insert.Enabled = false;
                    button_Update.Enabled = false ;
                }
                else
                {
                    MessageBox.Show("Please Select Record to Update");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(Convert.ToString(ex));
            }
        }

        private void dataGridViewUsers_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
           


        }

        private void dataGridViewUsers_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            textBoxUserID.Text = dataGridViewUsers.Rows[e.RowIndex].Cells[0].Value.ToString();
            i = Convert.ToInt16(textBoxUserID.Text);
            DisplayDatainTextBox(i);

            buttonNew.Enabled = false;
            button_Insert.Enabled = false;
            button_Update.Enabled = true;
        }

        private void userRightsAssignBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.userRightsAssignBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.sastockDataSetUserRightsAssign);

        }

        private void userRightsAssignDataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
