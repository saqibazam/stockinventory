﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SA_StockInventory
{
    public partial class Stock_Balance : Form
    {
        public Stock_Balance()
        {
            InitializeComponent();
        }

        private void Stock_Balance_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'itemsDataSet.Items' table. You can move, or remove it, as needed.
            this.itemsTableAdapter.Fill(this.itemsDataSet.Items);
            // TODO: This line of code loads data into the 'sastockDataSetCategory.Category' table. You can move, or remove it, as needed.
            this.categoryTableAdapter.Fill(this.sastockDataSetCategory.Category);
            // TODO: This line of code loads data into the 'ViewStockBalance.View_StockBalance' table. You can move, or remove it, as needed.
            this.View_StockBalanceTableAdapter.Fill(this.ViewStockBalance.View_StockBalance, Convert.ToInt16(comboBox1.SelectedValue));

            this.reportViewer1.RefreshReport();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
           
            // TODO: This line of code loads data into the 'ViewStockBalance.View_StockBalance' table. You can move, or remove it, as needed.
            this.View_StockBalanceTableAdapter.Fill(this.ViewStockBalance.View_StockBalance, Convert.ToInt16(comboBox1.SelectedValue));

            this.reportViewer1.RefreshReport();
        }

        private void comboBoxItem_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.View_StockBalanceTableAdapter.FillByItem(this.ViewStockBalance.View_StockBalance, Convert.ToInt16(comboBoxItem.SelectedValue));

            this.reportViewer1.RefreshReport();

        }
    }
}
