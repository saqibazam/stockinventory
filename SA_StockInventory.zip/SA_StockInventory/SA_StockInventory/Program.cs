﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SA_StockInventory
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            try
            {
                Application.EnableVisualStyles();
                Application.SetCompatibleTextRenderingDefault(false);
               
                
                  Application.Run(new FormLogin());
                // Application.Run(new MDIParentStock());

                // Application.Run(new FormStockOutMaster_Detail());

               //  Application.Run(new FormStockInMasterDetail());

                //  Application.Run(new FormMDSout());

                //  Application.Run(new FormUsers());

                // Application.Run(new RptIssuesList());

                //  Application.Run(new RptOutList());



                //   Application.Run(new FromStockOutMasterDetailFinal());
            }
            catch (Exception x)
            {
                MessageBox.Show(x.GetBaseException().ToString(), "Error",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }
    }
}
