﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SA_StockInventory
{
    public partial class RptOutList : Form
    {
        public RptOutList()
        {
            InitializeComponent();
        }

        private void RptOutList_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'ViewSaOut.View_StockOut' table. You can move, or remove it, as needed.
         //   this.View_StockOutTableAdapter.Fill(this.ViewSaOut.View_StockOut);
            // TODO: This line of code loads data into the 'ViewSaOut.View_StockOut' table. You can move, or remove it, as needed.
            //      this.View_StockOutTableAdapter.Fill(this.ViewSaOut.View_StockOut);
            // TODO: This line of code loads data into the 'sastockDataSetCategory.Category' table. You can move, or remove it, as needed.
            this.categoryTableAdapter.Fill(this.sastockDataSetCategory.Category);
            // TODO: This line of code loads data into the 'sastockDataSetEmpOnly.Employees' table. You can move, or remove it, as needed.
            this.employeesTableAdapter.Fill(this.sastockDataSetEmpOnly.Employees);
            // TODO: This line of code loads data into the 'sastockDataSetBranch.Branch' table. You can move, or remove it, as needed.
            this.branchTableAdapter.Fill(this.sastockDataSetBranch.Branch);

      
            this.reportViewerSout.RefreshReport();
        }

        private void buttonSearch_Click(object sender, EventArgs e)
        {

            if (checkBoxDate .Checked == true )
            { 
            this.View_StockOutTableAdapter.FillByDate(this.ViewSaOut.View_StockOut, Convert.ToDateTime(dateTimePickerFrom.Text), Convert.ToDateTime(dateTimePickerTo.Text));
            this.reportViewerSout.ZoomMode = Microsoft.Reporting.WinForms.ZoomMode.PageWidth;
            this.reportViewerSout.RefreshReport();
            }

            //if branch is checked && catagory not checked && employee not checked
            if(checkBoxBranch .Checked == true && checkBoxCatagory .Checked == false && checkBoxEmployee .Checked == false && checkBoxDate.Checked == true)
           // if (comboBoxBranch.Text != "" && comboBoxCatagory.Text == "" && comboBoxEmployee.Text == "")
            {
                this.View_StockOutTableAdapter.FillByDateBranch(this.ViewSaOut.View_StockOut, Convert.ToInt16(comboBoxBranch.SelectedValue), Convert.ToDateTime(dateTimePickerFrom.Text), Convert.ToDateTime(dateTimePickerTo.Text));
                this.reportViewerSout.ZoomMode = Microsoft.Reporting.WinForms.ZoomMode.PageWidth;
                this.reportViewerSout.RefreshReport();
            }

          //  if (comboBoxBranch.Text == "" && comboBoxCatagory.Text != "" && comboBoxEmployee.Text == "")
                if(checkBoxBranch .Checked == false && checkBoxCatagory .Checked == true && checkBoxEmployee .Checked == false && checkBoxDate.Checked == true)
            {
                this.View_StockOutTableAdapter.FillByCatagory(this.ViewSaOut.View_StockOut, Convert.ToInt16(comboBoxCatagory.SelectedValue), Convert.ToDateTime(dateTimePickerFrom.Text), Convert.ToDateTime(dateTimePickerTo.Text));
                this.reportViewerSout.ZoomMode = Microsoft.Reporting.WinForms.ZoomMode.PageWidth;
                this.reportViewerSout.RefreshReport();
            }

            //if (comboBoxBranch.Text == "" && comboBoxCatagory.Text == "" && comboBoxEmployee.Text != "")
            if(checkBoxBranch .Checked == false &&  checkBoxCatagory .Checked == false && checkBoxEmployee .Checked == true && checkBoxDate.Checked == true)
            {
                this.View_StockOutTableAdapter.FillByEmployee(this.ViewSaOut.View_StockOut, Convert.ToInt16(comboBoxEmployee.SelectedValue), Convert.ToDateTime(dateTimePickerFrom.Text), Convert.ToDateTime(dateTimePickerTo.Text));
                this.reportViewerSout.ZoomMode = Microsoft.Reporting.WinForms.ZoomMode.PageWidth;
                this.reportViewerSout.RefreshReport();
            }

            if (checkBoxBranch.Checked == true  && checkBoxCatagory.Checked == true  && checkBoxEmployee.Checked == false && checkBoxDate.Checked == true)
            //    if (comboBoxBranch.Text != "" && comboBoxCatagory.Text != "" && comboBoxEmployee.Text == "")
            {
                this.View_StockOutTableAdapter.FillByBranchCatagory(this.ViewSaOut.View_StockOut, Convert.ToInt16(comboBoxBranch.SelectedValue), Convert.ToInt16(comboBoxCatagory.SelectedValue), Convert.ToDateTime(dateTimePickerFrom.Text), Convert.ToDateTime(dateTimePickerTo.Text));
                this.reportViewerSout.ZoomMode = Microsoft.Reporting.WinForms.ZoomMode.PageWidth;
                this.reportViewerSout.RefreshReport();
            }

            if (checkBoxBranch.Checked == false && checkBoxCatagory.Checked == true  && checkBoxEmployee.Checked == true && checkBoxDate.Checked == true)
              //  if (comboBoxBranch.Text == "" && comboBoxCatagory.Text != "" && comboBoxEmployee.Text != "")
            {
                this.View_StockOutTableAdapter.FillByEmployeeCatagory(this.ViewSaOut.View_StockOut, Convert.ToInt16(comboBoxEmployee.SelectedValue), Convert.ToInt16(comboBoxCatagory.SelectedValue), Convert.ToDateTime(dateTimePickerFrom.Text), Convert.ToDateTime(dateTimePickerTo.Text));
                this.reportViewerSout.ZoomMode = Microsoft.Reporting.WinForms.ZoomMode.PageWidth;
                this.reportViewerSout.RefreshReport();

            }


        }
    }
}
