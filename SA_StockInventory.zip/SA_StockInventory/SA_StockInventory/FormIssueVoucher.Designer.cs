﻿namespace SA_StockInventory
{
    partial class FormIssueVoucher
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource1 = new Microsoft.Reporting.WinForms.ReportDataSource();
            this.View_StockOutBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.ViewSaOut = new SA_StockInventory.ViewSaOut();
            this.reportViewer1 = new Microsoft.Reporting.WinForms.ReportViewer();
            this.View_StockOutTableAdapter = new SA_StockInventory.ViewSaOutTableAdapters.View_StockOutTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.View_StockOutBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ViewSaOut)).BeginInit();
            this.SuspendLayout();
            // 
            // View_StockOutBindingSource
            // 
            this.View_StockOutBindingSource.DataMember = "View_StockOut";
            this.View_StockOutBindingSource.DataSource = this.ViewSaOut;
            // 
            // ViewSaOut
            // 
            this.ViewSaOut.DataSetName = "ViewSaOut";
            this.ViewSaOut.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // reportViewer1
            // 
            this.reportViewer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.reportViewer1.DocumentMapWidth = 6;
            reportDataSource1.Name = "DataSet1";
            reportDataSource1.Value = this.View_StockOutBindingSource;
            this.reportViewer1.LocalReport.DataSources.Add(reportDataSource1);
            this.reportViewer1.LocalReport.ReportEmbeddedResource = "SA_StockInventory.Report1.rdlc";
            this.reportViewer1.Location = new System.Drawing.Point(0, 0);
            this.reportViewer1.Margin = new System.Windows.Forms.Padding(0);
            this.reportViewer1.Name = "reportViewer1";
            this.reportViewer1.Size = new System.Drawing.Size(821, 432);
            this.reportViewer1.TabIndex = 2;
            this.reportViewer1.Load += new System.EventHandler(this.reportViewer1_Load_1);
            // 
            // View_StockOutTableAdapter
            // 
            this.View_StockOutTableAdapter.ClearBeforeFill = true;
            // 
            // FormIssueVoucher
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(821, 432);
            this.Controls.Add(this.reportViewer1);
            this.Name = "FormIssueVoucher";
            this.Text = "Issue Voucher";
            this.Load += new System.EventHandler(this.FormIssueVoucher_Load);
            ((System.ComponentModel.ISupportInitialize)(this.View_StockOutBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ViewSaOut)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private Microsoft.Reporting.WinForms.ReportViewer reportViewer1;
        private System.Windows.Forms.BindingSource View_StockOutBindingSource;
        private ViewSaOut ViewSaOut;
        private ViewSaOutTableAdapters.View_StockOutTableAdapter View_StockOutTableAdapter;
    }
}