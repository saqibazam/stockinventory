﻿namespace SA_StockInventory
{


    partial class ViewSaIN
    {
    }
}

namespace SA_StockInventory.ViewSaINTableAdapters {
    
    
    public partial class View_StockInTableAdapter {
    }
}
