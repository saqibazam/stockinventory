﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SA_StockInventory
{
    public partial class FormMDSout : Form
    {
        public FormMDSout()
        {
            InitializeComponent();
        }

        private void stock_Out_MasterBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
        
        }

        private void stock_Out_MasterBindingNavigatorSaveItem_Click_1(object sender, EventArgs e)
        {
            this.Validate();
            this.stock_Out_MasterBindingSource.EndEdit();
            this.stockOutDetailBindingSource.EndEdit();
          
            this.tableAdapterManager.UpdateAll(this.sastockDataSet_OutMasterDetail);

        }

        private void FormMDSout_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'sastockDataSet_OutMasterDetail.StockOutDetail' table. You can move, or remove it, as needed.
            this.stockOutDetailTableAdapter.Fill(this.sastockDataSet_OutMasterDetail.StockOutDetail);
            // TODO: This line of code loads data into the 'sastockDataSet_OutMasterDetail.Stock_Out_Master' table. You can move, or remove it, as needed.
            this.stock_Out_MasterTableAdapter.Fill(this.sastockDataSet_OutMasterDetail.Stock_Out_Master);

        }
    }
}
