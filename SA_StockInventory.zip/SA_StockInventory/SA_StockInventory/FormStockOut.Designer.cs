﻿namespace SA_StockInventory
{
    partial class FormStockOut
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label stock_out_idLabel;
            System.Windows.Forms.Label emp_idLabel;
            System.Windows.Forms.Label item_idLabel;
            System.Windows.Forms.Label outdateLabel;
            this.outdateDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.buttonNew = new System.Windows.Forms.Button();
            this.button_Update = new System.Windows.Forms.Button();
            this.button_Insert = new System.Windows.Forms.Button();
            this.buttonShowGrid = new System.Windows.Forms.Button();
            this.buttonShowLast = new System.Windows.Forms.Button();
            this.buttonShowTop = new System.Windows.Forms.Button();
            this.buttonPrintVoucher = new System.Windows.Forms.Button();
            this.sastockDataSetStock_Out = new SA_StockInventory.sastockDataSetStock_Out();
            this.stock_outBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.stock_outTableAdapter = new SA_StockInventory.sastockDataSetStock_OutTableAdapters.Stock_outTableAdapter();
            this.tableAdapterManager = new SA_StockInventory.sastockDataSetStock_OutTableAdapters.TableAdapterManager();
            this.stock_outDataGridView = new System.Windows.Forms.DataGridView();
            this.itemsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.itemsDataSet = new SA_StockInventory.ItemsDataSet();
            this.employeesBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.sastockDataSetEmployee = new SA_StockInventory.sastockDataSetEmployee();
            this.sastockDataSetEmployeeBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.employeesTableAdapter = new SA_StockInventory.sastockDataSetEmployeeTableAdapters.EmployeesTableAdapter();
            this.itemsTableAdapter = new SA_StockInventory.ItemsDataSetTableAdapters.ItemsTableAdapter();
            this.emp_idComboBox = new System.Windows.Forms.ComboBox();
            this.textBoxStockMasterID = new System.Windows.Forms.TextBox();
            this.cat_idComboBox = new System.Windows.Forms.ComboBox();
            this.categoryBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.sastockDataSetCategory = new SA_StockInventory.sastockDataSetCategory();
            this.categoryTableAdapter = new SA_StockInventory.sastockDataSetCategoryTableAdapters.CategoryTableAdapter();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            stock_out_idLabel = new System.Windows.Forms.Label();
            emp_idLabel = new System.Windows.Forms.Label();
            item_idLabel = new System.Windows.Forms.Label();
            outdateLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.sastockDataSetStock_Out)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.stock_outBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.stock_outDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.itemsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.itemsDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.employeesBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sastockDataSetEmployee)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sastockDataSetEmployeeBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.categoryBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sastockDataSetCategory)).BeginInit();
            this.SuspendLayout();
            // 
            // stock_out_idLabel
            // 
            stock_out_idLabel.AutoSize = true;
            stock_out_idLabel.Location = new System.Drawing.Point(22, 26);
            stock_out_idLabel.Name = "stock_out_idLabel";
            stock_out_idLabel.Size = new System.Drawing.Size(103, 13);
            stock_out_idLabel.TabIndex = 1;
            stock_out_idLabel.Text = "Outward Voucher #:";
            // 
            // emp_idLabel
            // 
            emp_idLabel.AutoSize = true;
            emp_idLabel.Location = new System.Drawing.Point(24, 53);
            emp_idLabel.Name = "emp_idLabel";
            emp_idLabel.Size = new System.Drawing.Size(38, 13);
            emp_idLabel.TabIndex = 3;
            emp_idLabel.Text = "Name:";
            // 
            // item_idLabel
            // 
            item_idLabel.AutoSize = true;
            item_idLabel.Location = new System.Drawing.Point(24, 82);
            item_idLabel.Name = "item_idLabel";
            item_idLabel.Size = new System.Drawing.Size(52, 13);
            item_idLabel.TabIndex = 5;
            item_idLabel.Text = "Catagory:";
            item_idLabel.Click += new System.EventHandler(this.item_idLabel_Click);
            // 
            // outdateLabel
            // 
            outdateLabel.AutoSize = true;
            outdateLabel.Location = new System.Drawing.Point(24, 114);
            outdateLabel.Name = "outdateLabel";
            outdateLabel.Size = new System.Drawing.Size(33, 13);
            outdateLabel.TabIndex = 9;
            outdateLabel.Text = "Date:";
            // 
            // outdateDateTimePicker
            // 
            this.outdateDateTimePicker.CustomFormat = "yyyy-MM-dd";
            this.outdateDateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.outdateDateTimePicker.Location = new System.Drawing.Point(146, 108);
            this.outdateDateTimePicker.Name = "outdateDateTimePicker";
            this.outdateDateTimePicker.Size = new System.Drawing.Size(118, 20);
            this.outdateDateTimePicker.TabIndex = 10;
            // 
            // buttonNew
            // 
            this.buttonNew.Location = new System.Drawing.Point(24, 151);
            this.buttonNew.Name = "buttonNew";
            this.buttonNew.Size = new System.Drawing.Size(75, 23);
            this.buttonNew.TabIndex = 31;
            this.buttonNew.Text = "New";
            this.buttonNew.UseVisualStyleBackColor = true;
            this.buttonNew.Click += new System.EventHandler(this.buttonNew_Click);
            // 
            // button_Update
            // 
            this.button_Update.Location = new System.Drawing.Point(256, 151);
            this.button_Update.Name = "button_Update";
            this.button_Update.Size = new System.Drawing.Size(75, 23);
            this.button_Update.TabIndex = 29;
            this.button_Update.Text = "Update";
            this.button_Update.UseVisualStyleBackColor = true;
            this.button_Update.Click += new System.EventHandler(this.button_Update_Click);
            // 
            // button_Insert
            // 
            this.button_Insert.Location = new System.Drawing.Point(136, 151);
            this.button_Insert.Name = "button_Insert";
            this.button_Insert.Size = new System.Drawing.Size(75, 23);
            this.button_Insert.TabIndex = 28;
            this.button_Insert.Text = "Insert";
            this.button_Insert.UseVisualStyleBackColor = true;
            this.button_Insert.Click += new System.EventHandler(this.button_Insert_Click);
            // 
            // buttonShowGrid
            // 
            this.buttonShowGrid.Location = new System.Drawing.Point(648, 151);
            this.buttonShowGrid.Name = "buttonShowGrid";
            this.buttonShowGrid.Size = new System.Drawing.Size(82, 23);
            this.buttonShowGrid.TabIndex = 26;
            this.buttonShowGrid.Text = "Show Grid";
            this.buttonShowGrid.UseVisualStyleBackColor = true;
            this.buttonShowGrid.Click += new System.EventHandler(this.buttonShowAll_Click);
            // 
            // buttonShowLast
            // 
            this.buttonShowLast.Location = new System.Drawing.Point(648, 105);
            this.buttonShowLast.Name = "buttonShowLast";
            this.buttonShowLast.Size = new System.Drawing.Size(82, 23);
            this.buttonShowLast.TabIndex = 25;
            this.buttonShowLast.Text = "Show Last 10";
            this.buttonShowLast.UseVisualStyleBackColor = true;
            this.buttonShowLast.Click += new System.EventHandler(this.buttonShowLast_Click);
            // 
            // buttonShowTop
            // 
            this.buttonShowTop.Location = new System.Drawing.Point(648, 72);
            this.buttonShowTop.Name = "buttonShowTop";
            this.buttonShowTop.Size = new System.Drawing.Size(82, 23);
            this.buttonShowTop.TabIndex = 24;
            this.buttonShowTop.Text = "Show Top 10";
            this.buttonShowTop.UseVisualStyleBackColor = true;
            this.buttonShowTop.Click += new System.EventHandler(this.buttonShowTop_Click);
            // 
            // buttonPrintVoucher
            // 
            this.buttonPrintVoucher.Location = new System.Drawing.Point(632, 26);
            this.buttonPrintVoucher.Name = "buttonPrintVoucher";
            this.buttonPrintVoucher.Size = new System.Drawing.Size(98, 23);
            this.buttonPrintVoucher.TabIndex = 32;
            this.buttonPrintVoucher.Text = "Print Voucher";
            this.buttonPrintVoucher.UseVisualStyleBackColor = true;
            this.buttonPrintVoucher.Click += new System.EventHandler(this.buttonPrintVoucher_Click);
            // 
            // sastockDataSetStock_Out
            // 
            this.sastockDataSetStock_Out.DataSetName = "sastockDataSetStock_Out";
            this.sastockDataSetStock_Out.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // stock_outBindingSource
            // 
            this.stock_outBindingSource.DataMember = "Stock_out";
            this.stock_outBindingSource.DataSource = this.sastockDataSetStock_Out;
            // 
            // stock_outTableAdapter
            // 
            this.stock_outTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.Stock_outTableAdapter = this.stock_outTableAdapter;
            this.tableAdapterManager.UpdateOrder = SA_StockInventory.sastockDataSetStock_OutTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // stock_outDataGridView
            // 
            this.stock_outDataGridView.AutoGenerateColumns = false;
            this.stock_outDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.stock_outDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn6});
            this.stock_outDataGridView.DataSource = this.stock_outBindingSource;
            this.stock_outDataGridView.Location = new System.Drawing.Point(25, 194);
            this.stock_outDataGridView.Name = "stock_outDataGridView";
            this.stock_outDataGridView.Size = new System.Drawing.Size(705, 278);
            this.stock_outDataGridView.TabIndex = 33;
            this.stock_outDataGridView.RowHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.stock_outDataGridView_RowHeaderMouseClick);
            // 
            // itemsBindingSource
            // 
            this.itemsBindingSource.DataMember = "Items";
            this.itemsBindingSource.DataSource = this.itemsDataSet;
            // 
            // itemsDataSet
            // 
            this.itemsDataSet.DataSetName = "ItemsDataSet";
            this.itemsDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // employeesBindingSource
            // 
            this.employeesBindingSource.DataMember = "Employees";
            this.employeesBindingSource.DataSource = this.sastockDataSetEmployee;
            // 
            // sastockDataSetEmployee
            // 
            this.sastockDataSetEmployee.DataSetName = "sastockDataSetEmployee";
            this.sastockDataSetEmployee.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // sastockDataSetEmployeeBindingSource
            // 
            this.sastockDataSetEmployeeBindingSource.DataSource = this.sastockDataSetEmployee;
            this.sastockDataSetEmployeeBindingSource.Position = 0;
            // 
            // employeesTableAdapter
            // 
            this.employeesTableAdapter.ClearBeforeFill = true;
            // 
            // itemsTableAdapter
            // 
            this.itemsTableAdapter.ClearBeforeFill = true;
            // 
            // emp_idComboBox
            // 
            this.emp_idComboBox.DataSource = this.employeesBindingSource;
            this.emp_idComboBox.DisplayMember = "EmpName";
            this.emp_idComboBox.FormattingEnabled = true;
            this.emp_idComboBox.Location = new System.Drawing.Point(146, 50);
            this.emp_idComboBox.Name = "emp_idComboBox";
            this.emp_idComboBox.Size = new System.Drawing.Size(325, 21);
            this.emp_idComboBox.TabIndex = 34;
            this.emp_idComboBox.ValueMember = "EmpID";
            // 
            // textBoxStockMasterID
            // 
            this.textBoxStockMasterID.Location = new System.Drawing.Point(146, 24);
            this.textBoxStockMasterID.Name = "textBoxStockMasterID";
            this.textBoxStockMasterID.Size = new System.Drawing.Size(80, 20);
            this.textBoxStockMasterID.TabIndex = 37;
            // 
            // cat_idComboBox
            // 
            this.cat_idComboBox.DataSource = this.categoryBindingSource;
            this.cat_idComboBox.DisplayMember = "category_name";
            this.cat_idComboBox.FormattingEnabled = true;
            this.cat_idComboBox.Location = new System.Drawing.Point(146, 79);
            this.cat_idComboBox.Name = "cat_idComboBox";
            this.cat_idComboBox.Size = new System.Drawing.Size(325, 21);
            this.cat_idComboBox.TabIndex = 38;
            this.cat_idComboBox.ValueMember = "category_id";
            this.cat_idComboBox.SelectedIndexChanged += new System.EventHandler(this.cat_idComboBox_SelectedIndexChanged);
            // 
            // categoryBindingSource
            // 
            this.categoryBindingSource.DataMember = "Category";
            this.categoryBindingSource.DataSource = this.sastockDataSetCategory;
            // 
            // sastockDataSetCategory
            // 
            this.sastockDataSetCategory.DataSetName = "sastockDataSetCategory";
            this.sastockDataSetCategory.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // categoryTableAdapter
            // 
            this.categoryTableAdapter.ClearBeforeFill = true;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "stock_out_id";
            this.dataGridViewTextBoxColumn1.HeaderText = "ID";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            this.dataGridViewTextBoxColumn1.Width = 50;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "item_id";
            this.dataGridViewTextBoxColumn3.DataSource = this.itemsBindingSource;
            this.dataGridViewTextBoxColumn3.DisplayMember = "items_name";
            this.dataGridViewTextBoxColumn3.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.ComboBox;
            this.dataGridViewTextBoxColumn3.HeaderText = "Items Name";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn3.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dataGridViewTextBoxColumn3.ValueMember = "items_id";
            this.dataGridViewTextBoxColumn3.Width = 300;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "qty_out";
            this.dataGridViewTextBoxColumn4.HeaderText = "Quantity";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.Width = 50;
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "description";
            this.dataGridViewTextBoxColumn6.HeaderText = "Description";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            this.dataGridViewTextBoxColumn6.Width = 200;
            // 
            // FormStockOut
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(764, 500);
            this.Controls.Add(this.cat_idComboBox);
            this.Controls.Add(this.textBoxStockMasterID);
            this.Controls.Add(this.emp_idComboBox);
            this.Controls.Add(this.stock_outDataGridView);
            this.Controls.Add(this.buttonPrintVoucher);
            this.Controls.Add(this.buttonNew);
            this.Controls.Add(this.button_Update);
            this.Controls.Add(this.button_Insert);
            this.Controls.Add(this.buttonShowGrid);
            this.Controls.Add(this.buttonShowLast);
            this.Controls.Add(this.buttonShowTop);
            this.Controls.Add(stock_out_idLabel);
            this.Controls.Add(emp_idLabel);
            this.Controls.Add(item_idLabel);
            this.Controls.Add(outdateLabel);
            this.Controls.Add(this.outdateDateTimePicker);
            this.Name = "FormStockOut";
            this.Text = "Form Stock Out";
            this.Load += new System.EventHandler(this.FormStockOut_Load);
            ((System.ComponentModel.ISupportInitialize)(this.sastockDataSetStock_Out)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.stock_outBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.stock_outDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.itemsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.itemsDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.employeesBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sastockDataSetEmployee)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sastockDataSetEmployeeBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.categoryBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sastockDataSetCategory)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.DateTimePicker outdateDateTimePicker;
        private System.Windows.Forms.Button buttonNew;
        private System.Windows.Forms.Button button_Update;
        private System.Windows.Forms.Button button_Insert;
        private System.Windows.Forms.Button buttonShowGrid;
        private System.Windows.Forms.Button buttonShowLast;
        private System.Windows.Forms.Button buttonShowTop;
        private System.Windows.Forms.Button buttonPrintVoucher;
        private sastockDataSetStock_Out sastockDataSetStock_Out;
        private System.Windows.Forms.BindingSource stock_outBindingSource;
        private sastockDataSetStock_OutTableAdapters.Stock_outTableAdapter stock_outTableAdapter;
        private sastockDataSetStock_OutTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.DataGridView stock_outDataGridView;
        private sastockDataSetEmployee sastockDataSetEmployee;
        private System.Windows.Forms.BindingSource sastockDataSetEmployeeBindingSource;
        private System.Windows.Forms.BindingSource employeesBindingSource;
        private sastockDataSetEmployeeTableAdapters.EmployeesTableAdapter employeesTableAdapter;
        private ItemsDataSet itemsDataSet;
        private System.Windows.Forms.BindingSource itemsBindingSource;
        private ItemsDataSetTableAdapters.ItemsTableAdapter itemsTableAdapter;
        private System.Windows.Forms.ComboBox emp_idComboBox;
        private System.Windows.Forms.TextBox textBoxStockMasterID;
        private System.Windows.Forms.ComboBox cat_idComboBox;
        private sastockDataSetCategory sastockDataSetCategory;
        private System.Windows.Forms.BindingSource categoryBindingSource;
        private sastockDataSetCategoryTableAdapters.CategoryTableAdapter categoryTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewComboBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
    }
}