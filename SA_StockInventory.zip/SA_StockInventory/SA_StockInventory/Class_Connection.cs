﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using System.Threading.Tasks;

namespace SA_StockInventory
{

    //Read Me First
    // Connection String will be update in App.config and Class_Connection.cs
    class Class_Connection
    {
       public SqlConnection con = new SqlConnection(@"Data Source=rti2k8server\rtisqlserver;Initial Catalog=sastock;Persist Security Info=True;User ID=sa;Password=Opprti@9221");

      //  public SqlConnection con = new SqlConnection(@"Data Source=192.168.0.110\mssqlserver1;Initial Catalog=sastock;Persist Security Info=True;User ID=sa;Password=softparadise");
      //  public SqlConnection con = new SqlConnection(@"Data Source=IT-L-Win7-PC-;Initial Catalog=sastock;Persist Security Info=True;User ID=sa;Password=softparadise");
    }
}
