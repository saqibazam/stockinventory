﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SA_StockInventory
{
    public partial class FormStockInMasterDetail : Form
    {
        public FormStockInMasterDetail()
        {
            InitializeComponent();
        }
        Class_Connection cn = new Class_Connection();
        DialogResult dlgResult;
        SqlCommand cmd;
        SqlDataAdapter adapt;
        DataTable da;
        int itemid;
        int balance;
        int StInDetailID;
        string SInItem_ID;
        string SInItem_Qty;


        private void stockInMasterBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
           
          
            try
            {
                this.Validate();
                this.stockInMasterBindingSource.EndEdit();
                this.stockInMasterTableAdapter.Update(this.sastockDataSet_InMasterDetail.StockInMaster);

                this.stockInDetailBindingSource.EndEdit();
                this.stockInDetailTableAdapter.Update(this.sastockDataSet_InMasterDetail.StockInDetail);


                //Save DataGrid View
                int rowsCount = stockInDetailDataGridView.Rows.Count;
                int rowsInserted = 0;
                for (int i = 0; i < rowsCount; i++)
                {
                    cn.con.Open();
                    cmd = new SqlCommand("CurrentStock", cn.con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add(new SqlParameter("@StatementType", "UpdateStockInBalance"));
                    //if (stockInDetailDataGridView.Rows[i].Cells[1].Value == null)
                    //{
                    //    cn.con.Close();
                    //    break;

                    //}

                    cmd.Parameters.AddWithValue("@itemID", stockInDetailDataGridView.Rows[i].Cells[2].Value);

                    if (cmd.ExecuteNonQuery() > 0)
                    {
                        rowsInserted++;
                    }
                    cn.con.Close();
                }//end of for loop


                ShowItemLisInGrid();
                MessageBox.Show("Record Inserted Successfully");

                client_idComboBox.Enabled = false;
                sInDateDateTimePicker.Enabled = false;
                bindingNavigatorAddNewItem.Enabled = true;
                toolStripButtonAssignVoucher.Enabled = false;
                stockInMasterBindingNavigatorSaveItem.Enabled = false;
                stockInDetailDataGridView.AllowUserToAddRows = false;
                stockInDetailDataGridView.Enabled = true;

            }
            catch (Exception ex)
            {
                MessageBox.Show(Convert.ToString(ex));
            }
        }

        private void FormStockInMasterDetail_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'sastockDataSetCategory.Category' table. You can move, or remove it, as needed.
            this.categoryTableAdapter.Fill(this.sastockDataSetCategory.Category);
            // TODO: This line of code loads data into the 'itemsDataSet.Items' table. You can move, or remove it, as needed.
            this.itemsTableAdapter.Fill(this.itemsDataSet.Items);
            try
            { 
            // TODO: This line of code loads data into the 'sastockDataSetClient.Client_info' table. You can move, or remove it, as needed.
            this.client_infoTableAdapter.Fill(this.sastockDataSetClient.Client_info);
            // TODO: This line of code loads data into the 'sastockDataSet_InMasterDetail.StockInDetail' table. You can move, or remove it, as needed.
            this.stockInDetailTableAdapter.Fill(this.sastockDataSet_InMasterDetail.StockInDetail);
            // TODO: This line of code loads data into the 'sastockDataSet_InMasterDetail.StockInMaster' table. You can move, or remove it, as needed.
            this.stockInMasterTableAdapter.Fill(this.sastockDataSet_InMasterDetail.StockInMaster);

            stockInMasterBindingSource.MoveLast();
            stockInDetailBindingSource.MoveLast();

            client_idComboBox.Enabled = false;

            sInDateDateTimePicker.Enabled = false;

            toolStripButtonAssignVoucher.Enabled = false;
            stockInMasterBindingNavigatorSaveItem.Enabled = false;
            stockInDetailDataGridView.AllowUserToAddRows = false;
            stockInDetailDataGridView.Enabled = true;

            }
            catch (Exception x)
            {
                MessageBox.Show(x.GetBaseException().ToString(), "Error",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
}





        private void bindingNavigatorAddNewItem_Click(object sender, EventArgs e)
        {
            try
            {
                // Selet Max Entry Record from Database
                //Max Master ID store in int

                cn.con.Open();
                cmd = new SqlCommand();
                cmd = new SqlCommand("crudStock_IN_MD", cn.con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add(new SqlParameter("@StatementType", "MaxStockID"));

                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    string a = "";
                    int b = 0;
                    a = reader["StockInMasterID"].ToString();
                    b = Convert.ToInt16(a) + 1;
                    stockInMasterIDTextBox.Text = b.ToString();

                    sInDateDateTimePicker.Text = DateTime.Now.ToShortDateString();


                }
                reader.Close();
                cn.con.Close();

                client_idComboBox.Enabled = true;

                sInDateDateTimePicker.Enabled = true;

                bindingNavigatorAddNewItem.Enabled = false;
                toolStripButtonAssignVoucher.Enabled = true;
                stockInMasterBindingNavigatorSaveItem.Enabled = false;
              //  stockInDetailDataGridView.AllowUserToAddRows  = false;
              //  stockInDetailDataGridView.Enabled = false;

            }
            catch (Exception x)
            {
                MessageBox.Show(x.GetBaseException().ToString(), "Error",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void toolStripButtonAssignVoucher_Click(object sender, EventArgs e)
        {
            try
            {
                this.Validate();
                this.stockInMasterBindingSource.EndEdit();
                this.stockInMasterTableAdapter.Update(this.sastockDataSet_InMasterDetail.StockInMaster);


                MessageBox.Show("Vendor Name Add Successfully");

                client_idComboBox.Enabled = true;

                sInDateDateTimePicker.Enabled = true;

                bindingNavigatorAddNewItem.Enabled = false;
                toolStripButtonAssignVoucher.Enabled = false;
                stockInMasterBindingNavigatorSaveItem.Enabled = true;


                //stockInDetailDataGridView.AllowUserToAddRows = false;
                //stockInDetailDataGridView.Enabled = false;
            }
            catch (Exception x)
            {
                MessageBox.Show(x.GetBaseException().ToString(), "Error",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void toolStripButtonEdit_Click(object sender, EventArgs e)
        {
            //Enter Super User Password to Edit the 



            client_idComboBox.Enabled = true;
            sInDateDateTimePicker.Enabled = true;
            bindingNavigatorAddNewItem.Enabled = false;
            toolStripButtonAssignVoucher.Enabled = false;
            stockInMasterBindingNavigatorSaveItem.Enabled = true;

//            stockInDetailDataGridView.Enabled = true;
        }
        public static string SetValueForTextSIn = "";

        private void buttonPrintVoucherSin_Click(object sender, EventArgs e)
        {
            SetValueForTextSIn = stockInMasterIDTextBox.Text;

         FormReceiveStock     frmrs = new FormReceiveStock();
            frmrs.Show();
        }

        private void stockInDetailDataGridView_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            //if (stockInDetailDataGridView.CurrentCell.ColumnIndex == 2) //Desired Column
            //{

            //    cn.con.Open();
            //    cmd = new SqlCommand();
            //    cmd = new SqlCommand("CurrentStock", cn.con);
            //    cmd.CommandType = CommandType.StoredProcedure;
            //    cmd.Parameters.Add(new SqlParameter("@StatementType", "BalanceStock"));
            //    cmd.Parameters.Add(new SqlParameter("@itemID", this.stockInDetailDataGridView.CurrentCell.Value.ToString()));
            //    cmd.Parameters.Add(new SqlParameter("@SumItemQtyIn", this.stockInDetailDataGridView.CurrentCell.Value.ToString()));

            //    cmd.ExecuteNonQuery();
            //    cn.con.Close();
            //}
                

            }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

     
        private void textBoxItems_TextChanged(object sender, EventArgs e)
        {
            ShowItemLisInGrid();
            
        }

        private void ShowItemLisInGrid()
        {
            cn.con.Open();
            adapt = new SqlDataAdapter("SELECT [ItemID],[items_name] ,[items_desc],[items_size] , [TotalIn]-[TotalOut] as Balance  FROM [View_StockBalance] where [category_id] = '" + comboBox1.SelectedValue + "' and items_name like '" + '%' + textBoxItems.Text + "%'", cn.con);
            da = new DataTable();
            adapt.Fill(da);
            dataGridView_ItemBalance.DataSource = da;
            cn.con.Close();
            ReDesignWidthofItemListinGrid();
        }

        private void ShowItemLisInGrid(string  item_ID)
        {
            cn.con.Open();
            adapt = new SqlDataAdapter("SELECT [ItemID],[items_name] ,[items_desc],[items_size] , [TotalIn]-[TotalOut] as Balance  FROM [View_StockBalance] where itemID ='" + item_ID + "'", cn.con);
            da = new DataTable();
            adapt.Fill(da);
            dataGridView_ItemBalance.DataSource = da;
            cn.con.Close();
            ReDesignWidthofItemListinGrid();
        }

        private void ReDesignWidthofItemListinGrid()
        {
           dataGridView_ItemBalance.Columns[0].Width = 40;
            dataGridView_ItemBalance.Columns[1].HeaderText = "Items Name";
            dataGridView_ItemBalance.Columns[1].Width = 170;
            dataGridView_ItemBalance.Columns[2].HeaderText = "Description";
            dataGridView_ItemBalance.Columns[2].Width = 100;
            dataGridView_ItemBalance.Columns[3].HeaderText = "Size";
            dataGridView_ItemBalance.Columns[3].Width = 60;
            dataGridView_ItemBalance.Columns[4].Width = 50;
        }

        private void buttonAddItem_Click(object sender, EventArgs e)
        {
           

            int qty = Convert.ToInt16(textBoxQuantity.Text);
            //check if qty / balance = 0
            if (qty == 0)
            {
                MessageBox.Show("Quantity can not be Zero");
            }
              // Check for duplicate item
                cn.con.Open();
            string itmid = Convert.ToString(itemid);

            cmd = new SqlCommand("select count(ItemID) from StockInDetail where StockInMasterID = '" + stockInMasterIDTextBox.Text + "'  and ItemID = '" + itmid+ "' ", cn.con);
            int returnval = 0;       
            returnval = Convert.ToInt32(cmd.ExecuteScalar());
            cn.con.Close();

                    if (returnval >= 1)
                    {
                        MessageBox.Show("Can not Add! This Item Already Exist");
                    }
                    if (returnval < 1 )   // If Item Id not exist
                    {
                        //Insert into StockInDetail Table
                        cn.con.Open();
                        cmd = new SqlCommand("crudStock_IN_MD", cn.con);
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.Add(new SqlParameter("@StatementType", "InsertStockDetial"));
                        cmd.Parameters.AddWithValue("@StockInMasterID", stockInMasterIDTextBox.Text);
                        cmd.Parameters.AddWithValue("@itemID", itemid);
                        cmd.Parameters.AddWithValue("@itemQty", qty);
                        cmd.Parameters.AddWithValue("@itemDesc", textBoxDescription.Text);
                        cmd.ExecuteNonQuery();
                        cn.con.Close();

                        //Update Stock
                        cn.con.Open();
                        cmd = new SqlCommand("CurrentStock", cn.con);
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.Add(new SqlParameter("@StatementType", "UpdateStockInBalance"));
                        cmd.Parameters.AddWithValue("@itemID", itemid);

                        cmd.ExecuteNonQuery();
                        cn.con.Close();
                        MessageBox.Show("This Selected Item Add Successfully");

                        buttonDeleteItemIn.Enabled = true;

                // TODO: This line of code loads data into the 'sastockDataSet_InMasterDetail.StockInDetail' table. You can move, or remove it, as needed.
                this.stockInDetailTableAdapter.Fill(this.sastockDataSet_InMasterDetail.StockInDetail);

                ShowItemLisInGrid();

            }

        }
        


    

        private void textBoxQuantity_TextChanged(object sender, EventArgs e)
        {
            if (System.Text.RegularExpressions.Regex.IsMatch(textBoxQuantity.Text, "[^0-9]"))
            {
                MessageBox.Show("Enter Only Numbers!");
                textBoxQuantity.Text = textBoxQuantity.Text.Remove(textBoxQuantity.Text.Length - 1);
            }
        }

        private void dataGridView_ItemBalance_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            itemid = Convert .ToInt16(dataGridView_ItemBalance.Rows[e.RowIndex].Cells[0].Value.ToString());
            balance = Convert.ToInt16(dataGridView_ItemBalance.Rows[e.RowIndex].Cells[4].Value.ToString());
            textBoxItemName.Text = dataGridView_ItemBalance.Rows[e.RowIndex].Cells[1].Value.ToString();
            textBoxDescription.Text = dataGridView_ItemBalance.Rows[e.RowIndex].Cells[2].Value.ToString();
            textBoxQuantity.Text = "";

            //MessageBox.Show("Values", i.ToString());
            //MessageBox.Show("Values", j.ToString());
        }





        private void buttonDelete_Click(object sender, EventArgs e)
        {

        }

        private void buttonDeleteItemIn_Click(object sender, EventArgs e)
        {
            dlgResult = MessageBox.Show("Do you want to Delete this Record", "Delete Record", MessageBoxButtons.YesNo, MessageBoxIcon.Stop );
            if (dlgResult == DialogResult.Yes)
            {

                //  select itemid, itemQty from StockinDetail where StockinDetailID = 85

                cmd = new SqlCommand("select itemID, itemQty from StockInDetail where StockInDetailID  = @StockInDetailID", cn.con);
                cmd.Parameters.AddWithValue("@StockInDetailID", StInDetailID);
                cn.con.Open();

                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    SInItem_ID = reader["itemID"].ToString();
                    SInItem_Qty = reader["itemQty"].ToString();
                }
                reader.Close();

                //Perform Check, When delete from stock IN inventory Check that Balance shoud not be negative.
                // on delete check If(QtyIn - Balance) >= 0 then perform delete operation
                // Show Message that This item can not be delete because "STOCK BALANCE" will be less than zero.

                
            //    string itmid = Convert.ToString(itemid);

                cmd = new SqlCommand("select (TotalIn - TotalOut) as balance  from StockBalance where ItemID ='" + SInItem_ID+"'", cn.con);
                int returnval = 0;
                returnval = Convert.ToInt32(cmd.ExecuteScalar());
                
                int sinItmQty = Convert.ToInt16(SInItem_Qty);

                if ((returnval - sinItmQty) < 0)
                {
                    MessageBox.Show("This item can not be delete because STOCK BALANCE will be = '" + (returnval - sinItmQty)+ "' might be less than zero.");
                    cn.con.Close();
                }
                
                if ((returnval - sinItmQty) >= 0)
                {
                    //delete this item

                    //  this itemQty will be add in StockBalance
                    //  update StockBalance set TotalIn = TotalIn + GridViewItem_Quantity where itemID = GridView_ItemID 


                    cmd = new SqlCommand("update StockBalance set TotalIn=TotalIn - @itemQty where itemid=@Itemid", cn.con);
                    //           cn.con.Open();
                    cmd.Parameters.AddWithValue("@itemQty", SInItem_Qty);
                    cmd.Parameters.AddWithValue("@Itemid", SInItem_ID);
                    cmd.ExecuteNonQuery();
                    //  MessageBox.Show("Quantity Updated Successfully");

                    //--delete from[StockOutDetail] where StockOutDetailID = 86

                    cmd = new SqlCommand("delete from [StockInDetail] where StockInDetailID =@StockInDetailID", cn.con);
                    //           cn.con.Open();
                    cmd.Parameters.AddWithValue("@StockInDetailID", StInDetailID);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Item Deleted Successfully");
                    cn.con.Close();
                    // TODO: This line of code loads data into the 'sastockDataSet_InMasterDetail.StockInDetail' table. You can move, or remove it, as needed.
                    this.stockInDetailTableAdapter.Fill(this.sastockDataSet_InMasterDetail.StockInDetail);

                    //Show Update GridViewBalance
                    ShowItemLisInGrid(SInItem_ID);


                }







            }
        }

        private void stockInDetailDataGridView_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            StInDetailID = Convert.ToInt16(stockInDetailDataGridView.Rows[e.RowIndex].Cells[0].Value.ToString());
        }

        private void bindingNavigatorMovePreviousItem_Click(object sender, EventArgs e)
        {
            string userName = FormLogin.CheckUserName;

            if (userName == "Admin" || userName == "Super")
            {
                buttonDeleteItemIn.Enabled = true;
                buttonAddItem.Enabled = true;

            }
             else

            {
                buttonDeleteItemIn.Enabled = false;
                buttonAddItem.Enabled = false;
            }
            
        }

        private void bindingNavigatorMoveFirstItem_Click(object sender, EventArgs e)
        {
            string userName = FormLogin.CheckUserName;

            if (userName == "Admin" || userName == "Super")
            {
                buttonDeleteItemIn.Enabled = true;
                buttonAddItem.Enabled = true;

            }
            else

            {
                buttonDeleteItemIn.Enabled = false;
                buttonAddItem.Enabled = false;
            }

        }
    }
}
