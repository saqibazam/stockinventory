﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Printing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SA_StockInventory
{
    public partial class FormIssueVoucher : Form
    {
        public FormIssueVoucher()
        {
            InitializeComponent();
        }

    
   
        private void FormIssueVoucher_Load(object sender, EventArgs e)
        {
            int i = Convert.ToInt16(FormStockOutMaster_Detail.SetValueForText);
            this.View_StockOutTableAdapter.Fill(this.ViewSaOut.View_StockOut, i);



            this.reportViewer1.RefreshReport();
        }

        private void reportViewer1_Load(object sender, EventArgs e)
        {
       
        }

        private void button1_Click(object sender, EventArgs e)
        {


        }

        private void reportViewer1_Load_1(object sender, EventArgs e)
        {

        }
    }
}
