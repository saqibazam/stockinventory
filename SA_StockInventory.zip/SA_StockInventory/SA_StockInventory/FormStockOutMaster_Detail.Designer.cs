﻿namespace SA_StockInventory
{
    partial class FormStockOutMaster_Detail
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label master_out_idLabel;
            System.Windows.Forms.Label emp_idLabel;
            System.Windows.Forms.Label date_soutLabel;
            System.Windows.Forms.Label label3;
            System.Windows.Forms.Label label4;
            System.Windows.Forms.Label label5;
            System.Windows.Forms.Label label6;
            System.Windows.Forms.Label label7;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormStockOutMaster_Detail));
            this.stock_Out_MasterBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.stock_Out_MasterBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.sastockDataSet_OutMasterDetail = new SA_StockInventory.sastockDataSet_OutMasterDetail();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButtonVoucherAssign = new System.Windows.Forms.ToolStripButton();
            this.stock_Out_MasterBindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
            this.toolStripButtonEdit = new System.Windows.Forms.ToolStripButton();
            this.master_out_idTextBox = new System.Windows.Forms.TextBox();
            this.emp_idComboBox = new System.Windows.Forms.ComboBox();
            this.employeesBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.sastockDataSetEmpOnly = new SA_StockInventory.sastockDataSetEmpOnly();
            this.date_soutDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.stockOutDetailBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.stockOutDetailDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.itemsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.itemsDataSet = new SA_StockInventory.ItemsDataSet();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.employeesTableAdapter = new SA_StockInventory.sastockDataSetEmpOnlyTableAdapters.EmployeesTableAdapter();
            this.itemsTableAdapter = new SA_StockInventory.ItemsDataSetTableAdapters.ItemsTableAdapter();
            this.buttonPrintVoucher = new System.Windows.Forms.Button();
            this.textBoxBalance = new System.Windows.Forms.TextBox();
            this.textBoxQtyBalance = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.comboBoxBranch = new System.Windows.Forms.ComboBox();
            this.branchBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.sastockDataSetBranchBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.sastockDataSetBranch = new SA_StockInventory.sastockDataSetBranch();
            this.branchTableAdapter = new SA_StockInventory.sastockDataSetBranchTableAdapters.BranchTableAdapter();
            this.dataGridViewItemListOut = new System.Windows.Forms.DataGridView();
            this.buttonAdd_Item = new System.Windows.Forms.Button();
            this.comboBoxCatagoryOut = new System.Windows.Forms.ComboBox();
            this.categoryBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.sastockDataSetCategory = new SA_StockInventory.sastockDataSetCategory();
            this.categoryTableAdapter = new SA_StockInventory.sastockDataSetCategoryTableAdapters.CategoryTableAdapter();
            this.textBoxSearchItemOut = new System.Windows.Forms.TextBox();
            this.textBoxItemOut = new System.Windows.Forms.TextBox();
            this.textBoxQtyOut = new System.Windows.Forms.TextBox();
            this.textBoxDescOut = new System.Windows.Forms.TextBox();
            this.buttonDeleteItem = new System.Windows.Forms.Button();
            this.stock_Out_MasterTableAdapter = new SA_StockInventory.sastockDataSet_OutMasterDetailTableAdapters.Stock_Out_MasterTableAdapter();
            this.tableAdapterManager = new SA_StockInventory.sastockDataSet_OutMasterDetailTableAdapters.TableAdapterManager();
            this.stockOutDetailTableAdapter = new SA_StockInventory.sastockDataSet_OutMasterDetailTableAdapters.StockOutDetailTableAdapter();
            master_out_idLabel = new System.Windows.Forms.Label();
            emp_idLabel = new System.Windows.Forms.Label();
            date_soutLabel = new System.Windows.Forms.Label();
            label3 = new System.Windows.Forms.Label();
            label4 = new System.Windows.Forms.Label();
            label5 = new System.Windows.Forms.Label();
            label6 = new System.Windows.Forms.Label();
            label7 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.stock_Out_MasterBindingNavigator)).BeginInit();
            this.stock_Out_MasterBindingNavigator.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.stock_Out_MasterBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sastockDataSet_OutMasterDetail)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.employeesBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sastockDataSetEmpOnly)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.stockOutDetailBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.stockOutDetailDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.itemsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.itemsDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.branchBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sastockDataSetBranchBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sastockDataSetBranch)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewItemListOut)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.categoryBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sastockDataSetCategory)).BeginInit();
            this.SuspendLayout();
            // 
            // master_out_idLabel
            // 
            master_out_idLabel.AutoSize = true;
            master_out_idLabel.Location = new System.Drawing.Point(24, 44);
            master_out_idLabel.Name = "master_out_idLabel";
            master_out_idLabel.Size = new System.Drawing.Size(60, 13);
            master_out_idLabel.TabIndex = 1;
            master_out_idLabel.Text = "Voucher #:";
            // 
            // emp_idLabel
            // 
            emp_idLabel.AutoSize = true;
            emp_idLabel.Location = new System.Drawing.Point(24, 70);
            emp_idLabel.Name = "emp_idLabel";
            emp_idLabel.Size = new System.Drawing.Size(38, 13);
            emp_idLabel.TabIndex = 3;
            emp_idLabel.Text = "Name:";
            // 
            // date_soutLabel
            // 
            date_soutLabel.AutoSize = true;
            date_soutLabel.Location = new System.Drawing.Point(24, 98);
            date_soutLabel.Name = "date_soutLabel";
            date_soutLabel.Size = new System.Drawing.Size(33, 13);
            date_soutLabel.TabIndex = 5;
            date_soutLabel.Text = "Date:";
            date_soutLabel.Click += new System.EventHandler(this.date_soutLabel_Click);
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new System.Drawing.Point(562, 36);
            label3.Name = "label3";
            label3.Size = new System.Drawing.Size(52, 13);
            label3.TabIndex = 17;
            label3.Text = "Catagory:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new System.Drawing.Point(547, 62);
            label4.Name = "label4";
            label4.Size = new System.Drawing.Size(67, 13);
            label4.TabIndex = 18;
            label4.Text = "Search Item:";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new System.Drawing.Point(678, 145);
            label5.Name = "label5";
            label5.Size = new System.Drawing.Size(49, 13);
            label5.TabIndex = 20;
            label5.Text = "Quantity:";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new System.Drawing.Point(547, 93);
            label6.Name = "label6";
            label6.Size = new System.Drawing.Size(61, 13);
            label6.TabIndex = 21;
            label6.Text = "Item Name:";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new System.Drawing.Point(793, 146);
            label7.Name = "label7";
            label7.Size = new System.Drawing.Size(63, 13);
            label7.TabIndex = 23;
            label7.Text = "Description:";
            // 
            // stock_Out_MasterBindingNavigator
            // 
            this.stock_Out_MasterBindingNavigator.AddNewItem = this.bindingNavigatorAddNewItem;
            this.stock_Out_MasterBindingNavigator.BindingSource = this.stock_Out_MasterBindingSource;
            this.stock_Out_MasterBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.stock_Out_MasterBindingNavigator.DeleteItem = null;
            this.stock_Out_MasterBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.toolStripButtonVoucherAssign,
            this.stock_Out_MasterBindingNavigatorSaveItem,
            this.toolStripButtonEdit});
            this.stock_Out_MasterBindingNavigator.Location = new System.Drawing.Point(0, 0);
            this.stock_Out_MasterBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.stock_Out_MasterBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.stock_Out_MasterBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.stock_Out_MasterBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.stock_Out_MasterBindingNavigator.Name = "stock_Out_MasterBindingNavigator";
            this.stock_Out_MasterBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.stock_Out_MasterBindingNavigator.Size = new System.Drawing.Size(1044, 25);
            this.stock_Out_MasterBindingNavigator.TabIndex = 0;
            this.stock_Out_MasterBindingNavigator.Text = "bindingNavigator1";
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(74, 22);
            this.bindingNavigatorAddNewItem.Text = "Add new";
            this.bindingNavigatorAddNewItem.Click += new System.EventHandler(this.bindingNavigatorAddNewItem_Click);
            // 
            // stock_Out_MasterBindingSource
            // 
            this.stock_Out_MasterBindingSource.DataMember = "Stock_Out_Master";
            this.stock_Out_MasterBindingSource.DataSource = this.sastockDataSet_OutMasterDetail;
            // 
            // sastockDataSet_OutMasterDetail
            // 
            this.sastockDataSet_OutMasterDetail.DataSetName = "sastockDataSet_OutMasterDetail";
            this.sastockDataSet_OutMasterDetail.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(35, 22);
            this.bindingNavigatorCountItem.Text = "of {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Total number of items";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem.Text = "Move first";
            this.bindingNavigatorMoveFirstItem.Click += new System.EventHandler(this.bindingNavigatorMoveFirstItem_Click);
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem.Text = "Move previous";
            this.bindingNavigatorMovePreviousItem.Click += new System.EventHandler(this.bindingNavigatorMovePreviousItem_Click);
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Position";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Current position";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator1";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem.Text = "Move next";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveLastItem.Text = "Move last";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator2";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripButtonVoucherAssign
            // 
            this.toolStripButtonVoucherAssign.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButtonVoucherAssign.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButtonVoucherAssign.Image")));
            this.toolStripButtonVoucherAssign.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonVoucherAssign.Name = "toolStripButtonVoucherAssign";
            this.toolStripButtonVoucherAssign.Size = new System.Drawing.Size(93, 22);
            this.toolStripButtonVoucherAssign.Text = "Assign Voucher";
            this.toolStripButtonVoucherAssign.Click += new System.EventHandler(this.toolStripButtonVoucherAssign_Click);
            // 
            // stock_Out_MasterBindingNavigatorSaveItem
            // 
            this.stock_Out_MasterBindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("stock_Out_MasterBindingNavigatorSaveItem.Image")));
            this.stock_Out_MasterBindingNavigatorSaveItem.Name = "stock_Out_MasterBindingNavigatorSaveItem";
            this.stock_Out_MasterBindingNavigatorSaveItem.Size = new System.Drawing.Size(78, 22);
            this.stock_Out_MasterBindingNavigatorSaveItem.Text = "Save Data";
            this.stock_Out_MasterBindingNavigatorSaveItem.Click += new System.EventHandler(this.stock_Out_MasterBindingNavigatorSaveItem_Click);
            // 
            // toolStripButtonEdit
            // 
            this.toolStripButtonEdit.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButtonEdit.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButtonEdit.Image")));
            this.toolStripButtonEdit.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonEdit.Name = "toolStripButtonEdit";
            this.toolStripButtonEdit.Size = new System.Drawing.Size(31, 22);
            this.toolStripButtonEdit.Text = "Edit";
            this.toolStripButtonEdit.Click += new System.EventHandler(this.toolStripButtonEdit_Click);
            // 
            // master_out_idTextBox
            // 
            this.master_out_idTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.stock_Out_MasterBindingSource, "Master_out_id", true));
            this.master_out_idTextBox.Enabled = false;
            this.master_out_idTextBox.Location = new System.Drawing.Point(101, 41);
            this.master_out_idTextBox.Name = "master_out_idTextBox";
            this.master_out_idTextBox.Size = new System.Drawing.Size(82, 20);
            this.master_out_idTextBox.TabIndex = 2;
            // 
            // emp_idComboBox
            // 
            this.emp_idComboBox.DataBindings.Add(new System.Windows.Forms.Binding("SelectedValue", this.stock_Out_MasterBindingSource, "emp_id", true));
            this.emp_idComboBox.DataSource = this.employeesBindingSource;
            this.emp_idComboBox.DisplayMember = "EmpName";
            this.emp_idComboBox.FormattingEnabled = true;
            this.emp_idComboBox.Location = new System.Drawing.Point(101, 67);
            this.emp_idComboBox.Name = "emp_idComboBox";
            this.emp_idComboBox.Size = new System.Drawing.Size(380, 21);
            this.emp_idComboBox.TabIndex = 4;
            this.emp_idComboBox.ValueMember = "EmpID";
            // 
            // employeesBindingSource
            // 
            this.employeesBindingSource.DataMember = "Employees";
            this.employeesBindingSource.DataSource = this.sastockDataSetEmpOnly;
            // 
            // sastockDataSetEmpOnly
            // 
            this.sastockDataSetEmpOnly.DataSetName = "sastockDataSetEmpOnly";
            this.sastockDataSetEmpOnly.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // date_soutDateTimePicker
            // 
            this.date_soutDateTimePicker.CustomFormat = "dd/MM/yyyy";
            this.date_soutDateTimePicker.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.stock_Out_MasterBindingSource, "date_sout", true));
            this.date_soutDateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.date_soutDateTimePicker.Location = new System.Drawing.Point(101, 94);
            this.date_soutDateTimePicker.Name = "date_soutDateTimePicker";
            this.date_soutDateTimePicker.Size = new System.Drawing.Size(151, 20);
            this.date_soutDateTimePicker.TabIndex = 6;
            // 
            // stockOutDetailBindingSource
            // 
            this.stockOutDetailBindingSource.DataMember = "Stock_Out_Master_StockOutDetail";
            this.stockOutDetailBindingSource.DataSource = this.stock_Out_MasterBindingSource;
            // 
            // stockOutDetailDataGridView
            // 
            this.stockOutDetailDataGridView.AllowUserToAddRows = false;
            this.stockOutDetailDataGridView.AllowUserToDeleteRows = false;
            this.stockOutDetailDataGridView.AllowUserToResizeColumns = false;
            this.stockOutDetailDataGridView.AllowUserToResizeRows = false;
            this.stockOutDetailDataGridView.AutoGenerateColumns = false;
            this.stockOutDetailDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.stockOutDetailDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5});
            this.stockOutDetailDataGridView.DataSource = this.stockOutDetailBindingSource;
            this.stockOutDetailDataGridView.Location = new System.Drawing.Point(27, 190);
            this.stockOutDetailDataGridView.Name = "stockOutDetailDataGridView";
            this.stockOutDetailDataGridView.ReadOnly = true;
            this.stockOutDetailDataGridView.Size = new System.Drawing.Size(465, 249);
            this.stockOutDetailDataGridView.TabIndex = 7;
            this.stockOutDetailDataGridView.CellBeginEdit += new System.Windows.Forms.DataGridViewCellCancelEventHandler(this.stockOutDetailDataGridView_CellBeginEdit);
            this.stockOutDetailDataGridView.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.stockOutDetailDataGridView_CellContentClick);
            this.stockOutDetailDataGridView.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.stockOutDetailDataGridView_CellEndEdit);
            this.stockOutDetailDataGridView.CellValueChanged += new System.Windows.Forms.DataGridViewCellEventHandler(this.stockOutDetailDataGridView_CellValueChanged);
            this.stockOutDetailDataGridView.CurrentCellDirtyStateChanged += new System.EventHandler(this.stockOutDetailDataGridView_CurrentCellDirtyStateChanged);
            this.stockOutDetailDataGridView.RowHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.stockOutDetailDataGridView_RowHeaderMouseClick);
            this.stockOutDetailDataGridView.RowsRemoved += new System.Windows.Forms.DataGridViewRowsRemovedEventHandler(this.stockOutDetailDataGridView_RowsRemoved);
            this.stockOutDetailDataGridView.RowValidated += new System.Windows.Forms.DataGridViewCellEventHandler(this.stockOutDetailDataGridView_RowValidated);
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "StockOutDetailID";
            this.dataGridViewTextBoxColumn1.HeaderText = "ID";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            this.dataGridViewTextBoxColumn1.Width = 50;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "StockMasterID";
            this.dataGridViewTextBoxColumn2.HeaderText = "StockMasterID";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            this.dataGridViewTextBoxColumn2.Visible = false;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "itemID";
            this.dataGridViewTextBoxColumn3.DataSource = this.itemsBindingSource;
            this.dataGridViewTextBoxColumn3.DisplayMember = "items_name";
            this.dataGridViewTextBoxColumn3.HeaderText = "Items";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            this.dataGridViewTextBoxColumn3.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn3.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dataGridViewTextBoxColumn3.ValueMember = "items_id";
            this.dataGridViewTextBoxColumn3.Width = 200;
            // 
            // itemsBindingSource
            // 
            this.itemsBindingSource.DataMember = "Items";
            this.itemsBindingSource.DataSource = this.itemsDataSet;
            // 
            // itemsDataSet
            // 
            this.itemsDataSet.DataSetName = "ItemsDataSet";
            this.itemsDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "itemQty";
            this.dataGridViewTextBoxColumn4.HeaderText = "Quantity";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.ReadOnly = true;
            this.dataGridViewTextBoxColumn4.Width = 50;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "itemDesc";
            this.dataGridViewTextBoxColumn5.HeaderText = "Description";
            this.dataGridViewTextBoxColumn5.MaxInputLength = 50;
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.ReadOnly = true;
            // 
            // employeesTableAdapter
            // 
            this.employeesTableAdapter.ClearBeforeFill = true;
            // 
            // itemsTableAdapter
            // 
            this.itemsTableAdapter.ClearBeforeFill = true;
            // 
            // buttonPrintVoucher
            // 
            this.buttonPrintVoucher.Location = new System.Drawing.Point(268, 141);
            this.buttonPrintVoucher.Name = "buttonPrintVoucher";
            this.buttonPrintVoucher.Size = new System.Drawing.Size(132, 23);
            this.buttonPrintVoucher.TabIndex = 8;
            this.buttonPrintVoucher.Text = "Print Outward Voucher";
            this.buttonPrintVoucher.UseVisualStyleBackColor = true;
            this.buttonPrintVoucher.Click += new System.EventHandler(this.buttonPrintVoucher_Click);
            // 
            // textBoxBalance
            // 
            this.textBoxBalance.BackColor = System.Drawing.SystemColors.MenuBar;
            this.textBoxBalance.Enabled = false;
            this.textBoxBalance.ForeColor = System.Drawing.SystemColors.WindowText;
            this.textBoxBalance.Location = new System.Drawing.Point(283, 107);
            this.textBoxBalance.Name = "textBoxBalance";
            this.textBoxBalance.Size = new System.Drawing.Size(19, 20);
            this.textBoxBalance.TabIndex = 9;
            this.textBoxBalance.Visible = false;
            this.textBoxBalance.TextChanged += new System.EventHandler(this.textBoxBalance_TextChanged);
            // 
            // textBoxQtyBalance
            // 
            this.textBoxQtyBalance.Enabled = false;
            this.textBoxQtyBalance.ForeColor = System.Drawing.SystemColors.WindowText;
            this.textBoxQtyBalance.Location = new System.Drawing.Point(380, 108);
            this.textBoxQtyBalance.Name = "textBoxQtyBalance";
            this.textBoxQtyBalance.Size = new System.Drawing.Size(62, 20);
            this.textBoxQtyBalance.TabIndex = 10;
            this.textBoxQtyBalance.Visible = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(322, 111);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(52, 13);
            this.label1.TabIndex = 11;
            this.label1.Text = "Balance :";
            this.label1.Visible = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(189, 43);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(44, 13);
            this.label2.TabIndex = 12;
            this.label2.Text = "Branch:";
            // 
            // comboBoxBranch
            // 
            this.comboBoxBranch.DataBindings.Add(new System.Windows.Forms.Binding("SelectedValue", this.stock_Out_MasterBindingSource, "branch_id", true));
            this.comboBoxBranch.DataSource = this.branchBindingSource;
            this.comboBoxBranch.DisplayMember = "branch_name";
            this.comboBoxBranch.FormattingEnabled = true;
            this.comboBoxBranch.Location = new System.Drawing.Point(249, 40);
            this.comboBoxBranch.Name = "comboBoxBranch";
            this.comboBoxBranch.Size = new System.Drawing.Size(193, 21);
            this.comboBoxBranch.TabIndex = 13;
            this.comboBoxBranch.ValueMember = "branch_id";
            // 
            // branchBindingSource
            // 
            this.branchBindingSource.DataMember = "Branch";
            this.branchBindingSource.DataSource = this.sastockDataSetBranchBindingSource;
            // 
            // sastockDataSetBranchBindingSource
            // 
            this.sastockDataSetBranchBindingSource.DataSource = this.sastockDataSetBranch;
            this.sastockDataSetBranchBindingSource.Position = 0;
            // 
            // sastockDataSetBranch
            // 
            this.sastockDataSetBranch.DataSetName = "sastockDataSetBranch";
            this.sastockDataSetBranch.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // branchTableAdapter
            // 
            this.branchTableAdapter.ClearBeforeFill = true;
            // 
            // dataGridViewItemListOut
            // 
            this.dataGridViewItemListOut.AllowUserToAddRows = false;
            this.dataGridViewItemListOut.AllowUserToDeleteRows = false;
            this.dataGridViewItemListOut.AllowUserToResizeColumns = false;
            this.dataGridViewItemListOut.AllowUserToResizeRows = false;
            this.dataGridViewItemListOut.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewItemListOut.Location = new System.Drawing.Point(537, 190);
            this.dataGridViewItemListOut.Name = "dataGridViewItemListOut";
            this.dataGridViewItemListOut.ReadOnly = true;
            this.dataGridViewItemListOut.Size = new System.Drawing.Size(494, 249);
            this.dataGridViewItemListOut.TabIndex = 14;
            this.dataGridViewItemListOut.RowHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dataGridViewItemListOut_RowHeaderMouseClick);
            // 
            // buttonAdd_Item
            // 
            this.buttonAdd_Item.Location = new System.Drawing.Point(550, 141);
            this.buttonAdd_Item.Name = "buttonAdd_Item";
            this.buttonAdd_Item.Size = new System.Drawing.Size(104, 23);
            this.buttonAdd_Item.TabIndex = 15;
            this.buttonAdd_Item.Text = "Add Item Out";
            this.buttonAdd_Item.UseVisualStyleBackColor = true;
            this.buttonAdd_Item.Click += new System.EventHandler(this.buttonAdd_Item_Click);
            // 
            // comboBoxCatagoryOut
            // 
            this.comboBoxCatagoryOut.DataSource = this.categoryBindingSource;
            this.comboBoxCatagoryOut.DisplayMember = "category_name";
            this.comboBoxCatagoryOut.FormattingEnabled = true;
            this.comboBoxCatagoryOut.Location = new System.Drawing.Point(639, 33);
            this.comboBoxCatagoryOut.Name = "comboBoxCatagoryOut";
            this.comboBoxCatagoryOut.Size = new System.Drawing.Size(167, 21);
            this.comboBoxCatagoryOut.TabIndex = 16;
            this.comboBoxCatagoryOut.ValueMember = "category_id";
            // 
            // categoryBindingSource
            // 
            this.categoryBindingSource.DataMember = "Category";
            this.categoryBindingSource.DataSource = this.sastockDataSetCategory;
            // 
            // sastockDataSetCategory
            // 
            this.sastockDataSetCategory.DataSetName = "sastockDataSetCategory";
            this.sastockDataSetCategory.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // categoryTableAdapter
            // 
            this.categoryTableAdapter.ClearBeforeFill = true;
            // 
            // textBoxSearchItemOut
            // 
            this.textBoxSearchItemOut.Location = new System.Drawing.Point(639, 62);
            this.textBoxSearchItemOut.Name = "textBoxSearchItemOut";
            this.textBoxSearchItemOut.Size = new System.Drawing.Size(167, 20);
            this.textBoxSearchItemOut.TabIndex = 19;
            this.textBoxSearchItemOut.TextChanged += new System.EventHandler(this.textBoxSearchItemOut_TextChanged);
            // 
            // textBoxItemOut
            // 
            this.textBoxItemOut.Enabled = false;
            this.textBoxItemOut.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxItemOut.Location = new System.Drawing.Point(639, 90);
            this.textBoxItemOut.Name = "textBoxItemOut";
            this.textBoxItemOut.Size = new System.Drawing.Size(375, 20);
            this.textBoxItemOut.TabIndex = 22;
            // 
            // textBoxQtyOut
            // 
            this.textBoxQtyOut.Location = new System.Drawing.Point(734, 143);
            this.textBoxQtyOut.Name = "textBoxQtyOut";
            this.textBoxQtyOut.Size = new System.Drawing.Size(48, 20);
            this.textBoxQtyOut.TabIndex = 24;
            this.textBoxQtyOut.TextChanged += new System.EventHandler(this.textBoxQtyOut_TextChanged);
            // 
            // textBoxDescOut
            // 
            this.textBoxDescOut.Location = new System.Drawing.Point(859, 144);
            this.textBoxDescOut.Name = "textBoxDescOut";
            this.textBoxDescOut.Size = new System.Drawing.Size(155, 20);
            this.textBoxDescOut.TabIndex = 25;
            // 
            // buttonDeleteItem
            // 
            this.buttonDeleteItem.Enabled = false;
            this.buttonDeleteItem.Location = new System.Drawing.Point(58, 142);
            this.buttonDeleteItem.Name = "buttonDeleteItem";
            this.buttonDeleteItem.Size = new System.Drawing.Size(108, 23);
            this.buttonDeleteItem.TabIndex = 26;
            this.buttonDeleteItem.Text = "Delete Item";
            this.buttonDeleteItem.UseVisualStyleBackColor = true;
            this.buttonDeleteItem.Click += new System.EventHandler(this.buttonDeleteItem_Click);
            // 
            // stock_Out_MasterTableAdapter
            // 
            this.stock_Out_MasterTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.Stock_Out_MasterTableAdapter = this.stock_Out_MasterTableAdapter;
            this.tableAdapterManager.StockOutDetailTableAdapter = this.stockOutDetailTableAdapter;
            this.tableAdapterManager.UpdateOrder = SA_StockInventory.sastockDataSet_OutMasterDetailTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // stockOutDetailTableAdapter
            // 
            this.stockOutDetailTableAdapter.ClearBeforeFill = true;
            // 
            // FormStockOutMaster_Detail
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1044, 473);
            this.Controls.Add(this.buttonDeleteItem);
            this.Controls.Add(this.textBoxDescOut);
            this.Controls.Add(this.textBoxQtyOut);
            this.Controls.Add(label7);
            this.Controls.Add(this.textBoxItemOut);
            this.Controls.Add(label6);
            this.Controls.Add(label5);
            this.Controls.Add(this.textBoxSearchItemOut);
            this.Controls.Add(label4);
            this.Controls.Add(label3);
            this.Controls.Add(this.comboBoxCatagoryOut);
            this.Controls.Add(this.buttonAdd_Item);
            this.Controls.Add(this.dataGridViewItemListOut);
            this.Controls.Add(this.comboBoxBranch);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBoxQtyBalance);
            this.Controls.Add(this.textBoxBalance);
            this.Controls.Add(this.buttonPrintVoucher);
            this.Controls.Add(this.stockOutDetailDataGridView);
            this.Controls.Add(master_out_idLabel);
            this.Controls.Add(this.master_out_idTextBox);
            this.Controls.Add(emp_idLabel);
            this.Controls.Add(this.emp_idComboBox);
            this.Controls.Add(date_soutLabel);
            this.Controls.Add(this.date_soutDateTimePicker);
            this.Controls.Add(this.stock_Out_MasterBindingNavigator);
            this.Name = "FormStockOutMaster_Detail";
            this.Text = "Stock Out";
            this.Load += new System.EventHandler(this.FormStockOutMaster_Detail_Load);
            ((System.ComponentModel.ISupportInitialize)(this.stock_Out_MasterBindingNavigator)).EndInit();
            this.stock_Out_MasterBindingNavigator.ResumeLayout(false);
            this.stock_Out_MasterBindingNavigator.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.stock_Out_MasterBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sastockDataSet_OutMasterDetail)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.employeesBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sastockDataSetEmpOnly)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.stockOutDetailBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.stockOutDetailDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.itemsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.itemsDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.branchBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sastockDataSetBranchBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sastockDataSetBranch)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewItemListOut)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.categoryBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sastockDataSetCategory)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private sastockDataSet_OutMasterDetail sastockDataSet_OutMasterDetail;
        private System.Windows.Forms.BindingSource stock_Out_MasterBindingSource;
        private sastockDataSet_OutMasterDetailTableAdapters.Stock_Out_MasterTableAdapter stock_Out_MasterTableAdapter;
        private sastockDataSet_OutMasterDetailTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.BindingNavigator stock_Out_MasterBindingNavigator;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton stock_Out_MasterBindingNavigatorSaveItem;
        private sastockDataSet_OutMasterDetailTableAdapters.StockOutDetailTableAdapter stockOutDetailTableAdapter;
        private System.Windows.Forms.TextBox master_out_idTextBox;
        private System.Windows.Forms.ComboBox emp_idComboBox;
        private System.Windows.Forms.DateTimePicker date_soutDateTimePicker;
        private System.Windows.Forms.BindingSource stockOutDetailBindingSource;
        private System.Windows.Forms.DataGridView stockOutDetailDataGridView;
        private System.Windows.Forms.ToolStripButton toolStripButtonVoucherAssign;
        private System.Windows.Forms.ToolStripButton toolStripButtonEdit;
        private sastockDataSetEmpOnly sastockDataSetEmpOnly;
        private System.Windows.Forms.BindingSource employeesBindingSource;
        private sastockDataSetEmpOnlyTableAdapters.EmployeesTableAdapter employeesTableAdapter;
        private ItemsDataSet itemsDataSet;
        private System.Windows.Forms.BindingSource itemsBindingSource;
        private ItemsDataSetTableAdapters.ItemsTableAdapter itemsTableAdapter;
        private System.Windows.Forms.Button buttonPrintVoucher;
        private System.Windows.Forms.TextBox textBoxBalance;
        private System.Windows.Forms.TextBox textBoxQtyBalance;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox comboBoxBranch;
        private System.Windows.Forms.BindingSource sastockDataSetBranchBindingSource;
        private sastockDataSetBranch sastockDataSetBranch;
        private System.Windows.Forms.BindingSource branchBindingSource;
        private sastockDataSetBranchTableAdapters.BranchTableAdapter branchTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewComboBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridView dataGridViewItemListOut;
        private System.Windows.Forms.Button buttonAdd_Item;
        private System.Windows.Forms.ComboBox comboBoxCatagoryOut;
        private sastockDataSetCategory sastockDataSetCategory;
        private System.Windows.Forms.BindingSource categoryBindingSource;
        private sastockDataSetCategoryTableAdapters.CategoryTableAdapter categoryTableAdapter;
        private System.Windows.Forms.TextBox textBoxSearchItemOut;
        private System.Windows.Forms.TextBox textBoxItemOut;
        private System.Windows.Forms.TextBox textBoxQtyOut;
        private System.Windows.Forms.TextBox textBoxDescOut;
        private System.Windows.Forms.Button buttonDeleteItem;
    }
}