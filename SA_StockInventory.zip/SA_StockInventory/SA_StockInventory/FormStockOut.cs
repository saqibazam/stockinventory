﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SA_StockInventory
{
    public partial class FormStockOut : Form
    {
        public FormStockOut()
        {
            InitializeComponent();
        }

        Class_Connection cn = new Class_Connection();
       // DialogResult dlgResult;
        SqlCommand cmd;
    //    int i = 1;
        //SqlDataAdapter adapt;
        private void FormStockOut_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'sastockDataSetCategory.Category' table. You can move, or remove it, as needed.
            this.categoryTableAdapter.Fill(this.sastockDataSetCategory.Category);

       
            DisplayDatainTextBox();
            DisplayDataInGrid();

        }

        private void DisplayDatainTextBox()
        {
            cn.con.Open();
            cmd = new SqlCommand();
            try
            {
                // Selet Max Entry Record from Database
                //Max Master ID store in int

                cmd = new SqlCommand("crudStock_out", cn.con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add(new SqlParameter("@StatementType", "MaxStockID"));
        //        cmd.Parameters.Add(new SqlParameter("@Stock_out_id", i));

                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    textBoxStockMasterID.Text = reader["stock_master_id"].ToString();
                    emp_idComboBox.SelectedValue   = reader["emp_id"].ToString();
                    cat_idComboBox.SelectedValue  = reader["cat_id"].ToString();
                    outdateDateTimePicker.Text = reader["outdate"].ToString();
    
               
                }
                reader.Close();
                cn.con.Close();

            }
            catch (Exception x)
            {
                MessageBox.Show(x.GetBaseException().ToString(), "Error",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                cmd.InitializeLifetimeService();

                cn.con.Close();

            }


        }


        private void buttonNew_Click(object sender, EventArgs e)
        {

            cn.con.Open();
            cmd = new SqlCommand();
            try
            {
                // Selet Max Entry Record from Database
                //Max Master ID store in int

                cmd = new SqlCommand("crudStock_out", cn.con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add(new SqlParameter("@StatementType", "MaxStockID"));
                //        cmd.Parameters.Add(new SqlParameter("@Stock_out_id", i));

                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    string a = "";
                    int b = 0;
                    a = reader["stock_master_id"].ToString ();
                    b =  Convert.ToInt16(a) + 1;
                    textBoxStockMasterID.Text = b.ToString();
                    emp_idComboBox.Text = "";
                    cat_idComboBox.Text = "";
                    outdateDateTimePicker.Text = DateTime.Now.ToShortDateString();


                }
                reader.Close();
                cn.con.Close();

            }
            catch (Exception x)
            {
                MessageBox.Show(x.GetBaseException().ToString(), "Error",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                cmd.InitializeLifetimeService();

                cn.con.Close();

            }


        }


        private void DisplayDataInGrid()
        {
            // Show MaxMasterID Detail in DataGrid at Load , after Insert, after update
            
            // TODO: This line of code loads data into the 'itemsDataSet.Items' table. You can move, or remove it, as needed.
            this.itemsTableAdapter.Fill(this.itemsDataSet.Items);
            // TODO: This line of code loads data into the 'sastockDataSetEmployee.Employees' table. You can move, or remove it, as needed.
            this.employeesTableAdapter.Fill(this.sastockDataSetEmployee.Employees);
            // TODO: This line of code loads data into the 'sastockDataSetStock_Out.Stock_out' table. You can move, or remove it, as needed.
            this.stock_outTableAdapter.FillByMID (this.sastockDataSetStock_Out.Stock_out,Convert.ToInt16 (textBoxStockMasterID .Text ));

        }

        private void DisplayDataInGridTop()
        {
            // TODO: This line of code loads data into the 'itemsDataSet.Items' table. You can move, or remove it, as needed.
            this.itemsTableAdapter.Fill(this.itemsDataSet.Items);
            // TODO: This line of code loads data into the 'sastockDataSetEmployee.Employees' table. You can move, or remove it, as needed.
            this.employeesTableAdapter.Fill(this.sastockDataSetEmployee.Employees);
            // TODO: This line of code loads data into the 'sastockDataSetStock_Out.Stock_out' table. You can move, or remove it, as needed.
            this.stock_outTableAdapter.FillByTop (this.sastockDataSetStock_Out.Stock_out);

        }

        private void DisplayDataInGridLast()
        {
            // TODO: This line of code loads data into the 'itemsDataSet.Items' table. You can move, or remove it, as needed.
            this.itemsTableAdapter.Fill(this.itemsDataSet.Items);
            // TODO: This line of code loads data into the 'sastockDataSetEmployee.Employees' table. You can move, or remove it, as needed.
            this.employeesTableAdapter.Fill(this.sastockDataSetEmployee.Employees);
            // TODO: This line of code loads data into the 'sastockDataSetStock_Out.Stock_out' table. You can move, or remove it, as needed.
            this.stock_outTableAdapter.FillByLast(this.sastockDataSetStock_Out.Stock_out);

        }

     

        private void button_Insert_Click(object sender, EventArgs e)
        {
            //dlgResult = MessageBox.Show("Do you want to Insert New Record", "New Record Insert", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
            //if (dlgResult == DialogResult.Yes)
            //{

            //    try
            //    {
            //        if (stock_out_idTextBox.Text == "" && (qty_outTextBox.Text != ""))
            //        {
            //            cn.con.Open();
            //            cmd = new SqlCommand("crudStock_out", cn.con);
            //            cmd.CommandType = CommandType.StoredProcedure;
            //            cmd.Parameters.Add(new SqlParameter("@StatementType", "InsertStock_out"));
            //            cmd.Parameters.AddWithValue("@Emp_id", emp_idComboBox.SelectedValue);
            //            cmd.Parameters.AddWithValue("@Item_id", item_idComboBox.SelectedValue);
            //            cmd.Parameters.AddWithValue("@Qty_out", qty_outTextBox.Text);
            //            //DateTime myDateTime = DateTime.Now;
            //            //string sqlFormattedDate = myDateTime.ToString("yyyy-MM-dd HH:mm:ss");

            //            cmd.Parameters.AddWithValue("@Out_Date", outdateDateTimePicker.Text);
            //            cmd.Parameters.AddWithValue("@Desc", descriptionTextBox.Text);
            //            //cmd.Parameters.AddWithValue("@EntryDate", DateTime.Now);

            //            cmd.ExecuteNonQuery();
            //            cn.con.Close();
            //            MessageBox.Show("Record Inserted Successfully");
            //            DisplayDatainTextBox(i);
            //            DisplayDataInGridLast();
            //        }
            //        else
            //        {
            //            MessageBox.Show("Only for New Record, Please Fill All Fields!");
            //        }
            //    }
            //    catch (Exception ex)
            //    {
            //        MessageBox.Show(Convert.ToString(ex));
            //    }

            //}
        }

        private void buttonShowTop_Click(object sender, EventArgs e)
        {
            DisplayDataInGridTop();
        }

        private void buttonShowAll_Click(object sender, EventArgs e)
        {
         //   DisplayDataInGrid();




        }

        private void button_Update_Click(object sender, EventArgs e)
        {
            //dlgResult = MessageBox.Show("Do you want to Update this Record", "Update Record", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
            //if (dlgResult == DialogResult.Yes)
            //{


            //    try
            //    {
            //        if (stock_out_idTextBox.Text != "" && qty_outTextBox.Text != "")
            //        {
            //            //cmd = new SqlCommand("update Branch set branch_name=@name,branch_location=@location where branch_id=@id", cn.con);
            //            cn.con.Open();
            //            cmd = new SqlCommand("crudStock_out", cn.con);
            //            cmd.CommandType = CommandType.StoredProcedure;
            //            cmd.Parameters.Add(new SqlParameter("@StatementType", "UpdateStock_out"));
            //            cmd.Parameters.AddWithValue("@Stock_out_id", stock_out_idTextBox.Text);
            //            cmd.Parameters.AddWithValue("@Emp_id", emp_idComboBox.SelectedValue);
            //            cmd.Parameters.AddWithValue("@Item_id", item_idComboBox.SelectedValue);
            //            cmd.Parameters.AddWithValue("@Qty_out", qty_outTextBox.Text);
            //            cmd.Parameters.AddWithValue("@Out_Date", outdateDateTimePicker.Text);
            //            cmd.Parameters.AddWithValue("@Desc", descriptionTextBox.Text);
            //            //cmd.Parameters.AddWithValue("@EntryDate", DateTime.Now);
            //            cmd.ExecuteNonQuery();
            //            MessageBox.Show("Record Updated Successfully");
            //            cn.con.Close();
            //            DisplayDatainTextBox(i);
            //            DisplayDataInGridLast();
            //        }
            //        else
            //        {
            //            MessageBox.Show("Please Select Record to Update");
            //        }
            //    }
            //    catch (Exception ex)
            //    {
            //        MessageBox.Show(Convert.ToString(ex));
            //    }

            //}

        }

        private void buttonShowLast_Click(object sender, EventArgs e)
        {
            DisplayDataInGridLast();
        }

        private void stock_outDataGridView_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            //stock_out_idTextBox.Text = stock_outDataGridView.Rows[e.RowIndex].Cells[0].Value.ToString();
            //i = Convert.ToInt16(stock_out_idTextBox.Text);

            //DisplayDatainTextBox();

        }
        public static string SetValueForText1 = "";

        private void buttonPrintVoucher_Click(object sender, EventArgs e)
        {


            ////SetValueForText1 = stock_out_idTextBox.Text;

            ////FormIssueVoucher frmiv = new FormIssueVoucher();
            ////frmiv.Show();
            //////Form2 frm2 = new Form2();
            //////frm2.Show();
        }

        private void item_idComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void item_idLabel_Click(object sender, EventArgs e)
        {

        }

        private void cat_idComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
        //    cat_idComboBox .SelectedValue

            
        }
    }
}
