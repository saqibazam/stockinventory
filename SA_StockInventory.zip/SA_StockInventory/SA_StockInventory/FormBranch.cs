﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SA_StockInventory
{
    public partial class FormBranch : Form
    {
        public FormBranch()
        {
            InitializeComponent();
        }
        Class_Connection cn = new Class_Connection();
        DialogResult dlgResult;
        SqlCommand cmd;
        SqlDataAdapter adapt;
        int i = 1;
        
        private void FormBranch_Load(object sender, EventArgs e)
        {
            DisplayDatainTextBox(i);
            DisplayDataInGrid();

            string userName = FormLogin.CheckUserName;
            if (userName == "Admin" || userName == "Super")
            {
                button_Delete.Visible = true;
                button_Update.Visible = true;
            }
        }

        private void DisplayDatainTextBox(int i)
        {

            cn.con.Open();
            SqlCommand cmd = new SqlCommand();
            try
            {
                //  cmd = new SqlCommand("select branch_id , branch_name , branch_location from Branch  where branch_id = 1", cn.con);
                cmd = new SqlCommand("crudBranch", cn.con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add(new SqlParameter("@StatementType", "SelectBranch"));
                cmd.Parameters.Add(new SqlParameter("@Br_ID", i));

                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    textBoxID.Text = reader["branch_id"].ToString();
                    textBoxName .Text = reader["branch_name"].ToString();
                    textBox_Location .Text = reader["branch_location"].ToString();
                    
                }
                reader.Close();
                cn.con.Close();

            }
            catch (Exception x)
            {
                MessageBox.Show(x.GetBaseException().ToString(), "Error",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                cmd.InitializeLifetimeService();
                // cmd.Dispose();
                cn.con.Close();
                //cn.con.Dispose(); //will be written on at exit from the application time....
            }

        }
        
        private void DisplayDataInGrid()
        {
            cn.con.Open();
            DataTable dt = new DataTable();
            adapt = new SqlDataAdapter("select * from Branch", cn.con);
            adapt.Fill(dt);
            dataGridViewBranch.DataSource = dt;
            cn.con.Close();
        }

     
     
        private void dataGridViewBranch_RowHeaderMouseClick_1(object sender, DataGridViewCellMouseEventArgs e)
        {
            textBoxID.Text = dataGridViewBranch.Rows[e.RowIndex].Cells[0].Value.ToString();
            i = Convert.ToInt16(textBoxID.Text);
            DisplayDatainTextBox(i);
        }

        private void button_Update_Click(object sender, EventArgs e)
        {
            dlgResult = MessageBox.Show("Do you want to Update this Record", "Update Record", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
            if (dlgResult == DialogResult.Yes)
            {


                try
                {
                    if (textBoxName.Text != "" && textBox_Location.Text != "")
                    {
                        //cmd = new SqlCommand("update Branch set branch_name=@name,branch_location=@location where branch_id=@id", cn.con);
                        cn.con.Open();
                        cmd = new SqlCommand("crudBranch", cn.con);
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.Add(new SqlParameter("@StatementType", "UpdateBranch"));
                        cmd.Parameters.AddWithValue("@Br_ID", textBoxID.Text);
                        cmd.Parameters.AddWithValue("@Br_Name", textBoxName.Text);
                        cmd.Parameters.AddWithValue("@Br_Location", textBox_Location.Text);
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Record Updated Successfully");
                        cn.con.Close();
                        DisplayDatainTextBox(i);
                        DisplayDataInGrid();

                        buttonNew.Enabled = true ;
                        button_Insert.Enabled = false ;
                        button_Update.Enabled = true ;

                    }
                    else
                    {
                        MessageBox.Show("Please Select Record to Update");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(Convert.ToString(ex));
                }
            }
        }
        
        private void button_Delete_Click(object sender, EventArgs e)
        {
            dlgResult = MessageBox.Show("Do you want to Delete this Record", "Delete Record", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
            if (dlgResult == DialogResult.Yes)
            {


                try
                {
                    if (textBoxID.Text != "")
                    {
                       // cmd = new SqlCommand("delete from Branch where branch_id=@id", cn.con);
                        cn.con.Open();
                        cmd = new SqlCommand("crudBranch", cn.con);
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.Add(new SqlParameter("@StatementType", "DeleteBranch"));
                        cmd.Parameters.AddWithValue("@Br_ID", textBoxID.Text);
                        cmd.ExecuteNonQuery();
                        cn.con.Close();
                        MessageBox.Show("Record Deleted Successfully!");
                        DisplayDatainTextBox(i);
                        DisplayDataInGrid();
                    }
                    else { MessageBox.Show("Please Select Record to Delete"); }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(Convert.ToString(ex));
                }

                //   MessageBox.Show("Please Select Record to Delete");
            }      
        }

        private void    button_Insert_Click(object sender, EventArgs e)
        {
            dlgResult = MessageBox.Show("Do you want to Insert New Record", "New Record Insert", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
            if (dlgResult == DialogResult.Yes)
            {

                try
                {
                    if (textBoxID.Text == "" && (textBoxName.Text != "" && textBox_Location.Text != ""))
                    {
                        //cmd = new SqlCommand("insert into Branch(branch_name,branch_location) values(@name,@location)", cn.con);
                        cn.con.Open();
                        cmd = new SqlCommand("crudBranch", cn.con);
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.Add(new SqlParameter("@StatementType", "InsertBranch"));
                        cmd.Parameters.AddWithValue("@Br_Name", textBoxName.Text);
                        cmd.Parameters.AddWithValue("@Br_Location", textBox_Location.Text);
                        cmd.ExecuteNonQuery();
                        cn.con.Close();
                        MessageBox.Show("Record Inserted Successfully");
                        DisplayDataInGrid();

                        buttonNew.Enabled = true ;
                        button_Insert.Enabled = false ;
                        button_Update.Enabled = true;

                    }
                    else
                    {
                        MessageBox.Show("Only for New Record, Please Fill All Fields!");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(Convert.ToString(ex));
                }
            }
        }

        private void buttonNew_Click(object sender, EventArgs e)
        {
            buttonNew.Enabled = false;
            button_Insert.Enabled = true;
            button_Update.Enabled = false;


            textBoxID.Text = "";
            textBoxName.Text = "";
            textBox_Location.Text = ""; 

        }
    }
}
