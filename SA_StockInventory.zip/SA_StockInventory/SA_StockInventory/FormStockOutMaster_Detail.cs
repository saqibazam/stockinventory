﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SA_StockInventory
{
    public partial class FormStockOutMaster_Detail : Form
    {

        Class_Connection cn = new Class_Connection();
        DialogResult dlgResult;
        SqlCommand cmd;
        SqlDataAdapter adapt;
        DataTable da;
        int itemid;
        int balance;
        int StOutDetailID;
        string SOutItem_ID;
        string SOutItem_Qty;

        public FormStockOutMaster_Detail()
        {
            InitializeComponent();
        }

        private void stock_Out_MasterBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            try
            {
                this.Validate();

                this.stock_Out_MasterBindingSource.EndEdit();
                this.stock_Out_MasterTableAdapter.Update(this.sastockDataSet_OutMasterDetail.Stock_Out_Master);

                this.stockOutDetailBindingSource.EndEdit();
                this.stockOutDetailTableAdapter.Update(this.sastockDataSet_OutMasterDetail.StockOutDetail);




                //Save DataGrid View
                int rowsCount = stockOutDetailDataGridView.Rows.Count;
                int rowsInserted = 0;
                for (int i = 0; i < rowsCount; i++)
                {
                    cn.con.Open();
                    cmd = new SqlCommand("CurrentStock", cn.con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add(new SqlParameter("@StatementType", "UpdateStockOutBalance"));
                    cmd.Parameters.AddWithValue("@itemID", stockOutDetailDataGridView.Rows[i].Cells[2].Value);

                    if (cmd.ExecuteNonQuery() > 0)
                    {
                        rowsInserted++;
                    }
                    cn.con.Close();
                }//end of for loop




                MessageBox.Show("Record Inserted Successfully");


                emp_idComboBox.Enabled = false;
                comboBoxBranch.Enabled = false;
                date_soutDateTimePicker.Enabled = false;

                bindingNavigatorAddNewItem.Enabled = true;
                toolStripButtonVoucherAssign.Enabled = false;
                stock_Out_MasterBindingNavigatorSaveItem.Enabled = false;

                stockOutDetailDataGridView.AllowUserToAddRows = false;
                stockOutDetailDataGridView.AllowUserToDeleteRows = false;
                
                stockOutDetailDataGridView.Enabled = false;

                ShowItemLisInGridOut();
            }
            catch (Exception ex)
            {
                MessageBox.Show(Convert.ToString(ex));
            }


        }

        private void FormStockOutMaster_Detail_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'sastockDataSetCategory.Category' table. You can move, or remove it, as needed.
            this.categoryTableAdapter.Fill(this.sastockDataSetCategory.Category);
            // TODO: This line of code loads data into the 'sastockDataSetBranch.Branch' table. You can move, or remove it, as needed.
            this.branchTableAdapter.Fill(this.sastockDataSetBranch.Branch);

            try
            {

                this.stockOutDetailDataGridView.CellValueChanged -= new
       DataGridViewCellEventHandler(stockOutDetailDataGridView_CellValueChanged);


                // TODO: This line of code loads data into the 'itemsDataSet.Items' table. You can move, or remove it, as needed.
                this.itemsTableAdapter.Fill(this.itemsDataSet.Items);
                // TODO: This line of code loads data into the 'sastockDataSetEmpOnly.Employees' table. You can move, or remove it, as needed.
                this.employeesTableAdapter.Fill(this.sastockDataSetEmpOnly.Employees);
                // TODO: This line of code loads data into the 'sastockDataSet_OutMasterDetail.StockOutDetail' table. You can move, or remove it, as needed.
                this.stockOutDetailTableAdapter.Fill(this.sastockDataSet_OutMasterDetail.StockOutDetail);
                // TODO: This line of code loads data into the 'sastockDataSet_OutMasterDetail.Stock_Out_Master' table. You can move, or remove it, as needed.
                this.stock_Out_MasterTableAdapter.Fill(this.sastockDataSet_OutMasterDetail.Stock_Out_Master);



                stock_Out_MasterBindingSource.MoveLast();
                stockOutDetailBindingSource.MoveLast();

                emp_idComboBox.Enabled = false;
                comboBoxBranch.Enabled = false;
                date_soutDateTimePicker.Enabled = false;

                toolStripButtonVoucherAssign.Enabled = false;
                stock_Out_MasterBindingNavigatorSaveItem.Enabled = false;
                stockOutDetailDataGridView.AllowUserToAddRows = false;
                stockOutDetailDataGridView.Enabled = true;

                this.stockOutDetailDataGridView.CellValueChanged += new
     DataGridViewCellEventHandler(stockOutDetailDataGridView_CellValueChanged);
            }

            catch (Exception x)
            {
                MessageBox.Show(x.GetBaseException().ToString(), "Error",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

       

        private void bindingNavigatorAddNewItem_Click(object sender, EventArgs e)
        {
            try
            {
                // Selet Max Entry Record from Database
                //Max Master ID store in int

                cn.con.Open();
                cmd = new SqlCommand();
                cmd = new SqlCommand("crudStock_out_MD", cn.con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add(new SqlParameter("@StatementType", "MaxStockID"));

                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    string a = "";
                    int b = 0;
                    a = reader["Master_out_id"].ToString();
                    b = Convert.ToInt16(a) + 1;
                    master_out_idTextBox.Text = b.ToString();

                    date_soutDateTimePicker.Text = DateTime.Now.ToShortDateString();


                }
                reader.Close();
                cn.con.Close();

                emp_idComboBox.Enabled = true;
                comboBoxBranch.Enabled = true;
                date_soutDateTimePicker.Enabled = true;

                bindingNavigatorAddNewItem.Enabled = false;
                toolStripButtonVoucherAssign.Enabled = true;
                stock_Out_MasterBindingNavigatorSaveItem.Enabled = false;


            }
            catch (Exception x)
            {
                MessageBox.Show(x.GetBaseException().ToString(), "Error",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void toolStripButtonVoucherAssign_Click(object sender, EventArgs e)
        {
            try
            {
                this.Validate();

                this.stock_Out_MasterBindingSource.EndEdit();
                this.stock_Out_MasterTableAdapter.Update(this.sastockDataSet_OutMasterDetail.Stock_Out_Master);



                MessageBox.Show("Name Add Successfully");

                emp_idComboBox.Enabled = true;
                comboBoxBranch.Enabled = true;
                date_soutDateTimePicker.Enabled = true;

                bindingNavigatorAddNewItem.Enabled = false;
                toolStripButtonVoucherAssign.Enabled = false;
                stock_Out_MasterBindingNavigatorSaveItem.Enabled = true;


               // stockOutDetailDataGridView.AllowUserToAddRows = false;
               // stockOutDetailDataGridView.Enabled = true;
            }
            catch (Exception x)
            {
                MessageBox.Show(x.GetBaseException().ToString(), "Error",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void toolStripButtonEdit_Click(object sender, EventArgs e)
        {
            emp_idComboBox.Enabled = true;
            comboBoxBranch.Enabled = true;
            date_soutDateTimePicker.Enabled = true;

            bindingNavigatorAddNewItem.Enabled = false;
            toolStripButtonVoucherAssign.Enabled = false;
            stock_Out_MasterBindingNavigatorSaveItem.Enabled = true;

         //   stockOutDetailDataGridView.AllowUserToAddRows = false;
          //  stockOutDetailDataGridView.AllowUserToDeleteRows = false ;
           // stockOutDetailDataGridView.Enabled = true;
        }

        private void date_soutLabel_Click(object sender, EventArgs e)
        {

        }
        public static string SetValueForText = "";
        private void buttonPrintVoucher_Click(object sender, EventArgs e)
        {
            try
            {
                SetValueForText = master_out_idTextBox.Text;

                FormIssueVoucher frmiv = new FormIssueVoucher();
                frmiv.Show();
            }
            catch (Exception x)
            {
                MessageBox.Show(x.GetBaseException().ToString(), "Error",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

      
        private void stockOutDetailDataGridView_CellBeginEdit(object sender, DataGridViewCellCancelEventArgs e)
        {
           // UpdateStockBalance();
        }

        private void stockOutDetailDataGridView_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {

           // UpdateStockBalance();

        }

        private void stockOutDetailDataGridView_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.ColumnIndex == dataGridViewTextBoxColumn3.Index && e.RowIndex >= 0) 
                  

                {
                    textBoxBalance.Text = stockOutDetailDataGridView.Rows[e.RowIndex].Cells[e.ColumnIndex].Value.ToString();
                }
            }
            catch (Exception x)
            {
                MessageBox.Show(x.GetBaseException().ToString(), "Error",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
            }


        }


        private void stockOutDetailDataGridView_CurrentCellDirtyStateChanged(object sender, EventArgs e)
        {
            try
            {
                if (stockOutDetailDataGridView.IsCurrentCellDirty)
                {
                    stockOutDetailDataGridView.CommitEdit(DataGridViewDataErrorContexts.Commit);
                }
            }
            catch (Exception x)
            {
                MessageBox.Show(x.GetBaseException().ToString(), "Error",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


        private void stockOutDetailDataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
       


        }

        private void textBoxBalance_TextChanged(object sender, EventArgs e)
        {
            UpdateStockBalance();
        }


        private void UpdateStockBalance()
        {
            try
            {

                if (stockOutDetailDataGridView.CurrentCell.ColumnIndex == 3)
                {
                    if (this.stockOutDetailDataGridView.CurrentCell.Value != null)
                    {
                        cn.con.Open();
                        cmd = new SqlCommand("CurrentStock", cn.con);
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.Add(new SqlParameter("@StatementType", "UpdateStockOutBalance"));
                        cmd.Parameters.AddWithValue("@itemID", textBoxBalance.Text);
                        cmd.ExecuteNonQuery();
                        cn.con.Close();

                    }
                }
                cn.con.Open();
                cmd = new SqlCommand();
                cmd = new SqlCommand("CurrentStock", cn.con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add(new SqlParameter("@StatementType", "BalanceStock"));
                cmd.Parameters.Add(new SqlParameter("@itemID", textBoxBalance.Text));
                SqlDataReader reader = cmd.ExecuteReader();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        int TotIn = 0;
                        int TotOut = 0;
                        int Bal = 0;

                        TotIn = Convert.ToInt16(reader["TotalIn"]);
                        TotOut = Convert.ToInt16(reader["TotalOut"]);
                        Bal = TotIn - TotOut;
                        textBoxQtyBalance.Text = Convert.ToString(Bal);
                    }
                }
                else
                {
                    textBoxQtyBalance.Text = "0";
                }
                cn.con.Close();

            }
            catch (Exception x)
            {
                MessageBox.Show(x.GetBaseException().ToString(), "Error",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }
       
        private void stockOutDetailDataGridView_RowValidated(object sender, DataGridViewCellEventArgs e)
        {
         
        }

        private void stockOutDetailDataGridView_RowsRemoved(object sender, DataGridViewRowsRemovedEventArgs e)
        {
           
        }


        private void ShowItemLisInGridOut()
        {
            cn.con.Open();
            adapt = new SqlDataAdapter("SELECT [ItemID],[items_name] ,[items_desc],[items_size] , [TotalIn]-[TotalOut] as Balance  FROM [View_StockBalance] where [category_id] = '" + comboBoxCatagoryOut.SelectedValue + "' and items_name like '" + '%' + textBoxSearchItemOut.Text + "%'", cn.con);
            da = new DataTable();
            adapt.Fill(da);
            dataGridViewItemListOut.DataSource = da;
            cn.con.Close();
            ReDesignWidthofItemListinGrid();
        }

        private void ShowItemLisInGridOut(string itemID)
        {
            cn.con.Open();
            adapt = new SqlDataAdapter("SELECT [ItemID],[items_name] ,[items_desc],[items_size] , [TotalIn]-[TotalOut] as Balance  FROM [View_StockBalance] where itemID ='"+itemID+"'", cn.con);
            da = new DataTable();
            adapt.Fill(da);
            dataGridViewItemListOut.DataSource = da;
            cn.con.Close();
            ReDesignWidthofItemListinGrid();
        }
        private void ReDesignWidthofItemListinGrid()
        {
            dataGridViewItemListOut.Columns[0].Width = 40;
            dataGridViewItemListOut.Columns[1].HeaderText = "Items Name";
            dataGridViewItemListOut.Columns[1].Width = 170;
            dataGridViewItemListOut.Columns[2].HeaderText = "Description";
            dataGridViewItemListOut.Columns[2].Width = 100;
            dataGridViewItemListOut.Columns[3].HeaderText = "Size";
            dataGridViewItemListOut.Columns[3].Width = 60;
            dataGridViewItemListOut.Columns[4].Width = 50;
        }

        private void buttonAdd_Item_Click(object sender, EventArgs e)
        {
            int qty = Convert.ToInt16(textBoxQtyOut.Text);

            //check if qty / balance = 0
            if (qty == 0)
            {
                MessageBox.Show("Quantity can not be Zero");
            }

            // If Balance = 0, This check is for Stock Out
            if (balance <= 0)
            {
                MessageBox.Show("Item Balance is Zero, Can not be Add");
            }
            // If Quantity Greater than Balance
            if (qty > balance)
            {
                MessageBox.Show("Can not Add, Quantity is more than Balance");

            }


            //Check If Item is repeated/duplicate

            cn.con.Open();
            string itmid = Convert.ToString(itemid);

            cmd = new SqlCommand("select count(ItemID) from StockOutDetail where StockMasterID = '" + master_out_idTextBox.Text + "'  and ItemID = '" + itmid + "' ", cn.con);
            int returnval = 0;
            returnval = Convert.ToInt32(cmd.ExecuteScalar());
            cn.con.Close();

            if (returnval >= 1)
            {
                MessageBox.Show("Can not Add! This Item Already Exist");
            }

            if (balance > 0 && qty <= balance)
            {

                if (returnval < 1)
                {
                    //Insert into StockInDetail Table
                    cn.con.Open();
                    cmd = new SqlCommand("crudStock_out_MD", cn.con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add(new SqlParameter("@StatementType", "InsertStockDetial"));
                    cmd.Parameters.AddWithValue("@StockMasterID", master_out_idTextBox.Text);
                    cmd.Parameters.AddWithValue("@itemID", itemid);
                    cmd.Parameters.AddWithValue("@itemQty", qty);
                    cmd.Parameters.AddWithValue("@itemDesc", textBoxDescOut.Text);
                    cmd.ExecuteNonQuery();
                    cn.con.Close();

                    //Update Stock
                    cn.con.Open();
                    cmd = new SqlCommand("CurrentStock", cn.con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add(new SqlParameter("@StatementType", "UpdateStockOutBalance"));
                    cmd.Parameters.AddWithValue("@itemID", itemid);

                    cmd.ExecuteNonQuery();
                    cn.con.Close();
                    MessageBox.Show("This Selected Item Add Successfully");
                    buttonDeleteItem.Enabled = true;

                    // TODO: This line of code loads data into the 'sastockDataSet_OutMasterDetail.StockOutDetail' table. You can move, or remove it, as needed.
                    this.stockOutDetailTableAdapter.Fill(this.sastockDataSet_OutMasterDetail.StockOutDetail);

                    ShowItemLisInGridOut();
                }
            }
        }

        private void textBoxSearchItemOut_TextChanged(object sender, EventArgs e)
        {
            ShowItemLisInGridOut();
        }

        private void dataGridViewItemListOut_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            itemid = Convert.ToInt16(dataGridViewItemListOut.Rows[e.RowIndex].Cells[0].Value.ToString());
            balance = Convert.ToInt16(dataGridViewItemListOut.Rows[e.RowIndex].Cells[4].Value.ToString());
            textBoxItemOut.Text = dataGridViewItemListOut.Rows[e.RowIndex].Cells[1].Value.ToString();
            textBoxDescOut.Text = dataGridViewItemListOut.Rows[e.RowIndex].Cells[2].Value.ToString();
            textBoxQtyOut.Text = "";

        }

        private void textBoxQtyOut_TextChanged(object sender, EventArgs e)
        {
            if (System.Text.RegularExpressions.Regex.IsMatch(textBoxQtyOut.Text, "[^0-9]"))
            {
                MessageBox.Show("Enter Only Numbers!");
                textBoxQtyOut.Text = textBoxQtyOut.Text.Remove(textBoxQtyOut.Text.Length - 1);
            }
        }

        private void buttonDeleteItem_Click(object sender, EventArgs e)
        {
            dlgResult = MessageBox.Show("Do you want to Delete this Record", "Delete Record", MessageBoxButtons.YesNo, MessageBoxIcon.Stop);
            if (dlgResult == DialogResult.Yes)
            {

                //  select itemid, itemQty from StockOutDetail where StockOutDetailID = 85

                cmd = new SqlCommand("select itemID, itemQty from StockOutDetail where StockOutDetailID  = @StockOutDetailID", cn.con);
                cmd.Parameters.AddWithValue("@StockOutDetailID", StOutDetailID);
                cn.con.Open();

                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    SOutItem_ID = reader["itemID"].ToString();
                    SOutItem_Qty = reader["itemQty"].ToString();
                }
                reader.Close();
                //cn.con.Close();

                //  this itemQty will be minus from StockBalance
                //  update StockBalance set TotalOut = TotalOut - GridViewItem_Quantity where itemID = GridView_ItemID 


                cmd = new SqlCommand("update StockBalance set TotalOut=TotalOut - @itemQty where itemid=@Itemid", cn.con);
                //           cn.con.Open();
                cmd.Parameters.AddWithValue("@itemQty", SOutItem_Qty);
                cmd.Parameters.AddWithValue("@Itemid", SOutItem_ID);
                cmd.ExecuteNonQuery();
                //  MessageBox.Show("Quantity Updated Successfully");

                //--delete from[StockOutDetail] where StockOutDetailID = 86

                cmd = new SqlCommand("delete from [StockOutDetail] where StockOutDetailID =@StockOutDetailID", cn.con);
                //           cn.con.Open();
                cmd.Parameters.AddWithValue("@StockOutDetailID", StOutDetailID);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Item Deleted Successfully");
                cn.con.Close();
                // TODO: This line of code loads data into the 'sastockDataSet_OutMasterDetail.StockOutDetail' table. You can move, or remove it, as needed.
                this.stockOutDetailTableAdapter.Fill(this.sastockDataSet_OutMasterDetail.StockOutDetail);

                //Show Update GridViewBalance
                ShowItemLisInGridOut(SOutItem_ID);
            }
        }

        private void stockOutDetailDataGridView_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
              StOutDetailID = Convert.ToInt16(stockOutDetailDataGridView.Rows[e.RowIndex].Cells[0].Value.ToString());
        }

        private void bindingNavigatorMovePreviousItem_Click(object sender, EventArgs e)
        {
            string userName = FormLogin.CheckUserName;

            if (userName == "Admin" || userName == "Super")
            {
                buttonDeleteItem.Enabled = true ;
                buttonAdd_Item.Enabled = true ;

            }
            else

            {
                buttonDeleteItem.Enabled = false;
                buttonAdd_Item.Enabled = false;
            }

        }

        private void bindingNavigatorMoveFirstItem_Click(object sender, EventArgs e)
        {
            string userName = FormLogin.CheckUserName;

            if (userName == "Admin" || userName == "Super")
            {
                buttonDeleteItem.Enabled = true;
                buttonAdd_Item.Enabled = true;

            }
            else

            {
                buttonDeleteItem.Enabled = false;
                buttonAdd_Item.Enabled = false;
            }
        }







        //int rowsCount = stockOutDetailDataGridView.Rows.Count;
        //    for (int i = 0; i < rowsCount; i++)
        //    {
        //        if (stockOutDetailDataGridView.Rows[i].Cells[3].Value != null)
        //        {
        //            textBoxBalance .Text = stockOutDetailDataGridView.Rows[i].Cells[2].Value.ToString();
        //        }
        //    }




        //private void UpdateBalance()
        //{
        //    int counter;
        //    int balance;
        //    int TotIn;
        //    int TotOut;

        //    // Iterate through the rows, skipping the Starting Balance row.
        //    for (counter = 1; counter < (stockOutDetailDataGridView.Rows.Count - 1);
        //        counter++)
        //    {
        //        cn.con.Open();

        //        if (stockOutDetailDataGridView.Rows[counter].Cells[3].Value != null)
        //        {
        //            int rowsInserted = 0;

        //            cmd = new SqlCommand("CurrentStock", cn.con);
        //            cmd.CommandType = CommandType.StoredProcedure;
        //            cmd.Parameters.Add(new SqlParameter("@StatementType", "UpdateStockOutBalance"));
        //            cmd.Parameters.AddWithValue("@itemID", stockOutDetailDataGridView.Rows[counter].Cells[2].Value);

        //            if (cmd.ExecuteNonQuery() > 0)
        //            {
        //                rowsInserted++;
        //            }
        //            cn.con.Close();
        //        }//endIF
        //    }//end of for loop






        //    TotIn = 0;
        //    TotOut = 0;

        //    cn.con.Open();
        //    cmd = new SqlCommand();
        //    cmd = new SqlCommand("CurrentStock", cn.con);
        //    cmd.CommandType = CommandType.StoredProcedure;
        //    cmd.Parameters.Add(new SqlParameter("@StatementType", "BalanceStock"));
        //    cmd.Parameters.Add(new SqlParameter("@itemID", stockOutDetailDataGridView.Rows[counter].Cells["itemID"].Value));
        //    SqlDataReader reader = cmd.ExecuteReader();
        //    if (reader.HasRows)
        //    {
        //        while (reader.Read())
        //        {
        //            TotIn = Convert.ToInt16(reader["TotalIn"]);
        //            TotOut = Convert.ToInt16(reader["TotalOut"]);

        //            balance = TotIn - TotOut;

        //        }
        //    }
        //    else
        //    {
        //        labelBalance.Text = "0";
        //    }




        //    balance = int.Parse(stockOutDetailDataGridView.Rows[counter - 1]
        //        .Cells["Balance"].Value.ToString());


        //    stockOutDetailDataGridView.Rows[counter].Cells["Balance"].Value = balance.ToString();
        //    cn.con.Close();
        //}



        //SqlCommand cmd = new SqlCommand("select user_name , user_password  from Users where user_name = @username ", cn.con);
        //cmd.Parameters.AddWithValue("@username", textBoxUserName.Text);
        //        cn.con.Open();

        //        SqlDataReader reader = cmd.ExecuteReader();
        //        while (reader.Read())
        //        {

        //            string usr = reader["user_name"].ToString();

        //string pwd = Decrypt(reader["user_password"].ToString());
        //        }
        //        reader.Close();
        //        cn.con.Close();

        //Update Query
        //cmd = new SqlCommand("update Items set items_name=@name,items_desc=@desc, items_size=@size, category_id=@catID where items_id=@Itemid", cn.con);
        //            this.Validate();
        //            this.userRightsAssignBindingSource.EndEdit();
        //            this.tableAdapterManager.UpdateAll(this.sastockDataSetUserRightsAssign);
        //            cn.con.Open();
        //            cmd = new SqlCommand("crudUserRights", cn.con);
        //cmd.CommandType = CommandType.StoredProcedure;
        //            cmd.Parameters.Add(new SqlParameter("@StatementType", "UpdateUser"));
        //            cmd.Parameters.AddWithValue("@user_id", textBoxUserID.Text);
        //            cmd.Parameters.AddWithValue("@user_name", textBoxUserName.Text);
        //            cmd.Parameters.AddWithValue("@user_password", Encrypt(textBoxPassword.Text));
        //            cmd.Parameters.AddWithValue("@description", textBoxDescription.Text);
        //            cmd.Parameters.AddWithValue("@isactive", checkBoxActive.Checked);
        //            cmd.ExecuteNonQuery();
        //            MessageBox.Show("Record Updated Successfully");
        //            cn.con.Close();





        //    cn.con.Open();
        //        cmd = new SqlCommand();
        //        try
        //        {
        //            //cmd = new SqlCommand("select items_id, items_name, items_desc, items_size, category_id, entrydate from Items where items_id = '"+i+"'", cn.con);
        //            cmd = new SqlCommand("crudUserRights", cn.con);
        //    cmd.CommandType = CommandType.StoredProcedure;
        //            cmd.Parameters.Add(new SqlParameter("@StatementType", "SelectUsers"));
        //            cmd.Parameters.Add(new SqlParameter("@user_id", i));

        //            SqlDataReader reader = cmd.ExecuteReader();
        //            while (reader.Read())
        //            {
        //                textBoxUserID.Text = reader["user_id"].ToString();
        //    textBoxUserName.Text = reader["user_name"].ToString();
        //    textBoxPassword.Text = Decrypt(reader["user_password"].ToString());
        //                textBoxDescription.Text = reader["description"].ToString();
        //    checkBoxActive.Checked  = (reader.GetBoolean(reader.GetOrdinal("isActive")));


        //            }
        //reader.Close();
        //            cn.con.Close();


        /*


      */



    }
}

