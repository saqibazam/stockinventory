﻿namespace SA_StockInventory
{
    partial class FormStockIn
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label stock_in_idLabel;
            System.Windows.Forms.Label client_idLabel;
            System.Windows.Forms.Label item_idLabel;
            System.Windows.Forms.Label qty_addLabel;
            System.Windows.Forms.Label indateLabel;
            System.Windows.Forms.Label descriptionLabel;
            this.stock_in_idTextBox = new System.Windows.Forms.TextBox();
            this.qty_addTextBox = new System.Windows.Forms.TextBox();
            this.indateDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.descriptionTextBox = new System.Windows.Forms.TextBox();
            this.buttonShowTop = new System.Windows.Forms.Button();
            this.buttonShowLast = new System.Windows.Forms.Button();
            this.buttonShowAll = new System.Windows.Forms.Button();
            this.dataGridViewStockIn = new System.Windows.Forms.DataGridView();
            this.stockinidDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clientidDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.clientinfoBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.sastockDataSetClient = new SA_StockInventory.sastockDataSetClient();
            this.itemidDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.itemsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.itemsDataSet = new SA_StockInventory.ItemsDataSet();
            this.qtyaddDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.indateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.descriptionDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.entryDateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.stockinBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.sastockDataSetStockIn = new SA_StockInventory.sastockDataSetStockIn();
            this.buttonNew = new System.Windows.Forms.Button();
            this.button_Update = new System.Windows.Forms.Button();
            this.button_Insert = new System.Windows.Forms.Button();
            this.buttonPrintStock = new System.Windows.Forms.Button();
            this.stock_inTableAdapter = new SA_StockInventory.sastockDataSetStockInTableAdapters.Stock_inTableAdapter();
            this.client_infoTableAdapter = new SA_StockInventory.sastockDataSetClientTableAdapters.Client_infoTableAdapter();
            this.itemsTableAdapter = new SA_StockInventory.ItemsDataSetTableAdapters.ItemsTableAdapter();
            this.tableAdapterManager = new SA_StockInventory.sastockDataSetStockInTableAdapters.TableAdapterManager();
            this.client_idComboBox = new System.Windows.Forms.ComboBox();
            this.item_idComboBox = new System.Windows.Forms.ComboBox();
            stock_in_idLabel = new System.Windows.Forms.Label();
            client_idLabel = new System.Windows.Forms.Label();
            item_idLabel = new System.Windows.Forms.Label();
            qty_addLabel = new System.Windows.Forms.Label();
            indateLabel = new System.Windows.Forms.Label();
            descriptionLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewStockIn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.clientinfoBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sastockDataSetClient)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.itemsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.itemsDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.stockinBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sastockDataSetStockIn)).BeginInit();
            this.SuspendLayout();
            // 
            // stock_in_idLabel
            // 
            stock_in_idLabel.AutoSize = true;
            stock_in_idLabel.Location = new System.Drawing.Point(29, 38);
            stock_in_idLabel.Name = "stock_in_idLabel";
            stock_in_idLabel.Size = new System.Drawing.Size(60, 13);
            stock_in_idLabel.TabIndex = 1;
            stock_in_idLabel.Text = "Voucher #:";
            // 
            // client_idLabel
            // 
            client_idLabel.AutoSize = true;
            client_idLabel.Location = new System.Drawing.Point(29, 65);
            client_idLabel.Name = "client_idLabel";
            client_idLabel.Size = new System.Drawing.Size(36, 13);
            client_idLabel.TabIndex = 3;
            client_idLabel.Text = "Client:";
            // 
            // item_idLabel
            // 
            item_idLabel.AutoSize = true;
            item_idLabel.Location = new System.Drawing.Point(29, 91);
            item_idLabel.Name = "item_idLabel";
            item_idLabel.Size = new System.Drawing.Size(35, 13);
            item_idLabel.TabIndex = 5;
            item_idLabel.Text = "Items:";
            // 
            // qty_addLabel
            // 
            qty_addLabel.AutoSize = true;
            qty_addLabel.Location = new System.Drawing.Point(29, 117);
            qty_addLabel.Name = "qty_addLabel";
            qty_addLabel.Size = new System.Drawing.Size(49, 13);
            qty_addLabel.TabIndex = 7;
            qty_addLabel.Text = "Quantity:";
            // 
            // indateLabel
            // 
            indateLabel.AutoSize = true;
            indateLabel.Location = new System.Drawing.Point(29, 144);
            indateLabel.Name = "indateLabel";
            indateLabel.Size = new System.Drawing.Size(33, 13);
            indateLabel.TabIndex = 9;
            indateLabel.Text = "Date:";
            // 
            // descriptionLabel
            // 
            descriptionLabel.AutoSize = true;
            descriptionLabel.Location = new System.Drawing.Point(29, 169);
            descriptionLabel.Name = "descriptionLabel";
            descriptionLabel.Size = new System.Drawing.Size(63, 13);
            descriptionLabel.TabIndex = 11;
            descriptionLabel.Text = "Description:";
            // 
            // stock_in_idTextBox
            // 
            this.stock_in_idTextBox.Location = new System.Drawing.Point(96, 35);
            this.stock_in_idTextBox.Name = "stock_in_idTextBox";
            this.stock_in_idTextBox.Size = new System.Drawing.Size(89, 20);
            this.stock_in_idTextBox.TabIndex = 2;
            // 
            // qty_addTextBox
            // 
            this.qty_addTextBox.Location = new System.Drawing.Point(96, 114);
            this.qty_addTextBox.Name = "qty_addTextBox";
            this.qty_addTextBox.Size = new System.Drawing.Size(67, 20);
            this.qty_addTextBox.TabIndex = 8;
            // 
            // indateDateTimePicker
            // 
            this.indateDateTimePicker.CustomFormat = "yyyy-MM-dd";
            this.indateDateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.indateDateTimePicker.Location = new System.Drawing.Point(96, 140);
            this.indateDateTimePicker.Name = "indateDateTimePicker";
            this.indateDateTimePicker.Size = new System.Drawing.Size(102, 20);
            this.indateDateTimePicker.TabIndex = 10;
            // 
            // descriptionTextBox
            // 
            this.descriptionTextBox.Location = new System.Drawing.Point(96, 166);
            this.descriptionTextBox.Name = "descriptionTextBox";
            this.descriptionTextBox.Size = new System.Drawing.Size(427, 20);
            this.descriptionTextBox.TabIndex = 12;
            // 
            // buttonShowTop
            // 
            this.buttonShowTop.Location = new System.Drawing.Point(639, 337);
            this.buttonShowTop.Name = "buttonShowTop";
            this.buttonShowTop.Size = new System.Drawing.Size(98, 23);
            this.buttonShowTop.TabIndex = 13;
            this.buttonShowTop.Text = "Show Top 10";
            this.buttonShowTop.UseVisualStyleBackColor = true;
            this.buttonShowTop.Click += new System.EventHandler(this.buttonShowTop_Click);
            // 
            // buttonShowLast
            // 
            this.buttonShowLast.Location = new System.Drawing.Point(639, 381);
            this.buttonShowLast.Name = "buttonShowLast";
            this.buttonShowLast.Size = new System.Drawing.Size(98, 23);
            this.buttonShowLast.TabIndex = 14;
            this.buttonShowLast.Text = "Show Last 10";
            this.buttonShowLast.UseVisualStyleBackColor = true;
            this.buttonShowLast.Click += new System.EventHandler(this.buttonShowLast_Click);
            // 
            // buttonShowAll
            // 
            this.buttonShowAll.Location = new System.Drawing.Point(639, 428);
            this.buttonShowAll.Name = "buttonShowAll";
            this.buttonShowAll.Size = new System.Drawing.Size(98, 23);
            this.buttonShowAll.TabIndex = 15;
            this.buttonShowAll.Text = "Show All";
            this.buttonShowAll.UseVisualStyleBackColor = true;
            this.buttonShowAll.Click += new System.EventHandler(this.buttonShowAll_Click);
            // 
            // dataGridViewStockIn
            // 
            this.dataGridViewStockIn.AllowUserToAddRows = false;
            this.dataGridViewStockIn.AutoGenerateColumns = false;
            this.dataGridViewStockIn.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewStockIn.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.stockinidDataGridViewTextBoxColumn,
            this.clientidDataGridViewTextBoxColumn,
            this.itemidDataGridViewTextBoxColumn,
            this.qtyaddDataGridViewTextBoxColumn,
            this.indateDataGridViewTextBoxColumn,
            this.descriptionDataGridViewTextBoxColumn,
            this.entryDateDataGridViewTextBoxColumn});
            this.dataGridViewStockIn.DataSource = this.stockinBindingSource;
            this.dataGridViewStockIn.Location = new System.Drawing.Point(32, 251);
            this.dataGridViewStockIn.Name = "dataGridViewStockIn";
            this.dataGridViewStockIn.ReadOnly = true;
            this.dataGridViewStockIn.Size = new System.Drawing.Size(582, 229);
            this.dataGridViewStockIn.TabIndex = 16;
            this.dataGridViewStockIn.RowHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dataGridViewStockIn_RowHeaderMouseClick);
            // 
            // stockinidDataGridViewTextBoxColumn
            // 
            this.stockinidDataGridViewTextBoxColumn.DataPropertyName = "stock_in_id";
            this.stockinidDataGridViewTextBoxColumn.HeaderText = "Stock ID";
            this.stockinidDataGridViewTextBoxColumn.Name = "stockinidDataGridViewTextBoxColumn";
            this.stockinidDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // clientidDataGridViewTextBoxColumn
            // 
            this.clientidDataGridViewTextBoxColumn.DataPropertyName = "client_id";
            this.clientidDataGridViewTextBoxColumn.DataSource = this.clientinfoBindingSource;
            this.clientidDataGridViewTextBoxColumn.DisplayMember = "client_name";
            this.clientidDataGridViewTextBoxColumn.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.Nothing;
            this.clientidDataGridViewTextBoxColumn.HeaderText = "Client Name";
            this.clientidDataGridViewTextBoxColumn.Name = "clientidDataGridViewTextBoxColumn";
            this.clientidDataGridViewTextBoxColumn.ReadOnly = true;
            this.clientidDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.clientidDataGridViewTextBoxColumn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.clientidDataGridViewTextBoxColumn.ValueMember = "client_id";
            // 
            // clientinfoBindingSource
            // 
            this.clientinfoBindingSource.DataMember = "Client_info";
            this.clientinfoBindingSource.DataSource = this.sastockDataSetClient;
            // 
            // sastockDataSetClient
            // 
            this.sastockDataSetClient.DataSetName = "sastockDataSetClient";
            this.sastockDataSetClient.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // itemidDataGridViewTextBoxColumn
            // 
            this.itemidDataGridViewTextBoxColumn.DataPropertyName = "item_id";
            this.itemidDataGridViewTextBoxColumn.DataSource = this.itemsBindingSource;
            this.itemidDataGridViewTextBoxColumn.DisplayMember = "items_name";
            this.itemidDataGridViewTextBoxColumn.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.Nothing;
            this.itemidDataGridViewTextBoxColumn.HeaderText = "items Name";
            this.itemidDataGridViewTextBoxColumn.Name = "itemidDataGridViewTextBoxColumn";
            this.itemidDataGridViewTextBoxColumn.ReadOnly = true;
            this.itemidDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.itemidDataGridViewTextBoxColumn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.itemidDataGridViewTextBoxColumn.ValueMember = "items_id";
            // 
            // itemsBindingSource
            // 
            this.itemsBindingSource.DataMember = "Items";
            this.itemsBindingSource.DataSource = this.itemsDataSet;
            // 
            // itemsDataSet
            // 
            this.itemsDataSet.DataSetName = "ItemsDataSet";
            this.itemsDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // qtyaddDataGridViewTextBoxColumn
            // 
            this.qtyaddDataGridViewTextBoxColumn.DataPropertyName = "qty_add";
            this.qtyaddDataGridViewTextBoxColumn.HeaderText = "Quantity";
            this.qtyaddDataGridViewTextBoxColumn.Name = "qtyaddDataGridViewTextBoxColumn";
            this.qtyaddDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // indateDataGridViewTextBoxColumn
            // 
            this.indateDataGridViewTextBoxColumn.DataPropertyName = "indate";
            this.indateDataGridViewTextBoxColumn.HeaderText = "Date";
            this.indateDataGridViewTextBoxColumn.Name = "indateDataGridViewTextBoxColumn";
            this.indateDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // descriptionDataGridViewTextBoxColumn
            // 
            this.descriptionDataGridViewTextBoxColumn.DataPropertyName = "description";
            this.descriptionDataGridViewTextBoxColumn.HeaderText = "Description";
            this.descriptionDataGridViewTextBoxColumn.Name = "descriptionDataGridViewTextBoxColumn";
            this.descriptionDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // entryDateDataGridViewTextBoxColumn
            // 
            this.entryDateDataGridViewTextBoxColumn.DataPropertyName = "entryDate";
            this.entryDateDataGridViewTextBoxColumn.HeaderText = "Entry Date";
            this.entryDateDataGridViewTextBoxColumn.Name = "entryDateDataGridViewTextBoxColumn";
            this.entryDateDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // stockinBindingSource
            // 
            this.stockinBindingSource.DataMember = "Stock_in";
            this.stockinBindingSource.DataSource = this.sastockDataSetStockIn;
            // 
            // sastockDataSetStockIn
            // 
            this.sastockDataSetStockIn.DataSetName = "sastockDataSetStockIn";
            this.sastockDataSetStockIn.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // buttonNew
            // 
            this.buttonNew.Location = new System.Drawing.Point(32, 209);
            this.buttonNew.Name = "buttonNew";
            this.buttonNew.Size = new System.Drawing.Size(75, 23);
            this.buttonNew.TabIndex = 23;
            this.buttonNew.Text = "New";
            this.buttonNew.UseVisualStyleBackColor = true;
            this.buttonNew.Click += new System.EventHandler(this.buttonNew_Click);
            // 
            // button_Update
            // 
            this.button_Update.Location = new System.Drawing.Point(264, 209);
            this.button_Update.Name = "button_Update";
            this.button_Update.Size = new System.Drawing.Size(75, 23);
            this.button_Update.TabIndex = 21;
            this.button_Update.Text = "Update";
            this.button_Update.UseVisualStyleBackColor = true;
            this.button_Update.Click += new System.EventHandler(this.button_Update_Click);
            // 
            // button_Insert
            // 
            this.button_Insert.Location = new System.Drawing.Point(144, 209);
            this.button_Insert.Name = "button_Insert";
            this.button_Insert.Size = new System.Drawing.Size(75, 23);
            this.button_Insert.TabIndex = 20;
            this.button_Insert.Text = "Insert";
            this.button_Insert.UseVisualStyleBackColor = true;
            this.button_Insert.Click += new System.EventHandler(this.button_Insert_Click);
            // 
            // buttonPrintStock
            // 
            this.buttonPrintStock.Location = new System.Drawing.Point(639, 55);
            this.buttonPrintStock.Name = "buttonPrintStock";
            this.buttonPrintStock.Size = new System.Drawing.Size(98, 23);
            this.buttonPrintStock.TabIndex = 24;
            this.buttonPrintStock.Text = "Print Stock";
            this.buttonPrintStock.UseVisualStyleBackColor = true;
            this.buttonPrintStock.Click += new System.EventHandler(this.buttonPrintStock_Click);
            // 
            // stock_inTableAdapter
            // 
            this.stock_inTableAdapter.ClearBeforeFill = true;
            // 
            // client_infoTableAdapter
            // 
            this.client_infoTableAdapter.ClearBeforeFill = true;
            // 
            // itemsTableAdapter
            // 
            this.itemsTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.Stock_inTableAdapter = this.stock_inTableAdapter;
            this.tableAdapterManager.UpdateOrder = SA_StockInventory.sastockDataSetStockInTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // client_idComboBox
            // 
            this.client_idComboBox.DataSource = this.clientinfoBindingSource;
            this.client_idComboBox.DisplayMember = "client_name";
            this.client_idComboBox.FormattingEnabled = true;
            this.client_idComboBox.Location = new System.Drawing.Point(96, 62);
            this.client_idComboBox.Name = "client_idComboBox";
            this.client_idComboBox.Size = new System.Drawing.Size(427, 21);
            this.client_idComboBox.TabIndex = 25;
            this.client_idComboBox.ValueMember = "client_id";
            // 
            // item_idComboBox
            // 
            this.item_idComboBox.DataSource = this.itemsBindingSource;
            this.item_idComboBox.DisplayMember = "items_name";
            this.item_idComboBox.FormattingEnabled = true;
            this.item_idComboBox.Location = new System.Drawing.Point(96, 87);
            this.item_idComboBox.Name = "item_idComboBox";
            this.item_idComboBox.Size = new System.Drawing.Size(427, 21);
            this.item_idComboBox.TabIndex = 26;
            this.item_idComboBox.ValueMember = "items_id";
            // 
            // FormStockIn
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(764, 500);
            this.Controls.Add(this.item_idComboBox);
            this.Controls.Add(this.client_idComboBox);
            this.Controls.Add(this.buttonPrintStock);
            this.Controls.Add(this.buttonNew);
            this.Controls.Add(this.button_Update);
            this.Controls.Add(this.button_Insert);
            this.Controls.Add(this.dataGridViewStockIn);
            this.Controls.Add(this.buttonShowAll);
            this.Controls.Add(this.buttonShowLast);
            this.Controls.Add(this.buttonShowTop);
            this.Controls.Add(stock_in_idLabel);
            this.Controls.Add(this.stock_in_idTextBox);
            this.Controls.Add(client_idLabel);
            this.Controls.Add(item_idLabel);
            this.Controls.Add(qty_addLabel);
            this.Controls.Add(this.qty_addTextBox);
            this.Controls.Add(indateLabel);
            this.Controls.Add(this.indateDateTimePicker);
            this.Controls.Add(descriptionLabel);
            this.Controls.Add(this.descriptionTextBox);
            this.Name = "FormStockIn";
            this.Text = "Form Stock In";
            this.Load += new System.EventHandler(this.FormStockIn_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewStockIn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.clientinfoBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sastockDataSetClient)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.itemsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.itemsDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.stockinBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sastockDataSetStockIn)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox stock_in_idTextBox;
        private System.Windows.Forms.TextBox qty_addTextBox;
        private System.Windows.Forms.DateTimePicker indateDateTimePicker;
        private System.Windows.Forms.TextBox descriptionTextBox;
        private System.Windows.Forms.Button buttonShowTop;
        private System.Windows.Forms.Button buttonShowLast;
        private System.Windows.Forms.Button buttonShowAll;
        private System.Windows.Forms.DataGridView dataGridViewStockIn;
        private System.Windows.Forms.Button buttonNew;
        private System.Windows.Forms.Button button_Update;
        private System.Windows.Forms.Button button_Insert;
        private System.Windows.Forms.Button buttonPrintStock;
        private sastockDataSetStockIn sastockDataSetStockIn;
        private System.Windows.Forms.BindingSource stockinBindingSource;
        private sastockDataSetStockInTableAdapters.Stock_inTableAdapter stock_inTableAdapter;
        private sastockDataSetClient sastockDataSetClient;
        private System.Windows.Forms.BindingSource clientinfoBindingSource;
        private sastockDataSetClientTableAdapters.Client_infoTableAdapter client_infoTableAdapter;
        private ItemsDataSet itemsDataSet;
        private System.Windows.Forms.BindingSource itemsBindingSource;
        private ItemsDataSetTableAdapters.ItemsTableAdapter itemsTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn stockinidDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewComboBoxColumn clientidDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewComboBoxColumn itemidDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn qtyaddDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn indateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn descriptionDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn entryDateDataGridViewTextBoxColumn;
        private sastockDataSetStockInTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.ComboBox client_idComboBox;
        private System.Windows.Forms.ComboBox item_idComboBox;
    }
}