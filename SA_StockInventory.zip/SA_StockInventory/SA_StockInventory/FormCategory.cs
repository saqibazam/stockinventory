﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SA_StockInventory
{
    public partial class FormCategory : Form
    {
        public FormCategory()
        {
            InitializeComponent();
        }
        Class_Connection cn = new Class_Connection();
        DialogResult dlgResult;
        SqlCommand cmd;
        //SqlDataAdapter adapt;
        int i = 1;


        private void FormCategory_Load(object sender, EventArgs e)
        {
            DisplayDataInGrid();

            string userName = FormLogin.CheckUserName;
            if (userName == "Admin" || userName == "Super")
            {
                button_Delete.Visible = true;
                button_Update.Visible = true;
            }

        }

        private void DisplayDatainTextBox(int i)
        {

            cn.con.Open();
            SqlCommand cmd = new SqlCommand();
            try
            {
                cmd = new SqlCommand("crudCatogary", cn.con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add(new SqlParameter("@StatementType", "SelectCatagory"));
                cmd.Parameters.Add(new SqlParameter("@Cat_ID", i));

                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    category_idTextBox.Text = reader["category_id"].ToString();
                    category_nameTextBox.Text = reader["category_name"].ToString();
         
                }
                reader.Close();
                cn.con.Close();

            }
            catch (Exception x)
            {
                MessageBox.Show(x.GetBaseException().ToString(), "Error",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                cmd.InitializeLifetimeService();
                // cmd.Dispose();
                cn.con.Close();
                //cn.con.Dispose(); //will be written on at exit from the application time....
            }

        }

        private void DisplayDataInGrid()
        {
            // TODO: This line of code loads data into the 'sastockDataSetCategory.Category' table. You can move, or remove it, as needed.
           this.categoryTableAdapter.Fill(this.sastockDataSetCategory.Category);
        }
        private void buttonNew_Click(object sender, EventArgs e)
        {
            buttonNew.Enabled = false;
            button_Insert.Enabled = true;
            button_Update.Enabled = false;

            category_idTextBox.Text = "";
            category_nameTextBox.Text = "";
        }

        private void button_Insert_Click(object sender, EventArgs e)
        {
            dlgResult = MessageBox.Show("Do you want to Insert New Record", "New Record Insert", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
            if (dlgResult == DialogResult.Yes)
            {

                try
                {
                    if (category_idTextBox.Text == "" && category_nameTextBox.Text != "" )
                    {
                        //cmd = new SqlCommand("insert into Branch(branch_name,branch_location) values(@name,@location)", cn.con);
                        cn.con.Open();
                        cmd = new SqlCommand("crudCatogary", cn.con);
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.Add(new SqlParameter("@StatementType", "InsertCatagory"));
                        cmd.Parameters.AddWithValue("@Cat_name", category_nameTextBox.Text);
                        cmd.ExecuteNonQuery();
                        cn.con.Close();
                        MessageBox.Show("Record Inserted Successfully");
                        DisplayDatainTextBox(i);
                        DisplayDataInGrid();

                        buttonNew.Enabled = true;
                        button_Insert.Enabled = false;
                        button_Update.Enabled = true;

                    }
                    else
                    {
                        MessageBox.Show("Only for New Record, Please Fill All Fields!");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(Convert.ToString(ex));
                }
            }
        }

        private void button_Update_Click(object sender, EventArgs e)
        {
            dlgResult = MessageBox.Show("Do you want to Update this Record", "Update Record", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
            if (dlgResult == DialogResult.Yes)
            {


                try
                {
                    if (category_nameTextBox.Text != "" )
                    {
                        cn.con.Open();
                        cmd = new SqlCommand("crudCatogary", cn.con);
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.Add(new SqlParameter("@StatementType", "UpdateCatagory"));
                        cmd.Parameters.AddWithValue("@Cat_ID", category_idTextBox.Text);
                        cmd.Parameters.AddWithValue("@Cat_name", category_nameTextBox.Text);
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Record Updated Successfully");
                        cn.con.Close();
                        DisplayDatainTextBox(i);
                        DisplayDataInGrid();

                        buttonNew.Enabled = true;
                        button_Insert.Enabled = false;
                        button_Update.Enabled = true;

                    }
                    else
                    {
                        MessageBox.Show("Please Select Record to Update");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(Convert.ToString(ex));
                }
            }
        }

        private void button_Delete_Click(object sender, EventArgs e)
        {
            dlgResult = MessageBox.Show("Do you want to Delete this Record", "Delete Record", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
            if (dlgResult == DialogResult.Yes)
            {


                try
                {
                    if (category_nameTextBox.Text != "")
                    {
                        // cmd = new SqlCommand("delete from Branch where branch_id=@id", cn.con);
                        cn.con.Open();
                        cmd = new SqlCommand("crudCatogary", cn.con);
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.Add(new SqlParameter("@StatementType", "DeleteCatagory"));
                        cmd.Parameters.AddWithValue("@Cat_ID", category_idTextBox.Text);
                        cmd.ExecuteNonQuery();
                        cn.con.Close();
                        MessageBox.Show("Record Deleted Successfully!");
                        DisplayDatainTextBox(i);
                        DisplayDataInGrid();
                    }
                    else { MessageBox.Show("Please Select Record to Delete"); }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(Convert.ToString(ex));
                }

                //   MessageBox.Show("Please Select Record to Delete");
            }
        }

        private void categoryDataGridView_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            category_idTextBox.Text = categoryDataGridView.Rows[e.RowIndex].Cells[0].Value.ToString();
            i = Convert.ToInt16(category_idTextBox.Text);
            DisplayDatainTextBox(i);

        }
    }
}
