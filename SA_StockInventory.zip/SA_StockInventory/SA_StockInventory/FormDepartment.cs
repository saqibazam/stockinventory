﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SA_StockInventory
{
    public partial class FormDepartment : Form
    {
        Class_Connection cn = new Class_Connection();
        DialogResult dlgResult;
        SqlCommand cmd;
        int i=3;

        public FormDepartment()
        {
            InitializeComponent();
        }

    

        private void FormDepartment_Load(object sender, EventArgs e)
        {
            DisplayDatainTextBox(i);
            DisplayDataInGrid();

            string userName = FormLogin.CheckUserName;
            if (userName == "Admin" || userName == "Super")
            {
                button_Delete.Visible = true;
                button_Update.Visible = true;
            }

        }

        private void buttonNew_Click(object sender, EventArgs e)
        {
            buttonNew.Enabled = false;
            button_Insert.Enabled = true;
            button_Update.Enabled = false;
            department_idTextBox.Text  = "";
            department_nameTextBox.Text = "";

        }

        private void button_Insert_Click(object sender, EventArgs e)
        {
            
                dlgResult = MessageBox.Show("Do you want to Insert New Record", "New Record Insert", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
                if (dlgResult == DialogResult.Yes)
                {

                    try
                    {
                        if (department_idTextBox.Text == "" && (department_nameTextBox.Text != ""))
                        {
                          //  cmd = new SqlCommand("insert into Department(department_name) values(@depName)", cn.con);
                            cn.con.Open();
                        cmd = new SqlCommand("crudDepartment", cn.con);
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.Add(new SqlParameter("@StatementType", "InsertDepartment"));
                        cmd.Parameters.AddWithValue("@Dep_name", department_nameTextBox.Text);
                        cmd.ExecuteNonQuery();
                        cn.con.Close();
                        MessageBox.Show("Record Inserted Successfully");
                        DisplayDatainTextBox(i);
                        DisplayDataInGrid();
                        buttonNew.Enabled = true;
                        button_Insert.Enabled = false;
                        button_Update.Enabled = true;

                    }
                    else
                        {
                            MessageBox.Show("Only for New Record, Please Fill All Fields!");
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(Convert.ToString(ex));
                    }
                }
            }

        private void DisplayDatainTextBox(int i)
        {
            cn.con.Open();
            cmd = new SqlCommand();
            try
            {
                //cmd = new SqlCommand("select department_id , department_name  from Department where department_id = 3", cn.con);
                cmd = new SqlCommand("crudDepartment", cn.con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add(new SqlParameter("@StatementType", "SelectDepartment"));
                cmd.Parameters.Add(new SqlParameter("@Dep_ID", i));

                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    department_idTextBox.Text = reader["department_id"].ToString();
                    department_nameTextBox.Text = reader["department_name"].ToString();

                }
                reader.Close();
                cn.con.Close();

            }
            catch (Exception x)
            {
                MessageBox.Show(x.GetBaseException().ToString(), "Error",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                cmd.InitializeLifetimeService();

                cn.con.Close();

            }


        }

        private void DisplayDataInGrid()
        {
            this.departmentTableAdapter.Fill(this.sastockDataSetDepartment.Department);

        }

        private void button_Update_Click(object sender, EventArgs e)
        {
            dlgResult = MessageBox.Show("Do you want to Update this Record", "Update Record", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
            if (dlgResult == DialogResult.Yes)
            {


                try
                {
                    if (department_idTextBox.Text != "" && (department_nameTextBox.Text != ""))
                    {
                       // cmd = new SqlCommand("update department set department_name=@deptName where department_id=@deptID", cn.con);
                        cn.con.Open();
                        cmd = new SqlCommand("crudDepartment", cn.con);
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.Add(new SqlParameter("@StatementType", "UpdateDepartment"));
                        cmd.Parameters.AddWithValue("@Dep_ID", department_idTextBox.Text);
                        cmd.Parameters.AddWithValue("@Dep_name", department_nameTextBox.Text);
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Record Updated Successfully");
                        cn.con.Close();
                        DisplayDatainTextBox(i);
                        DisplayDataInGrid();

                        buttonNew.Enabled = true;
                        button_Insert.Enabled = false;
                        button_Update.Enabled = true;

                    }
                    else
                    {
                        MessageBox.Show("Please Select Record to Update");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(Convert.ToString(ex));
                }
            } //

        }

        private void button_Delete_Click(object sender, EventArgs e)
        {
            dlgResult = MessageBox.Show("Do you want to Delete this Record", "Delete Record", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
            if (dlgResult == DialogResult.Yes)
            {


                try
                {
                    if (department_idTextBox.Text != "")
                    {
                      //  cmd = new SqlCommand("delete from department where department_id=@deptID", cn.con);
                        cn.con.Open();
                        cmd = new SqlCommand("crudDepartment", cn.con);
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.Add(new SqlParameter("@StatementType", "DeleteDepartment"));
                        cmd.Parameters.AddWithValue("@Dep_ID", department_idTextBox.Text);
                        cmd.ExecuteNonQuery();
                        cn.con.Close();
                        MessageBox.Show("Record Deleted Successfully!");
                        DisplayDatainTextBox(i);
                        DisplayDataInGrid();
                    }
                    else { MessageBox.Show("Please Select Record to Delete"); }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(Convert.ToString(ex));
                }

                
            }
        }

        private void departmentDataGridView_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            department_idTextBox.Text = departmentDataGridView.Rows[e.RowIndex].Cells[0].Value.ToString();
            department_nameTextBox.Text = departmentDataGridView.Rows[e.RowIndex].Cells[1].Value.ToString();


        }
    }
}
