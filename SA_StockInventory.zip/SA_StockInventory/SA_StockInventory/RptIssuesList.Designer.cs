﻿namespace SA_StockInventory
{
    partial class RptIssuesList
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource1 = new Microsoft.Reporting.WinForms.ReportDataSource();
            this.View_StockInBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.ViewSaIN = new SA_StockInventory.ViewSaIN();
            this.View_StockOutBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.ViewSaOut = new SA_StockInventory.ViewSaOut();
            this.comboBoxClient = new System.Windows.Forms.ComboBox();
            this.clientinfoBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.sastockDataSetClient = new SA_StockInventory.sastockDataSetClient();
            this.comboBoxCatagory = new System.Windows.Forms.ComboBox();
            this.categoryBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.sastockDataSetCategory = new SA_StockInventory.sastockDataSetCategory();
            this.buttonSearch = new System.Windows.Forms.Button();
            this.View_StockInTableAdapter = new SA_StockInventory.ViewSaINTableAdapters.View_StockInTableAdapter();
            this.client_infoTableAdapter = new SA_StockInventory.sastockDataSetClientTableAdapters.Client_infoTableAdapter();
            this.categoryTableAdapter = new SA_StockInventory.sastockDataSetCategoryTableAdapters.CategoryTableAdapter();
            this.View_StockOutTableAdapter = new SA_StockInventory.ViewSaOutTableAdapters.View_StockOutTableAdapter();
            this.reportViewer1 = new Microsoft.Reporting.WinForms.ReportViewer();
            this.checkBoxDate = new System.Windows.Forms.CheckBox();
            this.dateTimePickerFrom = new System.Windows.Forms.DateTimePicker();
            this.dateTimePickerTo = new System.Windows.Forms.DateTimePicker();
            this.radioButtonClient = new System.Windows.Forms.RadioButton();
            this.radioButtonCatagory = new System.Windows.Forms.RadioButton();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.View_StockInBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ViewSaIN)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.View_StockOutBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ViewSaOut)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.clientinfoBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sastockDataSetClient)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.categoryBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sastockDataSetCategory)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // View_StockInBindingSource
            // 
            this.View_StockInBindingSource.DataMember = "View_StockIn";
            this.View_StockInBindingSource.DataSource = this.ViewSaIN;
            this.View_StockInBindingSource.CurrentChanged += new System.EventHandler(this.View_StockInBindingSource_CurrentChanged);
            // 
            // ViewSaIN
            // 
            this.ViewSaIN.DataSetName = "ViewSaIN";
            this.ViewSaIN.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // View_StockOutBindingSource
            // 
            this.View_StockOutBindingSource.DataMember = "View_StockOut";
            this.View_StockOutBindingSource.DataSource = this.ViewSaOut;
            // 
            // ViewSaOut
            // 
            this.ViewSaOut.DataSetName = "ViewSaOut";
            this.ViewSaOut.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // comboBoxClient
            // 
            this.comboBoxClient.DataSource = this.clientinfoBindingSource;
            this.comboBoxClient.DisplayMember = "client_name";
            this.comboBoxClient.FormattingEnabled = true;
            this.comboBoxClient.Location = new System.Drawing.Point(109, 22);
            this.comboBoxClient.Name = "comboBoxClient";
            this.comboBoxClient.Size = new System.Drawing.Size(170, 21);
            this.comboBoxClient.TabIndex = 1;
            this.comboBoxClient.ValueMember = "client_id";
            // 
            // clientinfoBindingSource
            // 
            this.clientinfoBindingSource.DataMember = "Client_info";
            this.clientinfoBindingSource.DataSource = this.sastockDataSetClient;
            // 
            // sastockDataSetClient
            // 
            this.sastockDataSetClient.DataSetName = "sastockDataSetClient";
            this.sastockDataSetClient.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // comboBoxCatagory
            // 
            this.comboBoxCatagory.DataSource = this.categoryBindingSource;
            this.comboBoxCatagory.DisplayMember = "category_name";
            this.comboBoxCatagory.FormattingEnabled = true;
            this.comboBoxCatagory.Location = new System.Drawing.Point(109, 55);
            this.comboBoxCatagory.Name = "comboBoxCatagory";
            this.comboBoxCatagory.Size = new System.Drawing.Size(170, 21);
            this.comboBoxCatagory.TabIndex = 2;
            this.comboBoxCatagory.ValueMember = "category_id";
            // 
            // categoryBindingSource
            // 
            this.categoryBindingSource.DataMember = "Category";
            this.categoryBindingSource.DataSource = this.sastockDataSetCategory;
            // 
            // sastockDataSetCategory
            // 
            this.sastockDataSetCategory.DataSetName = "sastockDataSetCategory";
            this.sastockDataSetCategory.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // buttonSearch
            // 
            this.buttonSearch.Location = new System.Drawing.Point(620, 68);
            this.buttonSearch.Name = "buttonSearch";
            this.buttonSearch.Size = new System.Drawing.Size(89, 23);
            this.buttonSearch.TabIndex = 4;
            this.buttonSearch.Text = "Search";
            this.buttonSearch.UseVisualStyleBackColor = true;
            this.buttonSearch.Click += new System.EventHandler(this.buttonSearch_Click);
            // 
            // View_StockInTableAdapter
            // 
            this.View_StockInTableAdapter.ClearBeforeFill = true;
            // 
            // client_infoTableAdapter
            // 
            this.client_infoTableAdapter.ClearBeforeFill = true;
            // 
            // categoryTableAdapter
            // 
            this.categoryTableAdapter.ClearBeforeFill = true;
            // 
            // View_StockOutTableAdapter
            // 
            this.View_StockOutTableAdapter.ClearBeforeFill = true;
            // 
            // reportViewer1
            // 
            reportDataSource1.Name = "DataSetSINREPORT";
            reportDataSource1.Value = this.View_StockInBindingSource;
            this.reportViewer1.LocalReport.DataSources.Add(reportDataSource1);
            this.reportViewer1.LocalReport.ReportEmbeddedResource = "SA_StockInventory.RptIssueList.rdlc";
            this.reportViewer1.Location = new System.Drawing.Point(13, 126);
            this.reportViewer1.Name = "reportViewer1";
            this.reportViewer1.Size = new System.Drawing.Size(884, 324);
            this.reportViewer1.TabIndex = 8;
            // 
            // checkBoxDate
            // 
            this.checkBoxDate.AutoSize = true;
            this.checkBoxDate.Location = new System.Drawing.Point(10, 13);
            this.checkBoxDate.Name = "checkBoxDate";
            this.checkBoxDate.Size = new System.Drawing.Size(15, 14);
            this.checkBoxDate.TabIndex = 11;
            this.checkBoxDate.UseVisualStyleBackColor = true;
            this.checkBoxDate.CheckedChanged += new System.EventHandler(this.checkBoxFrom_CheckedChanged);
            // 
            // dateTimePickerFrom
            // 
            this.dateTimePickerFrom.Location = new System.Drawing.Point(74, 22);
            this.dateTimePickerFrom.Name = "dateTimePickerFrom";
            this.dateTimePickerFrom.Size = new System.Drawing.Size(188, 20);
            this.dateTimePickerFrom.TabIndex = 13;
            // 
            // dateTimePickerTo
            // 
            this.dateTimePickerTo.Location = new System.Drawing.Point(74, 55);
            this.dateTimePickerTo.Name = "dateTimePickerTo";
            this.dateTimePickerTo.Size = new System.Drawing.Size(188, 20);
            this.dateTimePickerTo.TabIndex = 14;
            // 
            // radioButtonClient
            // 
            this.radioButtonClient.AutoSize = true;
            this.radioButtonClient.Checked = true;
            this.radioButtonClient.Location = new System.Drawing.Point(16, 26);
            this.radioButtonClient.Name = "radioButtonClient";
            this.radioButtonClient.Size = new System.Drawing.Size(51, 17);
            this.radioButtonClient.TabIndex = 15;
            this.radioButtonClient.TabStop = true;
            this.radioButtonClient.Text = "Client";
            this.radioButtonClient.UseVisualStyleBackColor = true;
            // 
            // radioButtonCatagory
            // 
            this.radioButtonCatagory.AutoSize = true;
            this.radioButtonCatagory.Location = new System.Drawing.Point(16, 59);
            this.radioButtonCatagory.Name = "radioButtonCatagory";
            this.radioButtonCatagory.Size = new System.Drawing.Size(67, 17);
            this.radioButtonCatagory.TabIndex = 16;
            this.radioButtonCatagory.Text = "Catagory";
            this.radioButtonCatagory.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.radioButtonClient);
            this.groupBox1.Controls.Add(this.radioButtonCatagory);
            this.groupBox1.Controls.Add(this.comboBoxClient);
            this.groupBox1.Controls.Add(this.comboBoxCatagory);
            this.groupBox1.Location = new System.Drawing.Point(12, 9);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(294, 97);
            this.groupBox1.TabIndex = 17;
            this.groupBox1.TabStop = false;
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.dateTimePickerFrom);
            this.groupBox2.Controls.Add(this.dateTimePickerTo);
            this.groupBox2.Controls.Add(this.checkBoxDate);
            this.groupBox2.Location = new System.Drawing.Point(312, 9);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(272, 97);
            this.groupBox2.TabIndex = 20;
            this.groupBox2.TabStop = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(24, 58);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(23, 13);
            this.label2.TabIndex = 16;
            this.label2.Text = "To:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(24, 27);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(33, 13);
            this.label1.TabIndex = 15;
            this.label1.Text = "From:";
            // 
            // RptIssuesList
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(909, 459);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.reportViewer1);
            this.Controls.Add(this.buttonSearch);
            this.Name = "RptIssuesList";
            this.Text = "Report Issue List";
            this.Load += new System.EventHandler(this.RptIssuesList_Load);
            ((System.ComponentModel.ISupportInitialize)(this.View_StockInBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ViewSaIN)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.View_StockOutBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ViewSaOut)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.clientinfoBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sastockDataSetClient)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.categoryBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sastockDataSetCategory)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.BindingSource View_StockInBindingSource;
        private ViewSaIN ViewSaIN;
        private System.Windows.Forms.ComboBox comboBoxClient;
        private System.Windows.Forms.ComboBox comboBoxCatagory;
        private System.Windows.Forms.Button buttonSearch;
        private ViewSaINTableAdapters.View_StockInTableAdapter View_StockInTableAdapter;
        private sastockDataSetClient sastockDataSetClient;
        private System.Windows.Forms.BindingSource clientinfoBindingSource;
        private sastockDataSetClientTableAdapters.Client_infoTableAdapter client_infoTableAdapter;
        private sastockDataSetCategory sastockDataSetCategory;
        private System.Windows.Forms.BindingSource categoryBindingSource;
        private sastockDataSetCategoryTableAdapters.CategoryTableAdapter categoryTableAdapter;
        private System.Windows.Forms.BindingSource View_StockOutBindingSource;
        private ViewSaOut ViewSaOut;
        private ViewSaOutTableAdapters.View_StockOutTableAdapter View_StockOutTableAdapter;
        private Microsoft.Reporting.WinForms.ReportViewer reportViewer1;
        private System.Windows.Forms.CheckBox checkBoxDate;
        private System.Windows.Forms.DateTimePicker dateTimePickerFrom;
        private System.Windows.Forms.DateTimePicker dateTimePickerTo;
        private System.Windows.Forms.RadioButton radioButtonClient;
        private System.Windows.Forms.RadioButton radioButtonCatagory;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
    }
}