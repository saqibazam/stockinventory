﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SA_StockInventory
{
    public partial class FormStockIn : Form
    {
        public FormStockIn()
        {
            InitializeComponent();
        }

        Class_Connection cn = new Class_Connection();
        DialogResult dlgResult;
        SqlCommand cmd;
        int i = 2;
        //SqlDataAdapter adapt;
        private void DisplayDatainTextBox(int i)
        {
            cn.con.Open();
            cmd = new SqlCommand();
            try
            {
                cmd = new SqlCommand("crudStock_in", cn.con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add(new SqlParameter("@StatementType", "SelectStock_in"));
                cmd.Parameters.Add(new SqlParameter("@Stock_in_id", i));

                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    stock_in_idTextBox.Text = reader["stock_in_id"].ToString();
                    client_idComboBox.SelectedValue = reader["client_id"].ToString();
                    item_idComboBox.SelectedValue = reader["item_id"].ToString();
                    qty_addTextBox.Text = reader["qty_add"].ToString();
                    indateDateTimePicker.Text = reader["indate"].ToString();
                    descriptionTextBox.Text = reader["description"].ToString();
                }
                reader.Close();
                cn.con.Close();

            }
            catch (Exception x)
            {
                MessageBox.Show(x.GetBaseException().ToString(), "Error",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                cmd.InitializeLifetimeService();

                cn.con.Close();

            }

        }


        private void FormStockIn_Load(object sender, EventArgs e)
        {
            DisplayDatainTextBox(i);
            DisplayDataInGridTop();
        }

        private void buttonNew_Click(object sender, EventArgs e)
        {
            stock_in_idTextBox.Text = "";
            client_idComboBox.Text = "";
            item_idComboBox.Text = "";
            qty_addTextBox.Text = "";
            // indateDateTimePicker
            descriptionTextBox.Text = "";
        }

        private void DisplayDataInGrid()
        {
            // TODO: This line of code loads data into the 'itemsDataSet.Items' table. You can move, or remove it, as needed.
            this.itemsTableAdapter.Fill(this.itemsDataSet.Items);
            // TODO: This line of code loads data into the 'sastockDataSetClient.Client_info' table. You can move, or remove it, as needed.
            this.client_infoTableAdapter.Fill(this.sastockDataSetClient.Client_info);
            // TODO: This line of code loads data into the 'sastockDataSetStockIn.Stock_in' table. You can move, or remove it, as needed.
            this.stock_inTableAdapter.Fill(this.sastockDataSetStockIn.Stock_in);

        }

        private void DisplayDataInGridTop()
        {
            // TODO: This line of code loads data into the 'itemsDataSet.Items' table. You can move, or remove it, as needed.
            this.itemsTableAdapter.Fill(this.itemsDataSet.Items);
            // TODO: This line of code loads data into the 'sastockDataSetClient.Client_info' table. You can move, or remove it, as needed.
            this.client_infoTableAdapter.Fill(this.sastockDataSetClient.Client_info);
            // TODO: This line of code loads data into the 'sastockDataSetStockIn.Stock_in' table. You can move, or remove it, as needed.
            this.stock_inTableAdapter.FillByTop(this.sastockDataSetStockIn.Stock_in);

        }

        private void DisplayDataInGridLast()
        {
            // TODO: This line of code loads data into the 'itemsDataSet.Items' table. You can move, or remove it, as needed.
            this.itemsTableAdapter.Fill(this.itemsDataSet.Items);
            // TODO: This line of code loads data into the 'sastockDataSetClient.Client_info' table. You can move, or remove it, as needed.
            this.client_infoTableAdapter.Fill(this.sastockDataSetClient.Client_info);
            // TODO: This line of code loads data into the 'sastockDataSetStockIn.Stock_in' table. You can move, or remove it, as needed.
            this.stock_inTableAdapter.FillByLast (this.sastockDataSetStockIn.Stock_in);

        }


        private void button_Insert_Click(object sender, EventArgs e)
        {
            dlgResult = MessageBox.Show("Do you want to Insert New Record", "New Record Insert", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
            if (dlgResult == DialogResult.Yes)
            {

                try
                {
                    if (stock_in_idTextBox.Text == "" && (qty_addTextBox.Text != ""))
                    {
                        cn.con.Open();
                        cmd = new SqlCommand("crudStock_in", cn.con);
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.Add(new SqlParameter("@StatementType", "InsertStock_in"));
                        cmd.Parameters.AddWithValue("@Client_id", client_idComboBox.SelectedValue );
                        cmd.Parameters.AddWithValue("@Item_id", item_idComboBox.SelectedValue);
                        cmd.Parameters.AddWithValue("@Qty_add", qty_addTextBox.Text);
                        //DateTime myDateTime = DateTime.Now;
                        //string sqlFormattedDate = myDateTime.ToString("yyyy-MM-dd HH:mm:ss");
                        
                        cmd.Parameters.AddWithValue("@In_Date", indateDateTimePicker.Text );
                        cmd.Parameters.AddWithValue("@Desc", descriptionTextBox.Text);
                        //cmd.Parameters.AddWithValue("@EntryDate", DateTime.Now);

                        cmd.ExecuteNonQuery();
                        cn.con.Close();
                        MessageBox.Show("Record Inserted Successfully");
                        DisplayDatainTextBox(i);
                        DisplayDataInGridLast();
                    }
                    else
                    {
                        MessageBox.Show("Only for New Record, Please Fill All Fields!");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(Convert.ToString(ex));
                }

            }
        }

        private void button_Update_Click(object sender, EventArgs e)
        {
            dlgResult = MessageBox.Show("Do you want to Update this Record", "Update Record", MessageBoxButtons.YesNo, MessageBoxIcon.Information);
            if (dlgResult == DialogResult.Yes)
            {


                try
                {
                    if (stock_in_idTextBox.Text != "" && qty_addTextBox.Text != "")
                    {
                        //cmd = new SqlCommand("update Branch set branch_name=@name,branch_location=@location where branch_id=@id", cn.con);
                        cn.con.Open();
                        cmd = new SqlCommand("crudStock_in", cn.con);
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.Add(new SqlParameter("@StatementType", "UpdateStock_in"));
                        cmd.Parameters.AddWithValue("@Stock_in_id", stock_in_idTextBox.Text);
                        cmd.Parameters.AddWithValue("@Client_id", client_idComboBox.SelectedValue );
                        cmd.Parameters.AddWithValue("@Item_id", item_idComboBox.SelectedValue);
                        cmd.Parameters.AddWithValue("@Qty_add", qty_addTextBox.Text);
                        cmd.Parameters.AddWithValue("@In_Date", indateDateTimePicker.Text);
                        cmd.Parameters.AddWithValue("@Desc", descriptionTextBox.Text);
                        //cmd.Parameters.AddWithValue("@EntryDate", DateTime.Now);
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Record Updated Successfully");
                        cn.con.Close();
                        DisplayDatainTextBox(i);
                        DisplayDataInGridLast();
                    }
                    else
                    {
                        MessageBox.Show("Please Select Record to Update");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(Convert.ToString(ex));
                }

            }
        }

        private void buttonShowTop_Click(object sender, EventArgs e)
        {
            DisplayDataInGridTop();
        }

        private void buttonShowAll_Click(object sender, EventArgs e)
        {
            DisplayDataInGrid();
        }

        private void buttonShowLast_Click(object sender, EventArgs e)
        {
            DisplayDataInGridLast();
        }

        private void dataGridViewStockIn_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            stock_in_idTextBox.Text = dataGridViewStockIn.Rows[e.RowIndex].Cells[0].Value.ToString();
            i = Convert.ToInt16(stock_in_idTextBox.Text);

            DisplayDatainTextBox(i);

        }

        private void buttonPrintStock_Click(object sender, EventArgs e)
        {

        }
    }
}



